// routes
import Router from './routes';
// theme
import ThemeConfig from './theme';
import GlobalStyles from './theme/globalStyles';
// hooks
import useAuth from './hooks/useAuth';
// components
// import Settings from './components/settings';
import RtlLayout from './components/RtlLayout';
import ScrollToTop from './components/ScrollToTop';
import GoogleAnalytics from './components/GoogleAnalytics';
import NotistackProvider from './components/NotistackProvider';
import ThemePrimaryColor from './components/ThemePrimaryColor';
import ThemeLocalization from './components/ThemeLocalization';
import { BaseOptionChartStyle } from './components/charts/BaseOptionChart';
import LoadingScreen, { ProgressBarStyle } from './components/LoadingScreen';
import TokensCore from './contexts/TokensCore';
import WalletProvider from './contexts/WalletContext';
// import RoleProvider from './contexts/RoleContext';
import MemberCProvider from './contexts/MemberC';
import NotificationsProvider from './contexts/NotificationsContext';
import UserInfoProvider from './contexts/UserInfoContext';
import HostWalletProvider from './contexts/HostWalletContext';
import VersionProvider from './contexts/VersionContext';
import GoogleMapsApiProvider from './contexts/GoogleMapsApiProvider';
import EmpaqueProvider from './contexts/EmpaqueContext';
import SandboxProductionProvider from './contexts/SandboxProductionContext';
import OriginActionProvider from './contexts/OriginActionContext';
import UserLockerProvider from './contexts/UserLockerContext';
import DescuentoCuponesProvider from './contexts/DescuentoCuponesContext';
import UtilidadesProvider from './contexts/UtilidadesContext';
import BackendRoutesControlProvider from './contexts/BackendRoutesControlContext';

// ----------------------------------------------------------------------

export default function App() {
  const { isInitialized } = useAuth();

  return (
    <ThemeConfig>
      <ThemePrimaryColor>
        <ThemeLocalization>
          <RtlLayout>
            <NotistackProvider>
              <TokensCore>
                <VersionProvider>
                  <BackendRoutesControlProvider>
                    <SandboxProductionProvider>
                      <OriginActionProvider>
                        <UserInfoProvider>
                          <WalletProvider>
                            <HostWalletProvider>
                              <DescuentoCuponesProvider>
                                <UserLockerProvider>
                                  <MemberCProvider>
                                    <NotificationsProvider>
                                      <GoogleMapsApiProvider>
                                        <EmpaqueProvider>
                                          <UtilidadesProvider>
                                            <NotificationsProvider>
                                              <GlobalStyles />
                                              <ProgressBarStyle />
                                              <BaseOptionChartStyle />
                                              <ScrollToTop />
                                              <GoogleAnalytics />
                                              {isInitialized ? <Router /> : <LoadingScreen />}
                                            </NotificationsProvider>{' '}
                                          </UtilidadesProvider>
                                        </EmpaqueProvider>
                                      </GoogleMapsApiProvider>
                                    </NotificationsProvider>
                                  </MemberCProvider>
                                </UserLockerProvider>
                              </DescuentoCuponesProvider>
                            </HostWalletProvider>
                          </WalletProvider>
                        </UserInfoProvider>
                      </OriginActionProvider>
                    </SandboxProductionProvider>
                  </BackendRoutesControlProvider>
                </VersionProvider>
              </TokensCore>
            </NotistackProvider>
          </RtlLayout>
        </ThemeLocalization>
      </ThemePrimaryColor>
    </ThemeConfig>
  );
}
