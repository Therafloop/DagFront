import React, { useEffect, useState } from 'react';
import { Card } from '@mui/material';
import { GoogleMap, Marker } from '@react-google-maps/api';

const containerStyle = {
  width: '100%',
  height: '400px'
};

// const position = {
//   lat: 20.6596988,
//   lng: -103.3496092
// };

function SucursalMap({ actualMarkerPos }) {
  const [center, setCenter] = useState({
    lat: 20.6596988,
    lng: -103.3496092
  });
  const [positonMarker, setPositionMarker] = useState(null);
  const onLoad = (marker) => {
    console.log('marker: ', marker);
  };

  useEffect(() => {
    setPositionMarker(actualMarkerPos);
    if (actualMarkerPos) {
      setCenter(actualMarkerPos);
    }
  }, [actualMarkerPos]);
  return (
    <Card sx={{ padding: '10px', width: '100%' }}>
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={12}
        options={{ streetViewControl: false, mapTypeControl: false, fullscreenControl: false }}
      >
        {/* Child components, such as markers, info windows, etc. */}
        {positonMarker && <Marker onLoad={onLoad} position={positonMarker} />}
      </GoogleMap>
    </Card>
  );
}

export default SucursalMap;
