import React from 'react';
import { Box, Card, Divider, IconButton, Paper, styled, Typography } from '@mui/material';
import { Icon } from '@iconify/react';
import DialogSucursalDetalle from './sucursalDetalle/DialogSucursalDetalle';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  //   textAlign: 'center',
  //   color: theme.palette.text.secondary,
  display: 'flex',
  flexDirection: 'column'
  // height: '100%'
}));

const CuztomBox = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '70px 1fr'
}));

function CardSucursales({ dataItem }) {
  const { numCalle, calle, colonia, ciudad, estado, codPost, pais, status, sucursalName } = dataItem;
  return (
    <Item elevation={10}>
      <Box sx={{ display: 'flex', gap: '10px', justifyContent: 'space-between' }}>
        <Typography variant="subtitle1">{sucursalName}</Typography>
        {/* <IconButton>
          <Icon icon="eva:more-vertical-fill" />
        </IconButton> */}
        <DialogSucursalDetalle dataItem={dataItem} />
      </Box>
      <Divider />
      <Box>
        <CuztomBox>
          <Typography>Estado:</Typography>
          <Typography variant="subtitle1">{estado}</Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography>Ciudad:</Typography>
          <Typography variant="subtitle1">{ciudad}</Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography>Colonia:</Typography>
          <Typography variant="subtitle1">{colonia}</Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography>Status:</Typography>
          <Typography variant="subtitle1">{status || 'active'}</Typography>
        </CuztomBox>
      </Box>
    </Item>
  );
}

export default CardSucursales;
