import React, { useState } from 'react';
import { Box, Card, Collapse, IconButton, styled, Typography, useTheme } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton size="small" {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest
  })
}));

const CuztomBox = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '90px 1fr'
}));

function CardDetalle({ dataItem }) {
  const [expanded, setExpanded] = useState(true);
  const theme = useTheme();
  const { numCalle, calle, colonia, ciudad, estado, codPost, pais, status, coordinates, sucursalName } = dataItem;

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  return (
    <Box sx={{ position: 'absolute', zIndex: 1000, top: 0, left: 0 }}>
      <Card sx={{ padding: '8px', borderRadius: '8px' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '30px' }}>
          <Typography variant="subtitle1">{sucursalName}</Typography>
          <ExpandMore expand={expanded} onClick={handleExpandClick} aria-expanded={expanded} aria-label="show more">
            <ExpandMoreIcon />
          </ExpandMore>
        </Box>

        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <CuztomBox>
            <Typography fontSize="15px">Calle:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {calle} {numCalle}
            </Typography>
          </CuztomBox>
          <CuztomBox>
            <Typography fontSize="15px">Colonia:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {colonia}
            </Typography>
          </CuztomBox>
          <CuztomBox>
            <Typography fontSize="15px">Ciudad:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {ciudad}
            </Typography>
          </CuztomBox>
          <CuztomBox>
            <Typography fontSize="15px">Estado:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {estado}
            </Typography>
          </CuztomBox>
          <CuztomBox>
            <Typography fontSize="15px">Cod. postal:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {codPost}
            </Typography>
          </CuztomBox>
        </Collapse>
      </Card>
    </Box>
  );
}

export default CardDetalle;
