import { Box, Grid } from '@mui/material';
import React, { useEffect, useState } from 'react';
import SucursalForm from '../../newSucursal/SucursalForm';
import SucursalMap from '../../newSucursal/SucursalMap';

function ActualizarSucursal({ dataItem }) {
  const [actualMarkerPos, setActualMarker] = useState(null);

  const { numCalle, calle, colonia, ciudad, estado, codPost, pais, status, coordinates, sucursalName } = dataItem;

  const handleActualMarker = (objData) => {
    setActualMarker(objData);
  };

  useEffect(() => {
    handleActualMarker(coordinates);
  }, [coordinates]);
  return (
    <Box sx={{ marginTop: '15px' }}>
      <Grid container spacing={2}>
        <Grid item md={12} lg={6}>
          <SucursalForm handleActualMarker={handleActualMarker} dataItem={dataItem} action="update" />
        </Grid>
        <Grid item md={12} lg={6}>
          <SucursalMap actualMarkerPos={actualMarkerPos} />
        </Grid>
      </Grid>
    </Box>
  );
}

export default ActualizarSucursal;
