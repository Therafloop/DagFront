import { Box } from '@mui/material';
import { GoogleMap, Marker } from '@react-google-maps/api';
import React, { useEffect, useState } from 'react';
import CardDetalle from './CardDetalle';

const containerStyle = {
  width: '100%',
  height: '400px',
  zIndex: 900
};

function DetalleSucursal({ dataItem }) {
  const [center, setCenter] = useState({
    lat: 20.6596988,
    lng: -103.3496092
  });
  const [positonMarker, setPositionMarker] = useState(null);

  const { coordinates } = dataItem;

  useEffect(() => {
    if (coordinates) {
      setPositionMarker(coordinates);
      setCenter(coordinates);
    }
  }, [coordinates]);

  return (
    <Box sx={{ position: 'relative', width: '100%' }}>
      <Box sx={{ position: 'relative', width: '100%', zIndex: 900 }}>
        <GoogleMap
          mapContainerStyle={containerStyle}
          center={center}
          zoom={12}
          options={{ streetViewControl: false, mapTypeControl: false, fullscreenControl: false }}
        >
          {/* Child components, such as markers, info windows, etc. */}
          {positonMarker && <Marker position={positonMarker} />}
        </GoogleMap>
      </Box>
      {/* <Box sx={{ position: 'absolute', zIndex: '1000' }}> */}
      <CardDetalle dataItem={dataItem} />
      {/* </Box> */}
    </Box>
  );
}

export default DetalleSucursal;
