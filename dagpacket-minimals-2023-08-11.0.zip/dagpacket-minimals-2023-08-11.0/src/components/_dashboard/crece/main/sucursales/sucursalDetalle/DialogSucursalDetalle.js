import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import SelectOptionLayout, { SideItem } from '../../../../../../layouts/components/SelectOptionLayout';
import DetailsIcon from '@mui/icons-material/Details';
import DetalleSucursal from './section-1/DetalleSucursal';
import ActualizarSucursal from './section-2/ActualizarSucursal';

export default function DialogSucursalDetalle({ dataItem }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <IconButton onClick={() => setOpenDialog(true)}>
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>
      <DialogBody open={openDialog} onClose={setOpenDialog} dataItem={dataItem} />
    </>
  );
}

function DialogBody({ open, onClose, dataItem }) {
  const [section, setSection] = useState(1);
  const handleClose = () => {
    onClose(false);
  };

  const side = (
    <>
      <SideItem text="Detalles" section={1} action={setSection} icon={<DetailsIcon />} />
      <SideItem text="Actualizar" section={2} action={setSection} icon={<DetailsIcon />} />
    </>
  );

  const body = (
    <>
      {section === 1 && (
        <>
          <Grid item xs={12}>
            <DetalleSucursal dataItem={dataItem} />
          </Grid>
        </>
      )}
      {section === 2 && (
        <>
          <Grid item xs={12}>
            <ActualizarSucursal dataItem={dataItem} />
          </Grid>
        </>
      )}
    </>
  );

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="xl"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Detalle sucursal</DialogTitle> */}
      <DialogContent>
        <SelectOptionLayout sidebar={side} body={body} />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
