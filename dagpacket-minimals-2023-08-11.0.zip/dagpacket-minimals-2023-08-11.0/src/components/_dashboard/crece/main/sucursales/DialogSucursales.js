import React, { useEffect, useState } from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  InputAdornment,
  TextField,
  Typography
} from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import CardSucursales from './CardSucursales';
import DialogNuevoSucursal from './newSucursal/DialogNuevoSucursal';
import useGM from '../../../../../hooks/useGM';
import { firestore } from '../../../../../contexts/FirebaseContext';

export default function DialogSucursales() {
  const [sucursalesList, setSucursalesList] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    function getData() {
      firestore.collection('crece_sucursales').onSnapshot((query) => {
        const data = [];
        query.forEach((item) => {
          data.push({ id: item.id, ...item.data() });
        });
        setSucursalesList(data);
      });
    }

    getData();
  }, []);

  return (
    <Box>
      <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Sucursales
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} sucursalesList={sucursalesList} />
    </Box>
  );
}

function DialogBody({ open, onClose, sucursalesList }) {
  const { loaded } = useGM();

  const handleClose = () => {
    onClose(false);
  };

  if (!loaded) {
    return <Typography>Cargando</Typography>;
  }

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="xl"
      fullWidth
    >
      <DialogTitle id="alert-dialog-title">Sucursales</DialogTitle>
      <DialogContent>
        <Box sx={{ marginTop: '15px', marginBottom: '15px', display: 'flex', justifyContent: 'end' }}>
          <DialogNuevoSucursal />
        </Box>
        <Box sx={{ marginBottom: '15px' }}>
          <TextField
            label="Buscar"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Icon icon="eva:search-fill" />
                </InputAdornment>
              )
            }}
          />
        </Box>

        <Grid container spacing={2}>
          {sucursalesList.map((item) => (
            <Grid key={item.id} item xs={12} sm={6} md={4} lg={3}>
              <CardSucursales dataItem={item} />
            </Grid>
          ))}
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
