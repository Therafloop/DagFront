import React, { useEffect, useState } from 'react';
import { Box, Card, InputAdornment, Stack, styled, TextField, Typography, useTheme } from '@mui/material';
import PlacesAutocomplete, { geocodeByAddress, geocodeByPlaceId, getLatLng } from 'react-places-autocomplete';
import { LoadingButton } from '@mui/lab';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { firestore } from '../../../../../../contexts/FirebaseContext';

const CuztomBox = styled(Box)(() => ({
  width: '100%'
}));

const RegisterSchema = Yup.object().shape({
  sucursalName: Yup.string().required('Campo requerido'),
  numCalle: Yup.string().required('Campo requerido'),
  calle: Yup.string().required('Campo requerido'),
  colonia: Yup.string().required('Campo requerido'),
  ciudad: Yup.string().required('Campo requerido'),
  estado: Yup.string().required('Campo requerido'),
  codPost: Yup.string().required('Campo requerido'),
  pais: Yup.string().required('Campo requerido')
});

function SucursalForm({ handleActualMarker, handleClose, dataItem, action = 'create' }) {
  const [address, setAddress] = useState('');
  const [placeId, setPlaceId] = useState('');
  const [coordinates, setCoordinates] = useState({
    lat: null,
    lng: null
  });
  const theme = useTheme();

  const initialValues = {
    sucursalName: dataItem?.sucursalName || '',
    numCalle: dataItem?.numCalle || '',
    calle: dataItem?.calle || '',
    colonia: dataItem?.colonia || '',
    ciudad: dataItem?.ciudad || '',
    estado: dataItem?.estado || '',
    codPost: dataItem?.codPost || '',
    pais: dataItem?.pais || ''
  };

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors, isSubmitting }
  } = useForm({
    resolver: yupResolver(RegisterSchema),
    defaultValues: initialValues
  });

  const extractUbication = (place) => {
    const ubic = {
      numCalle: '',
      calle: '',
      colonia: '',
      ciudad: '',
      estado: '',
      codPost: '',
      pais: ''
    };

    if (!Array.isArray(place?.address_components)) {
      return ubic;
    }

    place.address_components.forEach((component) => {
      const { types } = component;
      const value = component.long_name;

      if (types.includes('street_number')) {
        ubic.numCalle = value;
      }
      if (types.includes('route')) {
        ubic.calle = value;
      }
      if (types.includes('sublocality_level_1')) {
        ubic.colonia = value;
      }
      if (types.includes('locality')) {
        ubic.ciudad = value;
      }
      if (types.includes('administrative_area_level_1')) {
        ubic.estado = value;
      }

      if (types.includes('administrative_area_level_2')) {
        ubic.estado = value;
      }

      if (types.includes('postal_code')) {
        ubic.codPost = value;
      }

      if (types.includes('country')) {
        ubic.pais = value;
      }
    });

    return ubic;
  };

  const handleSelect = async (value) => {
    const results = await geocodeByAddress(value);
    const latLng = await getLatLng(results[0]);

    setAddress(value);
    setPlaceId(results[0]?.place_id);
    // latitud y longitud para estado actual y para el mapa
    setCoordinates(latLng);
    handleActualMarker(latLng);
    // ----------------
    const ubicationObj = extractUbication(results[0]);
    console.log(results, latLng, ubicationObj);

    setValue('numCalle', ubicationObj.numCalle);
    setValue('calle', ubicationObj.calle);
    setValue('colonia', ubicationObj.colonia);
    setValue('ciudad', ubicationObj.ciudad);
    setValue('estado', ubicationObj.estado);
    setValue('codPost', ubicationObj.codPost);
    setValue('pais', ubicationObj.pais);
  };

  const onSubmit = async (dataForm) => {
    // console.log(obj);

    if (action === 'create') {
      const obj = {
        ...dataForm,
        coordinates,
        placeId,
        created_at: new Date(),
        updated_at: new Date(),
        status: 'active'
      };
      await firestore.collection('crece_sucursales').add(obj);
      reset();
      handleClose();
    }

    if (action === 'update') {
      const obj = {
        ...dataForm,
        coordinates,
        placeId,
        updated_at: new Date()
      };
      console.log(obj);
      await firestore.collection('crece_sucursales').doc(dataItem.id).update(obj);
    }
  };

  useEffect(() => {
    if (dataItem) {
      setCoordinates(dataItem.coordinates);
      setPlaceId(dataItem.placeId);
    }
  }, [dataItem]);
  return (
    <Card sx={{ padding: '10px' }}>
      <PlacesAutocomplete value={address} onChange={setAddress} onSelect={handleSelect}>
        {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
          <div>
            <TextField
              // size="small"
              label="Ingrese la direccion"
              fullWidth
              {...getInputProps({ placeholder: 'Ubicación' })}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LocationOnIcon />
                  </InputAdornment>
                )
              }}
            />
            <Box sx={{ position: 'relative' }}>
              {loading ? <Typography>loading ...</Typography> : null}

              <Card sx={{ position: 'absolute', zIndex: '1000', padding: '5px', width: '100%' }}>
                {suggestions.map((suggestion, i) => {
                  const style = {
                    // eslint-disable-next-line no-nested-ternary
                    backgroundColor: suggestion.active
                      ? theme.palette.mode === 'light'
                        ? theme.palette.grey[300]
                        : theme.palette.grey[700]
                      : theme.palette.mode === 'dark'
                      ? '#1A2027'
                      : '#fff',
                    cursor: 'pointer',
                    color: theme.palette.text
                  };
                  return (
                    <Typography fontSize="15px" key={i} {...getSuggestionItemProps(suggestion, { style })}>
                      {suggestion.description}
                    </Typography>
                  );
                })}
              </Card>
            </Box>
          </div>
        )}
      </PlacesAutocomplete>

      <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ width: '100%', marginTop: '15px' }}>
        <Box sx={{ marginBottom: '10px' }}>
          <TextField
            InputLabelProps={{
              shrink: true
            }}
            fullWidth
            label="Nombre Sucursal"
            {...register('sucursalName')}
          />
          {errors.sucursalName && (
            <Typography color="error" fontSize="13px">
              {errors?.sucursalName?.message}
            </Typography>
          )}
        </Box>
        <Stack sx={{ marginBottom: '10px' }} direction={{ sm: 'column', md: 'row' }} spacing={2}>
          <CuztomBox>
            <TextField
              InputLabelProps={{
                shrink: true
              }}
              fullWidth
              label="Calle"
              {...register('calle')}
            />
            {errors.sucursalName && (
              <Typography color="error" fontSize="13px">
                {errors?.calle?.message}
              </Typography>
            )}
          </CuztomBox>
          <CuztomBox>
            <TextField
              InputLabelProps={{
                shrink: true
              }}
              fullWidth
              label="Num. calle"
              {...register('numCalle')}
            />
            {errors.sucursalName && (
              <Typography color="error" fontSize="13px">
                {errors?.numCalle?.message}
              </Typography>
            )}
          </CuztomBox>
        </Stack>
        <Stack sx={{ marginBottom: '10px' }} direction={{ sm: 'column', md: 'row' }} spacing={2}>
          <CuztomBox>
            <TextField
              InputLabelProps={{
                shrink: true
              }}
              fullWidth
              label="Colonia"
              {...register('colonia')}
            />
            {errors.sucursalName && (
              <Typography color="error" fontSize="13px">
                {errors?.colonia?.message}
              </Typography>
            )}
          </CuztomBox>
          <CuztomBox>
            <TextField
              InputLabelProps={{
                shrink: true
              }}
              fullWidth
              label="Ciudad"
              {...register('ciudad')}
            />
            {errors.sucursalName && (
              <Typography color="error" fontSize="13px">
                {errors?.ciudad?.message}
              </Typography>
            )}
          </CuztomBox>
        </Stack>
        <Stack sx={{ marginBottom: '10px' }} direction={{ sm: 'column', md: 'row' }} spacing={2}>
          <CuztomBox>
            <TextField
              InputLabelProps={{
                shrink: true
              }}
              fullWidth
              label="Estado"
              {...register('estado')}
            />
            {errors.sucursalName && (
              <Typography color="error" fontSize="13px">
                {errors?.estado?.message}
              </Typography>
            )}
          </CuztomBox>
          <CuztomBox>
            <TextField
              InputLabelProps={{
                shrink: true
              }}
              fullWidth
              label="Post. Code"
              {...register('codPost')}
            />
            {errors.sucursalName && (
              <Typography color="error" fontSize="13px">
                {errors?.codPost?.message}
              </Typography>
            )}
          </CuztomBox>
        </Stack>
        <Box sx={{ marginBottom: '10px' }}>
          <TextField
            InputLabelProps={{
              shrink: true
            }}
            disabled
            fullWidth
            label="Pais"
            {...register('pais')}
          />
          {errors.sucursalName && (
            <Typography color="error" fontSize="13px">
              {errors?.pais?.message}
            </Typography>
          )}
        </Box>

        <LoadingButton loading={isSubmitting} type="submit" variant="contained" fullWidth>
          Guardar
        </LoadingButton>
      </Box>
    </Card>
  );
}

export default SucursalForm;
