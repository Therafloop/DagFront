import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import SucursalForm from './SucursalForm';
import SucursalMap from './SucursalMap';

export default function DialogNuevoSucursal() {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <Button
        variant="contained"
        color="warning"
        onClick={() => setOpenDialog(true)}
        startIcon={<Icon icon="eva:plus-fill" />}
      >
        Nueva sucursal
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </>
  );
}

function DialogBody({ open, onClose }) {
  const [actualMarkerPos, setActualMarker] = useState(null);

  const handleActualMarker = (objData) => {
    setActualMarker(objData);
  };

  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      <DialogTitle id="alert-dialog-title">Nueva sucursal</DialogTitle>
      <DialogContent>
        <Box sx={{ marginTop: '15px' }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <SucursalForm handleActualMarker={handleActualMarker} handleClose={handleClose} />
            </Grid>
            <Grid item xs={12} md={6}>
              <SucursalMap actualMarkerPos={actualMarkerPos} />
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
