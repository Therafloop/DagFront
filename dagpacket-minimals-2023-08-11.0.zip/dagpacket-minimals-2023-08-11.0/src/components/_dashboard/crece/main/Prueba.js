// import { Input, TextField } from '@mui/material';
// import React, { useRef, useState } from 'react';
// import Autocomplete, { usePlacesWidget } from 'react-google-autocomplete';
// import GooglePlacesAutocomplete from 'react-google-places-autocomplete';

// const GOOGLE_API_KEY = 'AIzaSyCtHqyG9wARRigzf7lAbweiJ9xR9NHuTZg';

// function Prueba() {
//   const [placeValue, setPlaceValue] = useState(null);
//   const [placeValue2, setPlaceValue2] = useState(null);
//   console.log(placeValue, placeValue2);

//   const inputRef = useRef(null);
//   const [country, setCountry] = useState('pe');
//   const { ref: materialRef } = usePlacesWidget({
//     apiKey: GOOGLE_API_KEY,
//     onPlaceSelected: (place) => console.log(place),
//     inputAutocompleteValue: 'country',
//     options: {
//       componentRestrictions: { country }
//     }
//   });

//   return (
//     <>
//       {/* <div style={{ width: '550px' }}>
//         <span style={{ color: 'black' }}>Material UI</span>
//         <Input
//           fullWidth
//           color="secondary"
//           inputComponent={({ inputRef, onFocus, onBlur, ...props }) => (
//             <Autocomplete apiKey={GOOGLE_API_KEY} {...props} onPlaceSelected={(selected) => setPlaceValue2(selected)} />
//           )}
//         />
//       </div>

//       <div style={{ width: '550px', marginTop: '20px' }}>
//         <span style={{ color: 'black' }}>Material UI</span>
//         <TextField fullWidth color="secondary" variant="outlined" inputRef={materialRef} />
//       </div> */}

//       <div>
//         <GooglePlacesAutocomplete
//           apiKey={GOOGLE_API_KEY}
//           selectProps={{
//             value: placeValue,
//             onChange: setPlaceValue
//           }}
//         />
//       </div>
//     </>
//   );
// }

// export default Prueba;
