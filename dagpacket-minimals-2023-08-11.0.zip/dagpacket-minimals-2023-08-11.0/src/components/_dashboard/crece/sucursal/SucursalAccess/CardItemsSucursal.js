import React from 'react';
import { Box, Card, Divider, Typography } from '@mui/material';
import { useNavigate } from 'react-router';
import { useDispatch } from 'react-redux';
import { getActualSucursal } from '../../../../../redux/slices/dagpacketCrece';

function CardItemsSucursal({ dataSucursal = {} }) {
  const navigate = useNavigate();

  const { id, numCalle, calle, colonia, ciudad, estado, codPost, pais, sucursalName } = dataSucursal;

  const redirectToSucursal = () => {
    navigate(
      `/dashboard/crece/sucursal?sucursalId=${id}&sucursalName=${sucursalName}&estado=${estado}&colonia=${colonia}&ciudad=${ciudad}&calle=${calle}&numCalle=${numCalle}`
    );
  };
  return (
    <Card
      onClick={redirectToSucursal}
      sx={{ padding: '15px', cursor: 'pointer', ':hover': { scale: '1.05', transition: '.2s' } }}
    >
      <Typography variant="subtitle1">{sucursalName}</Typography>
      <Divider />
      <Box sx={{ marginTop: '10px' }}>
        <Typography>
          {calle} {numCalle || ''}
        </Typography>
        <Typography>
          {estado} - {colonia} - {ciudad}{' '}
        </Typography>
      </Box>
    </Card>
  );
}

export default CardItemsSucursal;
