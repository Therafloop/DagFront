import { Icon } from '@iconify/react';
import { Box, Grid, InputAdornment, TextField } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { firestore } from '../../../../../contexts/FirebaseContext';
import CardItemsSucursal from './CardItemsSucursal';

function SucursalToAccess() {
  const [sucursalesList, setSucursalesList] = useState([]);
  const [searchItem, setSearchItem] = useState('');

  const filteredItems = sucursalesList?.filter((item) => {
    if (searchItem === '') {
      return item;
    }
    if (item?.sucursalName.toLowerCase().includes(searchItem.toLowerCase())) {
      return item;
    }
    return false;
  });

  useEffect(() => {
    function getData() {
      firestore.collection('crece_sucursales').onSnapshot((query) => {
        const data = [];
        query.forEach((item) => {
          data.push({ id: item.id, ...item.data() });
        });
        setSucursalesList(data);
        console.log(data);
      });
    }

    getData();
  }, []);
  return (
    <Box>
      <TextField
        value={searchItem}
        onChange={(e) => setSearchItem(e.target.value)}
        label="Buscar sucursal"
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Icon icon="eva:search-fill" />
            </InputAdornment>
          )
        }}
      />

      <Box marginTop="15px">
        <Grid container spacing={2}>
          {filteredItems.map((item) => (
            <Grid key={item.id} item xs={12} sm={6} md={4} lg={3}>
              <CardItemsSucursal dataSucursal={item} />
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  );
}

export default SucursalToAccess;
