import React, { useCallback, useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { UploadMultiFile } from '../../../../../../../upload';
import { firestore, storage as st } from '../../../../../../../../contexts/FirebaseContext';
import { LoadingButton } from '@mui/lab';
import {
  segimientoPaletizadoCrece,
  statusPaletizadoCrece
} from '../../../../../../../../constants/crece/paletizadoConst';

export default function DialogCerrarCostal({ dataPaletizado }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <Button variant="contained" onClick={() => setOpenDialog(true)}>
        Cerrar costal
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} dataPaletizado={dataPaletizado} />
    </>
  );
}

function DialogBody({ open, onClose, dataPaletizado }) {
  const [loadingImages, setLoadingImages] = useState(false);
  const [loading, setLoading] = useState(false);
  const [files, setFiles] = useState([]);

  console.log(dataPaletizado);

  const handleClose = () => {
    onClose(false);
  };

  const handleDropMultiFile = useCallback(
    (acceptedFiles) => {
      setFiles(
        acceptedFiles.map((file) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file)
          })
        )
      );
    },
    [setFiles]
  );

  const handleRemoveAll = () => {
    setFiles([]);
  };

  const handleRemove = (file) => {
    const filteredItems = files.filter((_file) => _file !== file);
    setFiles(filteredItems);
  };

  // eslint-disable-next-line consistent-return
  const uploadMedia = useCallback(async () => {
    const urlsArr = [];

    if (files.length > 0) {
      setLoadingImages(true);
      await Promise.all(
        files.map(async (file) => {
          const refF = st.ref().child(`crece_evidencias/${file.name}`);
          await refF.put(file);
          const url = await refF.getDownloadURL();

          urlsArr.push(url);
        })
      );

      setFiles([]);
      setLoadingImages(false);
      return urlsArr;
    }
  }, [files]);

  const handleCerrarPaquete = async () => {
    const evidenciaArr = await uploadMedia();
    const obj = {
      status: statusPaletizadoCrece.enEspera,
      updated_at: new Date(),
      evidenciasPaletizado: evidenciaArr
    };

    setLoading(true);

    try {
      await firestore.collection('crece_paletizado').doc(dataPaletizado.id).update(obj);

      setLoading(false);
      handleClose();
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle>
      <DialogContent>
        <Box>
          <UploadMultiFile
            showPreview
            files={files}
            onDrop={handleDropMultiFile}
            onRemove={handleRemove}
            onRemoveAll={handleRemoveAll}
            showBtn={false}
            // error={Boolean(touched.images && errors.images)}
          />
          <Box sx={{ display: 'flex', gap: '15px' }}>
            <Button disabled={loadingImages} variant="contained" color="info">
              Quitar todo
            </Button>
            <LoadingButton onClick={handleCerrarPaquete} loading={loadingImages} variant="contained">
              Cerrar el costal
            </LoadingButton>
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
