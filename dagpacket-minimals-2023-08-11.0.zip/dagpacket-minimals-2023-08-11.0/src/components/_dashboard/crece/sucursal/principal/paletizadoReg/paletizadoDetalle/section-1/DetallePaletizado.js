import React from 'react';
import { Box, Button, Grid, styled, Typography } from '@mui/material';
import { fDateTime } from '../../../../../../../../utils/formatTime';
import { statusPaletizadoCrece } from '../../../../../../../../constants/crece/paletizadoConst';
import { BlobProvider } from '@react-pdf/renderer';
import PaletizadoRegistradoRecibo from '../../../../../docs/PaletizadoRegistradoRecibo';
import DialogCerrarCostal from './DialogCerrarCostal';
import DialogModificarPaq from './DialogModificarPaq';

const CuztomBox = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '150px 1fr',
  marginBottom: '5px'
  // alignItems: 'center'
}));

const CuztomBox2 = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '100px 1fr',
  marginBottom: '5px'
}));

function DetallePaletizado({ dataItem }) {
  console.log(dataItem);
  return (
    <Box>
      <Box>
        <CuztomBox>
          <Typography fontSize="15px">Sucursal origen:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {dataItem.origenSucursalName} - {dataItem?.origenSucursalCalle} {dataItem?.origenSucursalNumCalle}{' '}
            {dataItem?.origenSucursalColonia} {dataItem?.origenSucursalCiudad}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Sucursal destino:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {dataItem?.destinoSucursalName} - {dataItem?.destinoSucursalCalle} {dataItem?.destinoSucursalNumCalle}{' '}
            {dataItem?.destinoSucursalColonia} {dataItem?.destinoSucursalCiudad}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Fecha:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {dataItem?.created_at ? fDateTime(dataItem?.created_at?.toDate()) : ''}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Num. paquetes:</Typography>
          <Box sx={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <Typography fontSize="15px" variant="subtitle1">
              {dataItem?.paletizadoItems.length}
            </Typography>

            {dataItem.status === statusPaletizadoCrece.pendienteCerrar && (
              <DialogModificarPaq dataPaletizado={dataItem} />
            )}
          </Box>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Codigo costal:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {dataItem?.paletizadoCode}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Status:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {dataItem?.status}
          </Typography>
        </CuztomBox>
        {dataItem.status !== statusPaletizadoCrece.pendienteCerrar ? (
          <CuztomBox>
            <Typography fontSize="15px">Recibo:</Typography>
            <Box>
              <BlobProvider document={<PaletizadoRegistradoRecibo data={dataItem} />}>
                {({ url }) => (
                  <Button variant="contained" href={url} target="_blank" rel="noreferrer">
                    Recibo
                  </Button>
                )}
              </BlobProvider>
            </Box>
          </CuztomBox>
        ) : null}
        {dataItem.status === statusPaletizadoCrece.pendienteCerrar ? (
          <CuztomBox>
            <Typography fontSize="15px">Recibo:</Typography>
            <Box>
              <DialogCerrarCostal dataPaletizado={dataItem} />
            </Box>
          </CuztomBox>
        ) : null}
        {/* <Grid container spacing={1}>
          <Grid item xs={12} md={12}>
            <Typography fontSize="15px">
              Sucursal Origen:{' '}
              <Typography variant="subtitle1" component="span">
                {dataItem?.origenSucursalName}
              </Typography>
            </Typography>
          </Grid>
          <Grid item xs={12} md={12}>
            <Typography fontSize="15px">
              Sucursal Destino:{' '}
              <Typography variant="subtitle1" component="span">
                {dataItem?.destinoSucursalName}
              </Typography>
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography fontSize="15px">
              Codigo costal:{' '}
              <Typography variant="subtitle1" component="span">
                {dataItem?.paletizadoCode}
              </Typography>
            </Typography>
            <Typography fontSize="15px">
              Num. paquetes:{' '}
              <Typography variant="subtitle1" component="span">
                {dataItem?.paletizadoItems.length}
              </Typography>
            </Typography>
          </Grid>
        </Grid> */}
      </Box>
    </Box>
  );
}

export default DetallePaletizado;
