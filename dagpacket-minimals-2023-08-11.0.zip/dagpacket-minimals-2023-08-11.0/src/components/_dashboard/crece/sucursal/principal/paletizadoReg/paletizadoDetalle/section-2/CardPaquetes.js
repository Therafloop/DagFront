import { Box, Card, Typography } from '@mui/material';
import React from 'react';

function CardPaquetes({ paquete }) {
  return (
    <Card sx={{ padding: '10px', display: 'flex', gap: '10px', justifyContent: 'space-between', alignItems: 'center' }}>
      <Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
          <Typography fontSize="14px">De:</Typography>
          <Typography fontSize="14px" variant="subtitle2">
            {paquete.remitenteNombre}
          </Typography>
        </Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
          <Typography fontSize="14px">Para:</Typography>
          <Typography fontSize="14px" variant="subtitle2">
            {paquete.destinatarioNombre}
          </Typography>
        </Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
          <Typography fontSize="12px">Destino:</Typography>
          <Typography fontSize="12px" variant="subtitle2">
            {paquete.destinoSucursalName}
          </Typography>
        </Box>
      </Box>
    </Card>
  );
}

export default CardPaquetes;
