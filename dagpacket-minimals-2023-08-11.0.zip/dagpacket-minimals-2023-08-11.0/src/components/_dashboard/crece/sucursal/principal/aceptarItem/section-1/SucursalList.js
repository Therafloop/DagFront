import React, { useEffect, useState } from 'react';
import { Box, TextField } from '@mui/material';
import { firestore } from '../../../../../../../contexts/FirebaseContext';
import CardSucursalItem from './CardSucursalItem';
import { useLocation } from 'react-router';

function SucursalList() {
  const [sucursalesList, setSucursalesList] = useState([]);
  const [dataSearch, setDataSearch] = useState('');
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);

  const sucursalId = queryParams.get('sucursalId');

  useEffect(() => {
    function getData() {
      firestore.collection('crece_sucursales').onSnapshot((query) => {
        const data = [];
        query.forEach((item) => {
          data.push({ id: item.id, ...item.data() });
        });

        console.log(data);
        setSucursalesList(data.filter((suc) => suc.id !== sucursalId));
      });
    }

    getData();
  }, [sucursalId]);

  const filteredByDataSearch = sucursalesList.filter((item) => {
    if (dataSearch === '') {
      return item;
    }
    if (item?.sucursalName?.toLowerCase().includes(dataSearch)) {
      return item;
    }
    return false;
  });

  return (
    <Box>
      <TextField
        value={dataSearch}
        onChange={(e) => setDataSearch(e.target.value)}
        size="small"
        label="Buscar sucursal"
      />

      <Box sx={{ marginTop: '10px' }}>
        {filteredByDataSearch.map((sucursal) => (
          <CardSucursalItem key={sucursal.id} sucursal={sucursal} />
        ))}
      </Box>
    </Box>
  );
}

export default SucursalList;
