import React from 'react';
import { Box, Button, TextField, Typography } from '@mui/material';
import * as yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { getExtraData } from '../../../../../../../redux/slices/dagpacketCrece';
import { statusItemCrece } from '../../../../../../../constants/crece/itemConst';
import { responsableTypeCrece } from '../../../../../../../constants/crece/paletizadoConst';

const schema = yup.object({
  claveNip: yup.string().required('Este campo es requerido'),
  descripcionContenido: yup.string().required('Este campo es requerido'),
  observaciones: yup.string()
});

function ExtraInfoForm({ handleNext }) {
  const { infoAceptarItemSucursal } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      claveNip: infoAceptarItemSucursal.claveNip || '',
      observaciones: infoAceptarItemSucursal.observaciones || '',
      descripcionContenido: infoAceptarItemSucursal.descripcionContenido || ''
    }
  });

  const onSubmit = (dataForm) => {
    const obj = {
      ...dataForm,
      responsableActualId: infoAceptarItemSucursal.origenSucursalId,
      responsableType: responsableTypeCrece.sucursal,
      status: statusItemCrece.recepcionado
    };
    dispatch(getExtraData(obj));
    handleNext();
    console.log(obj);
  };
  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Clave NIP" {...register('claveNip')} />
        {errors.claveNip && (
          <Typography fontSize="13px" color="error">
            {errors.claveNip?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Descripcion del contenido" {...register('descripcionContenido')} />
        {errors.descripcionContenido && (
          <Typography fontSize="13px" color="error">
            {errors.descripcionContenido?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Observaciones" {...register('observaciones')} multiline rows={4} />
        {errors.observaciones && (
          <Typography fontSize="13px" color="error">
            {errors.observaciones?.message}
          </Typography>
        )}
      </Box>

      <Button type="submit" variant="contained" fullWidth>
        Guardar
      </Button>
    </Box>
  );
}

export default ExtraInfoForm;
