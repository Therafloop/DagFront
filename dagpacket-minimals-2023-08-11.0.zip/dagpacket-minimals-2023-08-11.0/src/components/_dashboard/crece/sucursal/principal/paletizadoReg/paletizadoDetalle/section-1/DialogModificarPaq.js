import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import ListaPaqDisponibles from './ListaPaqDisponibles';
import ListaPaqPaletizado from './ListaPaqPaletizado';

export default function DialogModificarPaq({ dataPaletizado }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      {/* <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Abrir dialogo
      </Button> */}
      <IconButton color="error" size="small" onClick={() => setOpenDialog(true)}>
        <Icon icon="ph:plus-circle-fill" />
      </IconButton>
      <DialogBody open={openDialog} onClose={setOpenDialog} dataPaletizado={dataPaletizado} />
    </>
  );
}

function DialogBody({ open, onClose, dataPaletizado }) {
  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <ListaPaqDisponibles dataPaletizado={dataPaletizado} />

          <ListaPaqPaletizado dataPaletizado={dataPaletizado} />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
