import { Box, Button, ButtonGroup, Typography } from '@mui/material';
import React, { useState } from 'react';
import RegistrarItemFlujo from './aceptarItem/RegistrarItemFlujo';
import ListaItemsSucursal from './items/ListaItemsSucursal';
import PaletizadoFlujo from './paletizado/PaletizadoFlujo';
import ListaPaletizado from './paletizadoReg/ListaPaletizado';

function SucursalPrincipalPage() {
  const [section, setSection] = useState(1);

  return (
    <>
      <Box sx={{ width: '100%', textAlign: 'center', marginBottom: '15px' }}>
        <ButtonGroup variant="contained" aria-label="outlined primary button group">
          <Button onClick={() => setSection(1)}>Recepcionar paquete</Button>
          <Button onClick={() => setSection(2)}>Lista de paquetes</Button>
          <Button onClick={() => setSection(3)}>Crear costal</Button>
          <Button onClick={() => setSection(4)}>Lista costal</Button>
        </ButtonGroup>
      </Box>

      <Box>
        {section === 1 && <RegistrarItemFlujo />}
        {section === 2 && <ListaItemsSucursal />}
        {section === 3 && <PaletizadoFlujo />}
        {section === 4 && <ListaPaletizado />}
      </Box>
    </>
  );
}

export default SucursalPrincipalPage;
