import React, { useState } from 'react';
import { Box, Card, Divider, Grid, styled, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { LoadingButton } from '@mui/lab';
import { getAcceptedItemId, resetInfoAcceptedItem } from '../../../../../../../redux/slices/dagpacketCrece';
import { firestore } from '../../../../../../../contexts/FirebaseContext';
import { useSnackbar } from 'notistack';
import { segimientoItemCrece } from '../../../../../../../constants/crece/itemConst';
import { useLocation } from 'react-router';
import DialogPrintPdf from './DialogPrintPdf';

const CuztomBox = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '100px 1fr'
}));
const CuztomBox2 = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '180px 1fr'
}));

function ResumeItem({ handleReset }) {
  const [loading, setLoading] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [idItemAceptado, setIdItemAceptado] = useState(null);
  const { infoAceptarItemSucursal, actualSucursal } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);

  const {
    remitenteINE,
    remitenteNombre,
    remitenteApellidos,
    remitenteTelefono,
    remitenteEmail,
    destinatarioNombre,
    destinatarioApellidos,
    destinatarioTelefono,
    tipoServicio,
    observaciones,
    claveNip,
    destinoSucursalName,
    origenSucursalName,
    descripcionContenido
  } = infoAceptarItemSucursal;

  const acceptNewItem = async () => {
    console.log('aceptado');

    const obj = {
      ...infoAceptarItemSucursal,
      reception_date: new Date(),
      created_at: new Date(),
      updated_at: new Date()
    };

    setLoading(true);

    try {
      const res = await firestore.collection('crece_acceptedItems').add(obj);
      // console.log(res.id);

      const segObj = {
        itemId: res.id,
        statusItem: infoAceptarItemSucursal.status,
        registro: [
          {
            date: new Date(),
            status: segimientoItemCrece.recepcionadoSeg,
            sucursalName: actualSucursal.sucursalName,
            sucursalId: actualSucursal.id,
            descripcion: `Recepcionado en ${actualSucursal.sucursalName}`
          }
        ]
      };

      // console.log(segObj);
      await firestore.collection('crece_seguimientoItem').doc(res.id).set(segObj);

      // console.log('segimiento creado');
      enqueueSnackbar('Item aceptado', { variant: 'success' });
      setLoading(false);
      setIdItemAceptado(res.id);
      setOpenDialog(true);
      // dispatch(resetInfoAcceptedItem());
      // handleReset();
    } catch (error) {
      console.log(error);
      setLoading(false);
    }

    // console.log(obj);

    // dispatch(getAcceptedItemId());
    // handleNext();
  };
  return (
    <>
      <Card sx={{ padding: '15px' }}>
        <Typography textAlign="center" variant="h4">
          Resumen
        </Typography>
        <Box sx={{ display: 'flex', gap: '10px' }}>
          <Typography>Tipo envio:</Typography>
          <Typography variant="subtitle2">{tipoServicio}</Typography>
        </Box>
        <Divider />
        <Grid container spacing={1}>
          {/* remitente */}
          <Grid item xs={12} md={6}>
            <Box>
              <Typography variant="subtitle1">Remitente</Typography>
              <CuztomBox>
                <Typography fontSize="15px">Nombre:</Typography>
                <Typography fontSize="15px">
                  {remitenteNombre} {remitenteApellidos}
                </Typography>
              </CuztomBox>
              <CuztomBox>
                <Typography fontSize="15px">Telefono:</Typography>
                <Typography fontSize="15px">{remitenteTelefono}</Typography>
              </CuztomBox>
              <CuztomBox>
                <Typography fontSize="15px">Email:</Typography>
                <Typography fontSize="15px">{remitenteEmail}</Typography>
              </CuztomBox>
              <CuztomBox>
                <Typography fontSize="15px">INE:</Typography>
                <Typography fontSize="15px">{remitenteINE}</Typography>
              </CuztomBox>
            </Box>
          </Grid>

          {/* destinatario */}
          <Grid item xs={12} md={6}>
            <Box>
              <Typography variant="subtitle1">Destinatario</Typography>
              <CuztomBox>
                <Typography fontSize="15px">Nombre:</Typography>
                <Typography fontSize="15px">
                  {destinatarioNombre} {destinatarioApellidos}
                </Typography>
              </CuztomBox>
              <CuztomBox>
                <Typography fontSize="15px">Telefono:</Typography>
                <Typography fontSize="15px">{destinatarioTelefono}</Typography>
              </CuztomBox>
              {/* <CuztomBox>
              <Typography fontSize="15px">Email:</Typography>
              <Typography fontSize="15px">asdasd@fsafs.com</Typography>
            </CuztomBox> */}
            </Box>
          </Grid>
        </Grid>

        <Divider />

        <Box sx={{ marginTop: '10px' }}>
          <CuztomBox2>
            <Typography fontSize="15px">Sucursal de origen:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {origenSucursalName}
            </Typography>
          </CuztomBox2>
          <CuztomBox2>
            <Typography fontSize="15px">Sucursal de destino:</Typography>
            <Typography fontSize="15px" variant="subtitle2">
              {destinoSucursalName}
            </Typography>
          </CuztomBox2>
        </Box>

        <Divider />

        <Box sx={{ marginTop: '10px' }}>
          <CuztomBox2>
            <Typography fontSize="15px">Clave NIP:</Typography>
            <Typography fontSize="15px">{claveNip}</Typography>
          </CuztomBox2>
          <CuztomBox2>
            <Typography fontSize="15px">Contenido:</Typography>
            <Typography fontSize="15px">{descripcionContenido}</Typography>
          </CuztomBox2>
          <CuztomBox2>
            <Typography fontSize="15px">Observaciones:</Typography>
            <Typography fontSize="15px">{observaciones}</Typography>
          </CuztomBox2>
        </Box>

        <LoadingButton
          loading={loading}
          sx={{ marginTop: '15px' }}
          fullWidth
          variant="contained"
          onClick={acceptNewItem}
        >
          Guardar
        </LoadingButton>
      </Card>

      <DialogPrintPdf
        open={openDialog}
        onClose={setOpenDialog}
        idItemAceptado={idItemAceptado}
        handleReset={handleReset}
      />
    </>
  );
}

export default ResumeItem;
