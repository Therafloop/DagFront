import React, { useState } from 'react';
import { Box, Card, IconButton, LinearProgress, Typography } from '@mui/material';
import { Icon } from '@iconify/react';
import { firestore } from '../../../../../../../../contexts/FirebaseContext';
import { statusItemCrece } from '../../../../../../../../constants/crece/itemConst';
import { responsableTypeCrece } from '../../../../../../../../constants/crece/paletizadoConst';
import { useSelector } from 'react-redux';

function CardPaquetes({ paquete, action, dataPaletizado }) {
  const [loading, setLoading] = useState(false);
  const { actualSucursal } = useSelector((state) => state.dagpacketCrece);

  const addPaquetePaletizado = async () => {
    const newObj = {
      id: paquete.id,
      destinatarioNombre: paquete.destinatarioNombre,
      destinoSucursalName: paquete.destinoSucursalName,
      remitenteNombre: paquete.remitenteNombre
    };

    setLoading(true);
    try {
      await firestore
        .collection('crece_paletizado')
        .doc(dataPaletizado.id)
        .update({
          updated_at: new Date(),
          paletizadoItems: [...dataPaletizado.paletizadoItems, newObj]
        });

      await firestore.collection('crece_acceptedItems').doc(paquete.id).update({
        status: statusItemCrece.esperandoTransporte,
        responsableActualId: actualSucursal.id,
        responsableType: responsableTypeCrece.sucursal
      });

      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.log(error);
    }
  };
  return (
    <>
      <Card
        sx={{ padding: '10px', display: 'flex', gap: '10px', justifyContent: 'space-between', alignItems: 'center' }}
      >
        <Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
            <Typography fontSize="11px">De:</Typography>
            <Typography fontSize="12px" variant="subtitle2">
              {paquete.remitenteNombre}
            </Typography>
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
            <Typography fontSize="12px">Para:</Typography>
            <Typography fontSize="12px" variant="subtitle2">
              {paquete.destinatarioNombre}
            </Typography>
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
            <Typography fontSize="11px">Destino:</Typography>
            <Typography fontSize="11px" variant="subtitle2">
              {paquete.destinoSucursalName}
            </Typography>
          </Box>
        </Box>

        <Box>
          {action === 'agregar' && (
            <IconButton color="info" onClick={addPaquetePaletizado}>
              <Icon icon="ph:plus-circle-fill" />
            </IconButton>
          )}
        </Box>
      </Card>
      {loading && <LinearProgress />}
    </>
  );
}

export default CardPaquetes;
