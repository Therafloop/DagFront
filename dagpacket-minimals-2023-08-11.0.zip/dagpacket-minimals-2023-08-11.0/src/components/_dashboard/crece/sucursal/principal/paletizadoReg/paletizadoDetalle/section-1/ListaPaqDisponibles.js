import { Card, Divider, Grid, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { statusItemCrece } from '../../../../../../../../constants/crece/itemConst';
import { firestore } from '../../../../../../../../contexts/FirebaseContext';
import CardPaquetes from './CardPaquete';

function ListaPaqDisponibles({ dataPaletizado }) {
  const [dataList, setDataList] = useState([]);
  const { actualSucursal } = useSelector((state) => state.dagpacketCrece);

  console.log(dataPaletizado);

  useEffect(() => {
    async function getData() {
      await firestore
        .collection('crece_acceptedItems')
        .where('responsableActualId', '==', actualSucursal.id)
        .where('status', '==', statusItemCrece.recepcionado)
        .orderBy('reception_date', 'desc')
        // .limit(200)
        .onSnapshot((snapshot) => {
          const data = snapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
          console.log(data);
          setDataList(data);
        });
    }

    if (actualSucursal) {
      getData();
    }
  }, [actualSucursal]);

  return (
    <Card sx={{ padding: '10px' }}>
      <Typography>Paquetes disponibles</Typography>
      <Divider />

      <Grid container spacing={1} marginTop="10px">
        {dataList.map((paq) => (
          <Grid item xs={12} sm={6} lg={3} key={paq.id}>
            <CardPaquetes paquete={paq} action="agregar" dataPaletizado={dataPaletizado} />
          </Grid>
        ))}
      </Grid>
    </Card>
  );
}

export default ListaPaqDisponibles;
