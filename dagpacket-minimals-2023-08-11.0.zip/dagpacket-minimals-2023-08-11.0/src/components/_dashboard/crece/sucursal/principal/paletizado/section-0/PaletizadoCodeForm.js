import { yupResolver } from '@hookform/resolvers/yup';
import { Box, Button, Card, TextField, Typography } from '@mui/material';
import React from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { getPaletizadoCode } from '../../../../../../../redux/slices/dagpacketCrece';
import * as yup from 'yup';

const schema = yup.object({
  paletizadoCode: yup.string().required('Este campo es requerido')
});

function PaletizadoCodeForm({ handleNext }) {
  const { infoCrearPaletizado } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      paletizadoCode: infoCrearPaletizado.paletizadoCode || ''
    }
  });

  const onSubmit = (dataForm) => {
    dispatch(getPaletizadoCode(dataForm));
    console.log(dataForm);
    handleNext();
  };
  return (
    <Card sx={{ padding: '15px' }} component="form" onSubmit={handleSubmit(onSubmit)}>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Codigo" {...register('paletizadoCode')} />
        {errors.paletizadoCode && (
          <Typography fontSize="13px" color="error">
            {errors.paletizadoCode?.message}
          </Typography>
        )}
      </Box>

      <Button type="submit" variant="contained" fullWidth>
        Guardar
      </Button>
    </Card>
  );
}

export default PaletizadoCodeForm;
