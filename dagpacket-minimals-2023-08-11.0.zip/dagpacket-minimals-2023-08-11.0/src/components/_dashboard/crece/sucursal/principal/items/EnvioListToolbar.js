import PropTypes from 'prop-types';
import { Icon } from '@iconify/react';
import searchFill from '@iconify/icons-eva/search-fill';
import trash2Fill from '@iconify/icons-eva/trash-2-fill';
import roundFilterList from '@iconify/icons-ic/round-filter-list';
// material
import { useTheme, styled } from '@mui/material/styles';
import {
  Box,
  Toolbar,
  Tooltip,
  IconButton,
  Typography,
  OutlinedInput,
  InputAdornment,
  TextField,
  Menu,
  MenuItem,
  Button
} from '@mui/material';
import { useState } from 'react';
// import ReportePagosServiciosRecargas from '../../../../../docs/ReportePagosServiciosRecargas';

// ----------------------------------------------------------------------

const RootStyle = styled(Toolbar)(({ theme }) => ({
  height: 96,
  display: 'flex',
  justifyContent: 'space-between',
  padding: theme.spacing(0, 1, 0, 3)
}));

const SearchStyle = styled(OutlinedInput)(({ theme }) => ({
  width: 240,
  transition: theme.transitions.create(['box-shadow', 'width'], {
    easing: theme.transitions.easing.easeInOut,
    duration: theme.transitions.duration.shorter
  }),
  '&.Mui-focused': { width: 320, boxShadow: theme.customShadows.z8 },
  '& fieldset': {
    borderWidth: `1px !important`,
    borderColor: `${theme.palette.grey[500_32]} !important`
  }
}));

// ----------------------------------------------------------------------

EnvioListToolbar.propTypes = {
  numSelected: PropTypes.number,
  filterName: PropTypes.string,
  onFilterName: PropTypes.func
};

export default function EnvioListToolbar({
  numSelected,
  filterName,
  onFilterName,
  date,
  setDate,
  handleStatus,
  dataList,
  onDesdeDate,
  onHastaDate
}) {
  const theme = useTheme();
  const isLight = theme.palette.mode === 'light';

  // menu section---
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleDesdeDate = (value) => {
    onDesdeDate(value);
  };

  const handleHastaDate = (value) => {
    onHastaDate(value);
  };

  return (
    <RootStyle
      sx={{
        ...(numSelected > 0 && {
          color: isLight ? 'primary.main' : 'text.primary',
          bgcolor: isLight ? 'primary.lighter' : 'primary.dark'
        })
      }}
    >
      {numSelected > 0 ? (
        <Typography component="div" variant="subtitle1">
          {numSelected} selected
        </Typography>
      ) : (
        <SearchStyle
          value={filterName}
          onChange={onFilterName}
          placeholder="Buscar pago..."
          startAdornment={
            <InputAdornment position="start">
              <Box component={Icon} icon={searchFill} sx={{ color: 'text.disabled' }} />
            </InputAdornment>
          }
        />
      )}

      {/* <Tooltip title="Filtrar por fecha">
        <TextField type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </Tooltip> */}

      <Box sx={{ display: 'flex', gap: '10px' }}>
        <TextField
          type="date"
          label="Desde"
          onChange={(e) => handleDesdeDate(e.target.value)}
          InputLabelProps={{
            shrink: true
          }}
        />

        <TextField
          type="date"
          label="Hasta"
          onChange={(e) => handleHastaDate(e.target.value)}
          InputLabelProps={{
            shrink: true
          }}
        />
      </Box>

      {/* <Button variant="contained" onClick={getReporte}>
        Reporte
      </Button> */}

      {/* <ReportePagosServiciosRecargas dataList={dataList} /> */}

      <Tooltip title="Estado de envio">
        <IconButton
          id="basic-button"
          aria-controls={open ? 'basic-menu' : undefined}
          aria-haspopup="true"
          aria-expanded={open ? 'true' : undefined}
          onClick={handleClick}
        >
          <Icon icon={roundFilterList} />
        </IconButton>
      </Tooltip>

      {/* <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button'
        }}
      >
        <MenuItem onClick={() => handleStatus(null)}>Todos</MenuItem>
        <MenuItem onClick={() => handleStatus('recarga')}>Recarga</MenuItem>
        <MenuItem onClick={() => handleStatus('servicio')}>Servicio</MenuItem>
      </Menu> */}
    </RootStyle>
  );
}
