import React from 'react';
import { Box, Button, TextField, Typography } from '@mui/material';
import * as yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { getDestinatarioInfo } from '../../../../../../../redux/slices/dagpacketCrece';

const schema = yup.object({
  destinatarioNombre: yup.string().required('Este campo es requerido'),
  destinatarioApellidos: yup.string().required('Este campo es requerido'),
  destinatarioTelefono: yup.string().required('Este campo es requerido')
});

function DestinatarioForm({ handleNext }) {
  const { infoAceptarItemSucursal } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      destinatarioNombre: infoAceptarItemSucursal.destinatarioNombre || null,
      destinatarioApellidos: infoAceptarItemSucursal.destinatarioApellidos || null,
      destinatarioTelefono: infoAceptarItemSucursal.destinatarioTelefono || null
    }
  });

  const onSubmit = (dataForm) => {
    dispatch(getDestinatarioInfo(dataForm));
    handleNext();
    console.log(dataForm);
  };
  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Nombre" {...register('destinatarioNombre')} />
        {errors.destinatarioNombre && (
          <Typography fontSize="13px" color="error">
            {errors.destinatarioNombre?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Apellidos" {...register('destinatarioApellidos')} />
        {errors.destinatarioApellidos && (
          <Typography fontSize="13px" color="error">
            {errors.destinatarioApellidos?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Telefono" {...register('destinatarioTelefono')} />
        {errors.destinatarioTelefono && (
          <Typography fontSize="13px" color="error">
            {errors.destinatarioTelefono?.message}
          </Typography>
        )}
      </Box>

      <Button type="submit" variant="contained" fullWidth>
        Guardar
      </Button>
    </Box>
  );
}

export default DestinatarioForm;
