import { LoadingButton } from '@mui/lab';
import { Box, Card, Divider, Grid, Typography } from '@mui/material';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { firestore } from '../../../../../../../contexts/FirebaseContext';
import {
  responsableTypeCrece,
  segimientoPaletizadoCrece,
  statusPaletizadoCrece
} from '../../../../../../../constants/crece/paletizadoConst';
import { useLocation } from 'react-router';
import { statusItemCrece } from '../../../../../../../constants/crece/itemConst';
import { useSnackbar } from 'notistack';
import { resetPaletizadoInfo } from '../../../../../../../redux/slices/dagpacketCrece';
import DialogTerminarPaletizado from './DialogTerminarPaletizado';

function ResumenPaletizado({ handleReset }) {
  const [loading, setLoading] = useState(false);
  const [openDialogTermPal, setOpenDialogTermPal] = useState(false);
  const [createdPaletizadoId, setCreatedPaletizadoId] = useState(null);

  // si es que se crea el paletizado con el costal cerrado
  const [completedPaletizado, setCompletedPaletizado] = useState(false);
  const { infoCrearPaletizado } = useSelector((state) => state.dagpacketCrece);
  const { enqueueSnackbar } = useSnackbar();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const dispatch = useDispatch();

  const regPaletizadoPendiente = async () => {
    const obj = {
      ...infoCrearPaletizado,
      status: statusPaletizadoCrece.pendienteCerrar,
      responsableActualId: infoCrearPaletizado.origenSucursalId,
      responsableType: responsableTypeCrece.sucursal,

      created_at: new Date(),
      updated_at: new Date()
    };

    setLoading(true);
    try {
      const res = await firestore.collection('crece_paletizado').add(obj);

      await firestore
        .collection('crece_segimientoPaletizado')
        .doc(res.id)
        .set({
          paletizadoId: res.id,
          paletizadoCode: obj.paletizadoCode,
          statusPaletizado: infoCrearPaletizado.status,
          registro: [
            {
              date: new Date(),
              status: segimientoPaletizadoCrece.creadoSegPal,
              sucursalName: queryParams.get('sucursalName'),
              sucursalId: queryParams.get('sucursalId'),
              descripcion: `Recepcionado en ${queryParams.get('sucursalName')}`
            }
          ]
        });

      await Promise.all(
        infoCrearPaletizado.paletizadoItems.map(async (item) => {
          await firestore
            .collection('crece_acceptedItems')
            .doc(item.id)
            .update({
              status: statusItemCrece.esperandoTransporte,
              responsableActualId: queryParams.get('sucursalId'),
              responsableType: responsableTypeCrece.sucursal
            });
        })
      );

      enqueueSnackbar('Operacion exitosa', { variant: 'success' });
      dispatch(resetPaletizadoInfo());
      setLoading(false);
      handleReset();
    } catch (error) {
      console.log(error);

      setLoading(false);
      enqueueSnackbar('Se produjo un error', { variant: 'error' });
    }
  };

  const regPaletizadoCompleto = async (evidenciaArr) => {
    const obj = {
      ...infoCrearPaletizado,
      status: statusPaletizadoCrece.enEspera,
      responsableActualId: infoCrearPaletizado.origenSucursalId,
      responsableType: responsableTypeCrece.sucursal,
      evidenciasPaletizado: evidenciaArr,

      created_at: new Date(),
      updated_at: new Date()
    };

    setLoading(true);
    try {
      const res = await firestore.collection('crece_paletizado').add(obj);

      await firestore
        .collection('crece_segimientoPaletizado')
        .doc(res.id)
        .set({
          paletizadoId: res.id,
          paletizadoCode: obj.paletizadoCode,
          statusPaletizado: infoCrearPaletizado.status,
          registro: [
            {
              date: new Date(),
              status: segimientoPaletizadoCrece.creadoSegPal,
              sucursalName: queryParams.get('sucursalName'),
              sucursalId: queryParams.get('sucursalId'),
              descripcion: `Registrado en ${queryParams.get('sucursalName')}`
            }
          ]
        });

      await Promise.all(
        infoCrearPaletizado.paletizadoItems.map(async (item) => {
          await firestore
            .collection('crece_acceptedItems')
            .doc(item.id)
            .update({
              status: statusItemCrece.esperandoTransporte,
              responsableActualId: queryParams.get('sucursalId'),
              responsableType: responsableTypeCrece.sucursal
            });
        })
      );

      setLoading(false);
      setCreatedPaletizadoId(res.id);
      setCompletedPaletizado(true);
      // setOpenDialogTermPal(true);
      // enqueueSnackbar('Operacion exitosa', { variant: 'success' });
      // dispatch(resetPaletizadoInfo());
      // handleReset();
    } catch (error) {
      console.log(error);

      setLoading(false);
      enqueueSnackbar('Se produjo un error', { variant: 'error' });
    }
  };

  return (
    <Box sx={{ padding: '15px' }}>
      <Typography variant="h4">Resumen del paletizado</Typography>
      <Divider />

      <Box>
        <Grid container spacing={1}>
          <Grid item xs={12} md={6}>
            <Typography fontSize="15px">
              Sucursal Origen:{' '}
              <Typography variant="subtitle1" component="span">
                {infoCrearPaletizado.origenSucursalName}
              </Typography>
            </Typography>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography fontSize="15px">
              Sucursal Destino:{' '}
              <Typography variant="subtitle1" component="span">
                {infoCrearPaletizado.destinoSucursalName}
              </Typography>
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography fontSize="15px">
              Codigo costal:{' '}
              <Typography variant="subtitle1" component="span">
                {infoCrearPaletizado.paletizadoCode}
              </Typography>
            </Typography>
          </Grid>
        </Grid>
      </Box>

      <Typography variant="subtitle1">Items:</Typography>
      <Divider />
      <Box>
        <Grid container spacing={1}>
          {infoCrearPaletizado.paletizadoItems.map((item) => (
            <Grid item key={item.id} xs={12} sm={6} md={4} sx={{ marginTop: '10px' }}>
              <Card sx={{ padding: '10px' }}>
                <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
                  <Typography fontSize="14px">De:</Typography>
                  <Typography fontSize="14px" variant="subtitle2">
                    {item.remitenteNombre}
                  </Typography>
                </Box>
                <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
                  <Typography fontSize="14px">Para:</Typography>
                  <Typography fontSize="14px" variant="subtitle2">
                    {item.destinatarioNombre}
                  </Typography>
                </Box>
                <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
                  <Typography fontSize="12px">Destino:</Typography>
                  <Typography fontSize="12px" variant="subtitle2">
                    {item.destinoSucursalName}
                  </Typography>
                </Box>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>

      <Grid marginTop="10px" container spacing={2}>
        <Grid item xs={12} md={6}>
          <LoadingButton
            onClick={regPaletizadoPendiente}
            sx={{ marginTop: '10px' }}
            fullWidth
            variant="contained"
            loading={loading}
          >
            Registrar sin cerrar
          </LoadingButton>
        </Grid>
        <Grid item xs={12} md={6}>
          <LoadingButton
            onClick={() => setOpenDialogTermPal(true)}
            sx={{ marginTop: '10px' }}
            fullWidth
            variant="contained"
            loading={loading}
            color="info"
          >
            Registrar costal cerrado
          </LoadingButton>
        </Grid>
      </Grid>

      <DialogTerminarPaletizado
        onClose={setOpenDialogTermPal}
        open={openDialogTermPal}
        paletizadoId={createdPaletizadoId}
        regPaletizadoCompleto={regPaletizadoCompleto}
        completedPaletizado={completedPaletizado}
        handleResetStepper={handleReset}
      />
    </Box>
  );
}

export default ResumenPaletizado;
