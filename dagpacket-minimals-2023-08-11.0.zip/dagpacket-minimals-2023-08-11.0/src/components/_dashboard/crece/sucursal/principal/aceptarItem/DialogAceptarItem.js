import React, { useEffect, useState } from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  InputAdornment,
  TextField,
  Typography
} from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { firestore } from '../../../../../../contexts/FirebaseContext';
import RegistrarItemFlujo from './RegistrarItemFlujo';

export default function DialogAceptarItem() {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Recepcionar item
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </>
  );
}

function DialogBody({ open, onClose }) {
  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="md"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <RegistrarItemFlujo />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
