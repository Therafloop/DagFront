import React from 'react';
import { Box, Button, Card, Divider, Grid, styled, Typography } from '@mui/material';
import { fDateTime } from '../../../../../../../utils/formatTime';
import { Icon } from '@iconify/react';
import { getTypeServiceData } from '../../../../../../../utils/fTipoServicioCrece';
import { BlobProvider } from '@react-pdf/renderer';
import ItemRecepcionadoRecibo from '../../../../docs/ItemRecepcionadoRecibo';

const CuztomBox = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '150px 1fr',
  marginBottom: '5px'
}));

const CuztomBox2 = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '100px 1fr',
  marginBottom: '5px'
}));

function DetalleItem({ dataItem }) {
  const {
    origenSucursalName,
    origenSucursalCalle,
    origenSucursalNumCalle,
    origenSucursalColonia,
    origenSucursalCiudad,
    origenSucursalEstado,

    destinoSucursalId,
    destinoSucursalName,
    destinoSucursalCalle,
    destinoSucursalNumCalle,
    destinoSucursalColonia,
    destinoSucursalCiudad,
    destinoSucursalEstado,

    remitenteNombre,
    remitenteApellidos,
    remitenteTelefono,
    remitenteEmail,

    destinatarioNombre,
    destinatarioApellidos,
    destinatarioTelefono,

    created_at,
    tipoServicio
  } = dataItem;
  return (
    <Card sx={{ padding: '15px' }}>
      <Box>
        <CuztomBox>
          <Typography fontSize="15px">Sucursal origen:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {origenSucursalName} - {origenSucursalCalle} {origenSucursalNumCalle} {origenSucursalColonia}{' '}
            {origenSucursalCiudad}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Sucursal destino:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {destinoSucursalName} - {destinoSucursalCalle} {destinoSucursalNumCalle} {destinoSucursalColonia}{' '}
            {destinoSucursalCiudad}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Fecha:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {fDateTime(created_at.toDate())}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Tipo servicio:</Typography>
          <Typography fontSize="15px" variant="subtitle1">
            {getTypeServiceData(tipoServicio)}
          </Typography>
        </CuztomBox>
        <CuztomBox>
          <Typography fontSize="15px">Recibo:</Typography>
          <Box>
            <BlobProvider document={<ItemRecepcionadoRecibo data={dataItem} />}>
              {({ url }) => (
                <Button variant="contained" href={url} target="_blank" rel="noreferrer">
                  Recibo
                </Button>
              )}
            </BlobProvider>
            {/* <Button variant="contained" endIcon={<Icon icon="eva:file-text-fill" />}>
              Recibo
            </Button> */}
          </Box>
        </CuztomBox>
      </Box>

      <Box marginTop="15px">
        <Grid container spacing={1}>
          <Grid item xs={12} md={6}>
            <Box>
              <Typography textAlign="center" variant="subtitle2">
                Remitente
              </Typography>
              <Divider />

              <CuztomBox2>
                <Typography fontSize="14px">Nombre:</Typography>
                <Typography fontSize="14px" variant="subtitle1">
                  {remitenteNombre} {remitenteApellidos}
                </Typography>
              </CuztomBox2>
              <CuztomBox2>
                <Typography fontSize="14px">Telefono:</Typography>
                <Typography fontSize="14px" variant="subtitle1">
                  {remitenteTelefono}
                </Typography>
              </CuztomBox2>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box>
              <Typography textAlign="center" variant="subtitle2">
                Destiatario
              </Typography>
              <Divider />

              <CuztomBox2>
                <Typography fontSize="14px">Nombre:</Typography>
                <Typography fontSize="14px" variant="subtitle1">
                  {destinatarioNombre} {destinatarioApellidos}
                </Typography>
              </CuztomBox2>
              <CuztomBox2>
                <Typography fontSize="14px">Telefono:</Typography>
                <Typography fontSize="14px" variant="subtitle1">
                  {destinatarioTelefono}
                </Typography>
              </CuztomBox2>
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Card>
  );
}

export default DetalleItem;
