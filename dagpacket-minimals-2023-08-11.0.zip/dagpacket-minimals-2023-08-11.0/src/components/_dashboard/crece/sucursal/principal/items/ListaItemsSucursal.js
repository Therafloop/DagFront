import { filter } from 'lodash';
// import { Icon } from '@iconify/react';
// import { sentenceCase } from 'change-case';
import { useState, useEffect, useCallback } from 'react';
// import plusFill from '@iconify/icons-eva/plus-fill';
import { Link as RouterLink, useLocation } from 'react-router-dom';
// // material
// import { styled } from '@mui/material/styles';
import {
  Box,
  Card,
  Table,
  Button,
  TableRow,
  // Checkbox,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  Divider,
  Chip
} from '@mui/material';
// redux
import { useDispatch, useSelector } from '../../../../../../redux/store';
import { setEnviosList } from '../../../../../../redux/slices/dagpacket';
// utils
import { fDate, fDateTime } from '../../../../../../utils/formatTime';
import { fCurrency } from '../../../../../../utils/formatNumber';
// routes
// import { PATH_DASHBOARD } from '../../../routes/paths';
// hooks
import useSettings from '../../../../../../hooks/useSettings';
// components
import Page from '../../../../../Page';
// import Label from '../../Label';
import Scrollbar from '../../../../../Scrollbar';
import SearchNotFound from '../../../../../SearchNotFound';
// import HeaderBreadcrumbs from '../../HeaderBreadcrumbs';
import { ProductListHead, Label } from '../../../../e-commerce/product-list';
// import { Icon } from '@iconify/react';
import { firestore } from '../../../../../../contexts/FirebaseContext';
import CartCheckoutComplete from '../../../../cotenvio/checkout/CartCheckoutComplete';
import { clipPaymentConfirm, getConvertCompras, hacerEnvioRedpack } from '../../../../../../_apis_/dagpacket';
import useAuth from '../../../../../../hooks/useAuth';
import { Icon } from '@iconify/react';
import { startDate } from '../../../../../../constants/estartDate';
import useAuthUsers from '../../../../../../hooks/useAuthUsers';
import useUserRole from '../../../../../../hooks/useUserRole';
import EnvioListToolbar from './EnvioListToolbar';
import DialogItemDetalle from './itemDetalle/DialogItemDetalle';

const TABLE_HEAD = [
  //   { id: 'id', label: '#', alignRight: false },
  { id: 'destinoSucursalName', label: 'Sucursal destino', alignRight: false },
  //   { id: 'created_at', label: 'Fecha', alignRight: false },
  { id: 'reception_date', label: 'Fecha', alignRight: false },
  { id: 'destinatarioNombre', label: 'Destinatario', alignRight: false },
  { id: 'tipoServicio', label: 'Tipo servicio', alignRight: false },
  { id: 'status', label: 'Status', alignRight: false },
  // { id: 'enteredAmount', label: 'Monto', alignRight: true },
  // //   { id: 'city_to', label: 'Destino', alignRight: true },
  // //   { id: 'state', label: 'Estado de pago', alignRight: true },
  // { id: 'status', label: 'Estado de envio', alignRight: true },
  { id: '' }
];

const setValueCurrentControlNumber = (value) => {
  if (value === 'null') {
    return '';
  }
  if (typeof value === 'object') {
    return '';
  }
  return value;
};

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });

  if (query) {
    return filter(
      array,
      (_product) => _product?.accountId?.toString().toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }

  return stabilizedThis.map((el) => el[0]);
}

function calcNewCost(value, percent) {
  const xpercent = value * (percent / 100);
  return value + xpercent;
}
// ----------------------------------------------------------------------

export default function ListaItemsSucursal() {
  const { themeStretch } = useSettings();
  // const theme = useTheme();
  const dispatch = useDispatch();
  const { actualSucursal } = useSelector((state) => state.dagpacketCrece);
  const [dataTable, setDataTable] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [selected, setSelected] = useState([]);
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [orderBy, setOrderBy] = useState('createdAt');
  const [statusEnvioSelected, setStatusEnvioSelected] = useState([]);
  // const [openComplete, setOpenComplete] = useState(false);
  const admin = 'ADMIN';
  const licen = 'LICENCIATARIO';

  const [fecha, setFecha] = useState('');
  const [desdeDate, setDesdeDate] = useState('');
  const [hastaDate, setHastaDate] = useState('');
  // const { search } = useLocation();
  const { user } = useAuth();
  // const { currentUser } = useAuthUsers();
  const { actualRol } = useUserRole();

  // console.log(currentUser);

  // const TABLE_HEAD = selectTableHead(actualRol.userType);
  //   const TABLE_HEAD = TABLE_HEAD_NORMAL;

  useEffect(() => {
    async function getData() {
      await firestore
        .collection('crece_acceptedItems')
        .where('responsableActualId', '==', actualSucursal.id)
        // .where('created_at', '>', startDate)
        .orderBy('reception_date', 'desc')
        // .limit(200)
        .onSnapshot((snapshot) => {
          const data = snapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
          console.log(data);
          setDataTable(data);
        });
    }

    if (actualSucursal) {
      getData();
    }
    // dispatch(getProducts());
  }, [actualSucursal]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = dataTable.map((n) => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - dataTable.length) : 0;

  // const filterDate = (data, date) => {
  //   if (date.length > 0) {
  //     // const asd = data.map((item) => console.log(item.created_at.toDate().toISOString().substring(0, 10)));
  //     return data.filter((item) => item.created_at.toDate().toISOString().substring(0, 10) === date);
  //     // return data;
  //   }
  //   return data;
  // };

  const filterStatus = (data, status) => {
    if (status === 'recarga') {
      return data.filter((item) => item.type === status);
    }
    if (status === 'servicio') {
      return data.filter((item) => item.type === status);
    }
    return data;
  };

  const filterDate = (dataArr, initialDate, finalDate) => {
    const filteredData = dataArr.filter((item) => {
      if (initialDate === '' && finalDate === '') {
        return item;
      }

      if (
        item.updated_at.toDate() >= (initialDate ? new Date(initialDate) : new Date('2017-05-24')) &&
        item.updated_at.toDate() <= (finalDate ? new Date(finalDate) : new Date())
      ) {
        return item;
      }
      return false;
    });

    return filteredData;
  };
  const handleStatus = (selectedStatuses) => {
    setStatusEnvioSelected(selectedStatuses);
  };

  const filteredByStatus = filterStatus(dataTable, statusEnvioSelected);

  const filteredByDate = filterDate(filteredByStatus, desdeDate, hastaDate);

  const filteredProducts = applySortFilter(filteredByDate, getComparator(order, orderBy), filterName);

  const isProductNotFound = filteredProducts.length === 0;
  // collection_status=approved
  // status=approved

  return (
    <Page title="Crece - Lista Sucursal ">
      {/* <Container maxWidth={themeStretch ? false : 'lg'}> */}
      {/* <CartCheckoutComplete open={openComplete} setOpen={setOpenComplete} /> */}
      <Card>
        <Box display="flex" justifyContent="center" sx={{ margin: '15px 0' }}>
          <Typography component="h2" variant="h4">
            Items
          </Typography>
        </Box>
        <Divider />

        <EnvioListToolbar
          numSelected={selected.length}
          filterName={filterName}
          onFilterName={handleFilterByName}
          date={fecha}
          setDate={setFecha}
          // todo: adecuar si se necesita array en statusSelected
          handleStatus={handleStatus}
          dataList={filteredProducts}
          onDesdeDate={setDesdeDate}
          onHastaDate={setHastaDate}
        />

        <Scrollbar>
          <TableContainer sx={{ minWidth: 800 }}>
            <Table>
              <ProductListHead
                order={order}
                orderBy={orderBy}
                headLabel={TABLE_HEAD}
                rowCount={filteredProducts.length}
                numSelected={selected.length}
                onRequestSort={handleRequestSort}
                onSelectAllClick={handleSelectAllClick}
                checkbox={false}
              />
              <TableBody>
                {filteredProducts.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                  const {
                    id,
                    reception_date,
                    tipoServicio,
                    destinatarioNombre,
                    destinoSucursalName,
                    destinatarioApellidos,
                    status
                  } = row;

                  // const createDate = created_at.value ? fDate(new Date(created_at.value)) : fDate(created_at.toDate());

                  const isItemSelected = selected.indexOf(id) !== -1;

                  return (
                    <TableRow
                      hover
                      key={id}
                      tabIndex={-1}
                      role="checkbox"
                      selected={isItemSelected}
                      aria-checked={isItemSelected}
                    >
                      <TableCell style={{ minWidth: 160 }}>{destinoSucursalName}</TableCell>
                      <TableCell style={{ minWidth: 160 }}>{fDateTime(reception_date.toDate())}</TableCell>
                      <TableCell style={{ minWidth: 160 }}>
                        {destinatarioNombre} {destinatarioApellidos}
                      </TableCell>

                      <TableCell>{tipoServicio}</TableCell>
                      <TableCell>{status}</TableCell>

                      <TableCell align="right">
                        <DialogItemDetalle dataItem={row} />
                      </TableCell>
                    </TableRow>
                  );
                })}
                {emptyRows > 0 && (
                  <TableRow style={{ height: 53 * emptyRows }}>
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
              {isProductNotFound && (
                <TableBody>
                  <TableRow>
                    <TableCell align="center" colSpan={6}>
                      <Box sx={{ py: 3 }}>
                        <SearchNotFound searchQuery={filterName} />
                      </Box>
                    </TableCell>
                  </TableRow>
                </TableBody>
              )}
            </Table>
          </TableContainer>
        </Scrollbar>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredProducts.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Card>
      {/* </Container> */}
    </Page>
  );
}

function StatusTableCell({ data }) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const { state, payment_source, payment_id } = data;

  const getStatusClip = useCallback(() => {
    setLoading(true);
    clipPaymentConfirm(payment_id)
      .then((res) => {
        console.log('clip message', res);
        setLoading(false);
        setMessage('pagado clip');
      })
      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  }, [payment_id]);

  useEffect(() => {
    if (payment_source === 'CLIP') {
      getStatusClip();
    }
    setMessage(state || '-');
  }, [payment_source, getStatusClip, state]);
  // console.log(data);
  return (
    <TableCell align="right">
      {/* {state && <Chip sx={{ fontSize: '10px' }} label={state} size="small" color="info" />} */}
      {loading ? 'loading...' : <Chip sx={{ fontSize: '10px' }} label={message} size="small" color="info" />}
    </TableCell>
  );
}
