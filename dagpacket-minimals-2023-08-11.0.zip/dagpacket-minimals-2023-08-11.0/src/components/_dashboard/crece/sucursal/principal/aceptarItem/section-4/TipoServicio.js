import { Box, Button, FormControl, FormControlLabel, FormLabel, Radio, RadioGroup } from '@mui/material';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getTipoServicio } from '../../../../../../../redux/slices/dagpacketCrece';
import { tipoServiciosCrece } from '../../../../../../../constants/crece/tipoServicio';

function TipoServicio({ handleNext }) {
  const [value, setValue] = React.useState(null);
  const { infoAceptarItemSucursal } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();

  const handleChange = (event) => {
    setValue(event.target.value);
    dispatch(getTipoServicio(event.target.value));
    handleNext();
  };

  const selectTipoServicio = (event) => {
    console.log(event.target.value);
    // dispatch(getTipoServicio(event.target.value));
    // handleNext();
  };
  useEffect(() => {
    setValue(infoAceptarItemSucursal.tipoServicio);
  }, [infoAceptarItemSucursal.tipoServicio]);

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center' }}>
      <FormControl hiddenLabel>
        <FormLabel id="demo-controlled-radio-buttons-group">Tipo de servicio</FormLabel>
        <RadioGroup
          aria-labelledby="demo-controlled-radio-buttons-group"
          name="controlled-radio-buttons-group"
          value={value}
          onChange={handleChange}
          // onClick={selectTipoServicio}
        >
          {tipoServiciosCrece.map((item) => (
            <FormControlLabel key={item.id} value={item.id} control={<Radio />} label={item.label} />
          ))}
        </RadioGroup>
      </FormControl>
      {/* <Button variant="contained">Guardar</Button> */}
    </Box>
  );
}

export default TipoServicio;
