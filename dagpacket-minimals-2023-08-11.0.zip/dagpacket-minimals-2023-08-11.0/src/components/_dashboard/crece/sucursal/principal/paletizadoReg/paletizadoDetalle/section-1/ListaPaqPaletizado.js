import React from 'react';
import { Card, Divider, Grid, Typography } from '@mui/material';
import CardPaquetes from './CardPaquete';

function ListaPaqPaletizado({ dataPaletizado }) {
  const { paletizadoItems } = dataPaletizado;

  console.log(paletizadoItems);

  return (
    <Card sx={{ padding: '10px' }}>
      <Typography>Paquetes en costal</Typography>
      <Divider />

      <Grid container spacing={1} marginTop="10px">
        {paletizadoItems.map((paq) => {
          const paqObj = {
            id: paq.id,
            remitenteNombre: paq.remitenteNombre,
            destinatarioNombre: paq.destinatarioNombre,
            destinoSucursalName: paq.destinoSucursalName
          };
          return (
            <Grid item xs={12} sm={6} lg={3} key={paq.id}>
              <CardPaquetes paquete={paq} />
            </Grid>
          );
        })}
      </Grid>
    </Card>
  );
}

export default ListaPaqPaletizado;
