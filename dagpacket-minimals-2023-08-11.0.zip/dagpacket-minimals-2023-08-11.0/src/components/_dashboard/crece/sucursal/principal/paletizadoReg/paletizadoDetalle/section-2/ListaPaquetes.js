import { Box, Grid } from '@mui/material';
import React from 'react';
import CardPaquetes from './CardPaquetes';

function ListaPaquetes({ dataItem }) {
  const { paletizadoItems } = dataItem;
  return (
    <Box>
      <Grid container spacing={1}>
        {paletizadoItems.map((paq) => (
          <Grid item xs={12} sm={6} lg={4} key={paq.id}>
            <CardPaquetes paquete={paq} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default ListaPaquetes;
