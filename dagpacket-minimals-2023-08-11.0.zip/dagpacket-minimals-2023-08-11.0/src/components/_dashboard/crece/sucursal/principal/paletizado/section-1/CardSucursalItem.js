import { Icon } from '@iconify/react';
import { Box, Card, IconButton, Typography } from '@mui/material';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getSucursalDestino, getSucursalDestinoPaletizado } from '../../../../../../../redux/slices/dagpacketCrece';

function CardSucursalItem({ sucursal }) {
  const { infoCrearPaletizado } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();

  const selectSucursal = () => {
    const originData = {
      destinoSucursalId: sucursal.id,
      destinoSucursalName: sucursal.sucursalName,
      destinoSucursalCalle: sucursal.calle,
      destinoSucursalNumCalle: sucursal.numCalle,
      destinoSucursalColonia: sucursal.colonia,
      destinoSucursalCiudad: sucursal.ciudad,
      destinoSucursalEstado: sucursal.estado,
      destinoSucursalCodPost: sucursal.codPost,
      destinoSucursalPlaceId: sucursal.placeId,
      destinoSucursalCoordinates: sucursal.coordinates
    };
    dispatch(getSucursalDestinoPaletizado(originData));
  };
  return (
    <Card
      sx={{
        padding: '10px',
        marginBottom: '10px',
        display: 'flex',
        gap: '15px',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}
    >
      <Box>
        <Typography variant="subtitle1">{sucursal.sucursalName}</Typography>
        <Typography>
          {sucursal.sucursalName} - {sucursal.estado}
        </Typography>
      </Box>

      <Box>
        {infoCrearPaletizado.destinoSucursalId === sucursal.id ? (
          <IconButton color="info">
            <Icon icon="eva:checkmark-circle-2-fill" />
          </IconButton>
        ) : (
          <IconButton onClick={selectSucursal} color="info">
            <Icon icon="eva:radio-button-off-fill" />
          </IconButton>
        )}
      </Box>
    </Card>
  );
}

export default CardSucursalItem;
