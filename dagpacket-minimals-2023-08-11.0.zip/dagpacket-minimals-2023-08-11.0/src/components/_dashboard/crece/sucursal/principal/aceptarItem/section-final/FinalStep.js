import { Card } from '@mui/material';
import React from 'react';

function FinalStep() {
  return <Card sx={{ padding: '15px' }}>final</Card>;
}

export default FinalStep;
