import React, { useCallback, useEffect, useState } from 'react';
import { Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { firestore, storage as st } from '../../../../../../../contexts/FirebaseContext';
import { UploadMultiFile } from '../../../../../../upload';
import { LoadingButton } from '@mui/lab';
import {
  responsableTypeCrece,
  segimientoPaletizadoCrece,
  statusPaletizadoCrece
} from '../../../../../../../constants/crece/paletizadoConst';
import { statusItemCrece } from '../../../../../../../constants/crece/itemConst';
import { useSnackbar } from 'notistack';
import { useLocation } from 'react-router';
import { resetPaletizadoInfo } from '../../../../../../../redux/slices/dagpacketCrece';
import { useDispatch } from 'react-redux';
import PaletizadoRegistradoRecibo from '../../../../docs/PaletizadoRegistradoRecibo';
import { BlobProvider } from '@react-pdf/renderer';

export default function DialogTerminarPaletizado({
  open,
  onClose,
  paletizadoId,
  completedPaletizado,
  regPaletizadoCompleto,
  handleResetStepper
}) {
  const [dataPaletizado, setDataPaletizado] = useState(null);
  const [loadingImages, setLoadingImages] = useState(false);
  const [loading, setLoading] = useState(false);
  const [files, setFiles] = useState([]);
  // const [completed, setCompleted] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const dispatch = useDispatch();

  const handleClose = () => {
    if (completedPaletizado) {
      dispatch(resetPaletizadoInfo());
      handleResetStepper();
    }
    onClose(false);
  };

  console.log(files);

  useEffect(() => {
    async function getData() {
      setLoading(true);
      const data = await (await firestore.collection('crece_paletizado').doc(paletizadoId).get()).data();
      setDataPaletizado(data);
      setLoading(false);
    }

    if (paletizadoId) {
      getData();
    }
  }, [paletizadoId]);

  const handleDropMultiFile = useCallback(
    (acceptedFiles) => {
      setFiles(
        acceptedFiles.map((file) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file)
          })
        )
      );
    },
    [setFiles]
  );

  const handleRemoveAll = () => {
    setFiles([]);
  };

  const handleRemove = (file) => {
    const filteredItems = files.filter((_file) => _file !== file);
    setFiles(filteredItems);
  };

  // eslint-disable-next-line consistent-return
  const uploadMedia = useCallback(async () => {
    const urlsArr = [];

    if (files.length > 0) {
      setLoadingImages(true);
      await Promise.all(
        files.map(async (file) => {
          const refF = st.ref().child(`crece_evidencias/${file.name}`);
          await refF.put(file);
          const url = await refF.getDownloadURL();

          urlsArr.push(url);
        })
      );

      setFiles([]);
      setLoadingImages(false);
      return urlsArr;
    }
  }, [files]);

  const subirEvidencia = async () => {
    const urls = await uploadMedia();

    console.log(urls);
    await regPaletizadoCompleto(urls);

    // const updateObj = { evidenciasPaletizado: urls, updated_at: new Date(), status: statusPaletizadoCrece.enEspera };

    // await firestore.collection('crece_paletizado').doc(paletizadoId).update(updateObj);

    // enqueueSnackbar('Operacion exitosa', { variant: 'success' });
    // // dispatch(resetPaletizadoInfo());
    // // handleResetStepper();
    // setCompleted(true);
  };

  return (
    <Dialog
      open={open}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="md"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        {!completedPaletizado && (
          <>
            <Typography marginBottom="10px" variant="subtitle1" textAlign="center">
              ingrese la evidencia de haber cerrado el costal
            </Typography>
            <Box>
              <UploadMultiFile
                showPreview
                files={files}
                onDrop={handleDropMultiFile}
                onRemove={handleRemove}
                onRemoveAll={handleRemoveAll}
                showBtn={false}
                // error={Boolean(touched.images && errors.images)}
              />
              <Box sx={{ display: 'flex', gap: '15px' }}>
                <Button disabled={loadingImages} variant="contained" color="info">
                  Quitar todo
                </Button>
                <LoadingButton onClick={subirEvidencia} loading={loadingImages} variant="contained">
                  Subir imagenes
                </LoadingButton>
              </Box>
            </Box>
          </>
        )}

        {loading && (
          <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
            <CircularProgress />
          </Box>
        )}

        {completedPaletizado && dataPaletizado && (
          <>
            <Typography variant="subtitle1" textAlign="center" marginBottom="15px">
              Ver el recibo
            </Typography>
            <BlobProvider document={<PaletizadoRegistradoRecibo data={dataPaletizado} />}>
              {({ url }) => (
                <Button fullWidth variant="contained" href={url} target="_blank" rel="noreferrer">
                  Recibo
                </Button>
              )}
            </BlobProvider>
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
