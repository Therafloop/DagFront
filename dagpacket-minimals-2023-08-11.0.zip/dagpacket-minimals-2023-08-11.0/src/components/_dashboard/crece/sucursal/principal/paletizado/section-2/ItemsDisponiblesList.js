import { Grid } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { statusItemCrece } from '../../../../../../../constants/crece/itemConst';
import { firestore } from '../../../../../../../contexts/FirebaseContext';
import CardItem from './CardItem';

function ItemsDisponiblesList() {
  const [itemsDisponibles, setItemsDisponibles] = useState([]);
  const { actualSucursal } = useSelector((state) => state.dagpacketCrece);

  console.log(itemsDisponibles);

  useEffect(() => {
    function getData() {
      firestore
        .collection('crece_acceptedItems')
        .where('responsableActualId', '==', actualSucursal.id)
        .where('status', '==', statusItemCrece.recepcionado)
        .onSnapshot((query) => {
          const data = query.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

          setItemsDisponibles(data);
        });
    }

    getData();
  }, [actualSucursal.id]);

  return (
    <Grid container spacing={1}>
      {itemsDisponibles.map((item) => (
        <Grid item xs={12} sm={6} lg={4} key={item.id}>
          <CardItem dataItem={item} />
        </Grid>
      ))}
    </Grid>
  );
}

export default ItemsDisponiblesList;
