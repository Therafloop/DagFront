import { yupResolver } from '@hookform/resolvers/yup';
import { Box, Button, TextField, Typography } from '@mui/material';
import React from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { getRemitInfo } from '../../../../../../../redux/slices/dagpacketCrece';
import * as yup from 'yup';

const schema = yup.object({
  remitenteNombre: yup.string().required('Este campo es requerido'),
  remitenteApellidos: yup.string().required('Este campo es requerido'),
  remitenteTelefono: yup.string().required('Este campo es requerido'),
  remitenteEmail: yup.string().required('Este campo es requerido'),
  remitenteINE: yup.string().required('Este campo es requerido')
});

function RemitenteForm({ handleNext }) {
  const { infoAceptarItemSucursal } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      remitenteNombre: infoAceptarItemSucursal.remitenteNombre || null,
      remitenteApellidos: infoAceptarItemSucursal.remitenteApellidos || null,
      remitenteTelefono: infoAceptarItemSucursal.remitenteTelefono || null,
      remitenteEmail: infoAceptarItemSucursal.remitenteEmail || null,
      remitenteINE: infoAceptarItemSucursal.remitenteINE || null
    }
  });

  const onSubmit = (dataForm) => {
    dispatch(getRemitInfo(dataForm));
    console.log(dataForm);
    handleNext();
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Nombre" {...register('remitenteNombre')} />
        {errors.remitenteNombre && (
          <Typography fontSize="13px" color="error">
            {errors.remitenteNombre?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Apellidos" {...register('remitenteApellidos')} />
        {errors.remitenteApellidos && (
          <Typography fontSize="13px" color="error">
            {errors.remitenteApellidos?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Telefono" {...register('remitenteTelefono')} />
        {errors.remitenteTelefono && (
          <Typography fontSize="13px" color="error">
            {errors.remitenteTelefono?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="Email" {...register('remitenteEmail')} />
        {errors.remitenteEmail && (
          <Typography fontSize="13px" color="error">
            {errors.remitenteEmail?.message}
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField fullWidth label="INE" {...register('remitenteINE')} />
        {errors.remitenteINE && (
          <Typography fontSize="13px" color="error">
            {errors.remitenteINE?.message}
          </Typography>
        )}
      </Box>
      <Button type="submit" variant="contained" fullWidth>
        Guardar
      </Button>
    </Box>
  );
}

export default RemitenteForm;
