import React, { useEffect, useState } from 'react';
import { Box, Button, Card, Container, Step, StepLabel, Stepper, Typography } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import SucursalList from './section-1/SucursalList';
import { getSucursalOrigenPaletizado } from '../../../../../../redux/slices/dagpacketCrece';
import ItemsDisponiblesList from './section-2/ItemsDisponiblesList';
import ResumenPaletizado from './section-final/ResumenPaletizado';
import PaletizadoCodeForm from './section-0/PaletizadoCodeForm';

export default function PaletizadoFlujo() {
  const [activeStep, setActiveStep] = useState(0);
  const [skipped, setSkipped] = useState(new Set());
  const { actualSucursal, infoAceptarItemSucursal } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();

  const handleJumpSteps = (step = 1) => {
    setActiveStep(step);
  };

  const handleNext = () => {
    const newSkipped = skipped;

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped(newSkipped);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  const steps = [
    {
      label: 'Codigo paletizado',
      component: <PaletizadoCodeForm handleNext={handleNext} />
    },
    {
      label: 'Sucursal destino',
      component: <SucursalList />
    },
    {
      label: 'Items',
      component: <ItemsDisponiblesList />
    },
    {
      label: 'Resumen Paletizado',
      component: <ResumenPaletizado handleReset={handleReset} />
    }
  ];

  useEffect(() => {
    if (actualSucursal) {
      const originData = {
        origenSucursalId: actualSucursal.id,
        origenSucursalName: actualSucursal.sucursalName,
        origenSucursalCalle: actualSucursal.calle,
        origenSucursalNumCalle: actualSucursal.numCalle,
        origenSucursalColonia: actualSucursal.colonia,
        origenSucursalCiudad: actualSucursal.ciudad,
        origenSucursalEstado: actualSucursal.estado,
        origenSucursalCodPost: actualSucursal.codPost,
        origenSucursalPlaceId: actualSucursal.placeId,
        origenSucursalCoordinates: actualSucursal.coordinates
      };
      dispatch(getSucursalOrigenPaletizado(originData));
    }
  }, [actualSucursal, dispatch]);

  return (
    <>
      <Box sx={{ width: '100%' }}>
        <Stepper activeStep={activeStep}>
          {steps.map((step, index) => {
            const stepProps = {};
            const labelProps = {};

            return (
              <Step key={step.label} {...stepProps}>
                <StepLabel {...labelProps}>{step.label}</StepLabel>
              </Step>
            );
          })}
        </Stepper>
        {activeStep === steps.length ? (
          <>
            {/* <Typography sx={{ mt: 2, mb: 1 }}>All steps completed - you&apos;re finished</Typography> */}

            <Typography>final</Typography>

            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
              <Box sx={{ flex: '1 1 auto' }} />
              <Button onClick={handleReset}>Reset</Button>
            </Box>
          </>
        ) : (
          <>
            {/* ---------------cuerpo del steper------------------- */}
            <Card sx={{ padding: '20px', mt: 2, mb: 1, width: '100%' }}>{steps[activeStep].component}</Card>

            {/* -------------- seccion de botones de control ----------------- */}
            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
              <Button color="inherit" disabled={activeStep === 0} onClick={handleBack} sx={{ mr: 1 }}>
                Back
              </Button>
              <Box sx={{ flex: '1 1 auto' }} />

              {![].includes(activeStep) && (
                <Button onClick={handleNext}>{activeStep === steps.length - 1 ? 'Finish' : 'Next'}</Button>
              )}
            </Box>
          </>
        )}
      </Box>
    </>
  );
}
