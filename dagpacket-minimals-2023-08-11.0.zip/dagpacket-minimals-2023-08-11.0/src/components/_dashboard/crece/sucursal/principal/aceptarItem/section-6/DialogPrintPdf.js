import { Box } from '@material-ui/core';
import { Button, CircularProgress, Dialog, DialogActions, DialogContent, Icon, Typography } from '@mui/material';
import { BlobProvider } from '@react-pdf/renderer';
import React, { useEffect, useState } from 'react';
import ItemRecepcionadoRecibo from '../../../../docs/ItemRecepcionadoRecibo';
import { firestore } from '../../../../../../../contexts/FirebaseContext';
import { useDispatch } from 'react-redux';
import { resetInfoAcceptedItem } from '../../../../../../../redux/slices/dagpacketCrece';

function DialogPrintPdf({ open, onClose, idItemAceptado, handleReset }) {
  const [loading, setLoading] = useState(false);
  const [dataItem, setDataItem] = useState(null);
  const dispatch = useDispatch();

  const handleClose = () => {
    onClose(false);
  };

  const salirDialogo = () => {
    dispatch(resetInfoAcceptedItem());
    handleClose();
    handleReset();
  };

  useEffect(() => {
    async function getData() {
      setLoading(true);
      const data = await (await firestore.collection('crece_acceptedItems').doc(idItemAceptado).get()).data();
      setDataItem(data);
      setLoading(false);
    }

    if (idItemAceptado) {
      getData();
    }
  }, [idItemAceptado]);

  return (
    <Dialog
      open={open}
      //   onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        {loading && (
          <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center', marginTop: '10px' }}>
            <CircularProgress />
          </Box>
        )}
        {!loading && (
          <>
            <Box sx={{ width: '100%', textAlign: 'center', marginTop: '10px' }}>
              <Typography variant="subtitle1">Paquete recepcionado exitosamente</Typography>

              {dataItem && (
                <Box my="15px">
                  <BlobProvider document={<ItemRecepcionadoRecibo data={dataItem} />}>
                    {({ url }) => (
                      <Button fullWidth variant="contained" href={url} target="_blank" rel="noreferrer">
                        Ver recibo
                      </Button>
                    )}
                  </BlobProvider>
                  {/* <Button variant="contained" endIcon={<Icon icon="eva:file-text-fill" />}>
              Recibo
            </Button> */}
                </Box>
              )}
            </Box>

            <Button onClick={salirDialogo} fullWidth color="inherit">
              salir
            </Button>
          </>
        )}
      </DialogContent>
      {/* <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions> */}
    </Dialog>
  );
}

export default DialogPrintPdf;
