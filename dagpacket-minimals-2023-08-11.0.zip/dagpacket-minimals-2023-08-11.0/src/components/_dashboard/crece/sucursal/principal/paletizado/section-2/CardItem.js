import React from 'react';
import { Box, Card, IconButton, Typography } from '@mui/material';
import { Icon } from '@iconify/react';
import { useDispatch, useSelector } from 'react-redux';
import { getItemsPaletizados } from '../../../../../../../redux/slices/dagpacketCrece';

function CardItem({ dataItem }) {
  const { infoCrearPaletizado } = useSelector((state) => state.dagpacketCrece);
  const dispatch = useDispatch();

  const verifyItemSelected = () => {
    const finded = infoCrearPaletizado.paletizadoItems.find((item) => item.id === dataItem.id);

    if (finded) {
      return true;
    }
    return false;
  };

  const handleItemSelected = () => {
    const obj = {
      id: dataItem.id,
      remitenteNombre: dataItem.remitenteNombre,
      destinatarioNombre: dataItem.destinatarioNombre,
      destinoSucursalName: dataItem.destinoSucursalName
    };
    dispatch(getItemsPaletizados(obj));
  };
  return (
    <Card sx={{ padding: '10px', display: 'flex', gap: '10px', justifyContent: 'space-between', alignItems: 'center' }}>
      <Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
          <Typography fontSize="14px">De:</Typography>
          <Typography fontSize="14px" variant="subtitle2">
            {dataItem.remitenteNombre}
          </Typography>
        </Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
          <Typography fontSize="14px">Para:</Typography>
          <Typography fontSize="14px" variant="subtitle2">
            {dataItem.destinatarioNombre}
          </Typography>
        </Box>
        <Box sx={{ display: 'grid', gridTemplateColumns: '50px 1fr' }}>
          <Typography fontSize="12px">Destino:</Typography>
          <Typography fontSize="12px" variant="subtitle2">
            {dataItem.destinoSucursalName}
          </Typography>
        </Box>
      </Box>
      <Box>
        {/* <IconButton color="info">
          <Icon icon="eva:checkmark-circle-2-fill" />
        </IconButton> */}
        <Box>
          {verifyItemSelected() ? (
            <IconButton onClick={handleItemSelected} color="info">
              <Icon icon="eva:checkmark-circle-2-fill" />
            </IconButton>
          ) : (
            <IconButton onClick={handleItemSelected} color="info">
              <Icon icon="eva:radio-button-off-fill" />
            </IconButton>
          )}
        </Box>
      </Box>
    </Card>
  );
}

export default CardItem;
