import { Document, Page, PDFViewer, Text, View, StyleSheet, Image } from '@react-pdf/renderer';
import { useEffect } from 'react';
import { fDate, fDateTime } from '../../../../utils/formatTime';
import { fCurrency } from '../../../../utils/formatNumber';
import { getTypeServiceData } from '../../../../utils/fTipoServicioCrece';

const styles = StyleSheet.create({
  title_container: {
    borderBottomColor: '#000',
    borderBottomStyle: 'solid',
    borderBottomWidth: '1px',
    margin: '5px 0 1px',
    fontWeight: 800
  }
});

export default function PaletizadoRegistradoRecibo({ data }) {
  const {
    paletizadoCode,

    origenSucursalName,
    origenSucursalCalle,
    origenSucursalNumCalle,
    origenSucursalColonia,
    origenSucursalCiudad,
    origenSucursalEstado,

    destinoSucursalName,
    destinoSucursalCalle,
    destinoSucursalNumCalle,
    destinoSucursalColonia,
    destinoSucursalCiudad,
    destinoSucursalEstado,

    status,
    paletizadoItems,
    created_at
  } = data;
  return (
    <Document>
      <Page size="A6">
        <View style={{ padding: '15px 25px 15px 10px', fontSize: '9px' }}>
          <View style={{ display: 'flex', flexDirection: 'row', gap: '15px', justifyContent: 'space-between' }}>
            <View>
              <Image src="/favicon/logo_negro.png" />
              {/* <Image src="/favicon/Logo_Negro_.svg" /> */}
            </View>
          </View>
          <View style={{ marginTop: '10px', textAlign: 'center' }}>
            <Text>{created_at ? fDateTime(created_at?.toDate()) : ''}</Text>
          </View>
          <View style={{ marginTop: '9px' }}>
            <Text>
              Sucursal Origen: {origenSucursalName} - {origenSucursalCalle} {origenSucursalNumCalle}{' '}
              {origenSucursalColonia} {origenSucursalCiudad}
            </Text>
          </View>
          <View style={{ marginTop: '9px' }}>
            <Text>
              Sucursal Destino: {destinoSucursalName} - {destinoSucursalCalle} {destinoSucursalNumCalle}{' '}
              {destinoSucursalColonia} {destinoSucursalCiudad}
            </Text>
          </View>
          <View style={{ marginTop: '9px' }}>
            <Text>Codigo Costal: {paletizadoCode}</Text>
          </View>
          <View style={{ marginTop: '9px' }}>
            <Text>Cantidad paquetes: {paletizadoItems.length} </Text>
          </View>
        </View>
      </Page>
    </Document>
  );
}
