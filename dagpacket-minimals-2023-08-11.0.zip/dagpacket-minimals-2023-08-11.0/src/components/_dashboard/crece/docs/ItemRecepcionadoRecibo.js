import { Document, Page, PDFViewer, Text, View, StyleSheet, Image } from '@react-pdf/renderer';
import { useEffect } from 'react';
import { fDate, fDateTime } from '../../../../utils/formatTime';
import { fCurrency } from '../../../../utils/formatNumber';
import { getTypeServiceData } from '../../../../utils/fTipoServicioCrece';

const styles = StyleSheet.create({
  title_container: {
    borderBottomColor: '#000',
    borderBottomStyle: 'solid',
    borderBottomWidth: '1px',
    margin: '5px 0 1px',
    fontWeight: 800
  }
});

export default function ItemRecepcionadoRecibo({ data }) {
  const {
    origenSucursalName,
    origenSucursalCalle,
    origenSucursalNumCalle,
    origenSucursalColonia,
    origenSucursalCiudad,
    origenSucursalEstado,

    destinoSucursalId,
    destinoSucursalName,
    destinoSucursalCalle,
    destinoSucursalNumCalle,
    destinoSucursalColonia,
    destinoSucursalCiudad,
    destinoSucursalEstado,

    remitenteNombre,
    remitenteApellidos,
    remitenteTelefono,
    remitenteEmail,

    destinatarioNombre,
    destinatarioApellidos,
    destinatarioTelefono,

    created_at,
    tipoServicio,
    observaciones,
    descripcionContenido,
    claveNip
  } = data;

  //   console.log(created_at.toDate());
  return (
    <Document>
      <Page size="A6">
        <View style={{ padding: '15px 25px 15px 10px', fontSize: '9px' }}>
          <View style={{ display: 'flex', flexDirection: 'row', gap: '15px', justifyContent: 'space-between' }}>
            <View>
              <Image src="/favicon/logo_negro.png" />
              {/* <Image src="/favicon/Logo_Negro_.svg" /> */}
            </View>
          </View>
          <View style={{ marginTop: '7px', textAlign: 'center' }}>
            <Text>{fDateTime(created_at.toDate())}</Text>
          </View>
          <View style={{ marginTop: '5px', fontSize: '7px', textAlign: 'center' }}>
            <Text>
              {origenSucursalName} - {origenSucursalCalle} {origenSucursalNumCalle} {origenSucursalColonia}{' '}
              {origenSucursalCiudad}
            </Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Tipo servicio: {getTypeServiceData(tipoServicio)}</Text>
          </View>
          <View
            style={{
              marginTop: '5px',
              borderBottomWidth: 1,
              borderBottomColor: '#112131',
              borderBottomStyle: 'solid',
              textAlign: 'center'
            }}
          >
            <Text>Datos del envio</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>
              Nombre: {remitenteNombre} {remitenteApellidos}
            </Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>telefono: {remitenteTelefono}</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Contenido: {descripcionContenido || '-'}</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Observaciones: {observaciones}</Text>
          </View>
          <View style={{ marginTop: '5px', fontSize: '6px' }}>
            <Text>NIP: {claveNip}</Text>
          </View>

          <View
            style={{
              marginTop: '5px',
              borderBottomWidth: 1,
              borderBottomColor: '#112131',
              borderBottomStyle: 'solid',
              textAlign: 'center'
            }}
          >
            <Text>Sucursales</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Sucursal origen: {origenSucursalName}</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Sucursal destino: {destinoSucursalName}</Text>
          </View>

          <View
            style={{
              marginTop: '5px',
              borderBottomWidth: 1,
              borderBottomColor: '#112131',
              borderBottomStyle: 'solid',
              textAlign: 'center'
            }}
          >
            <Text>Cliente final</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>
              Nombre (con identificacion oficial): {destinatarioNombre} {destinatarioApellidos}
            </Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Telefono: {destinatarioTelefono}</Text>
          </View>

          {/* <View style={{ marginTop: '5px' }}>
            <Text>Fecha: {TransactionDateTime}</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Referencia: {accountId}</Text>
          </View>
           <View style={{ marginTop: '5px' }}>
            <Text>Invoice N°: {InvoiceNo}</Text>
          </View> 
          <View style={{ marginTop: '5px' }}>
            <Text>N° autorizacion: {typeof CarrierControlNo === 'string' ? CarrierControlNo : ''}</Text>
          </View>
          
          <View style={{ marginTop: '5px' }}>
            <Text>Id Transacción: {TransactionId || TRANSACTION}</Text>
          </View>
          <View style={{ marginTop: '5px' }}>
            <Text>Mensaje: {ResponseMessage}</Text>
          </View>{' '}
          */}
        </View>
      </Page>
    </Document>
  );
}
