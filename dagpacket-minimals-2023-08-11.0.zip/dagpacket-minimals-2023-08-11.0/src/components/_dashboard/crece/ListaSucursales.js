import { useState, useEffect } from 'react';
import { Grid } from '@mui/material';
import SucursalCard from './SucursalCard';
import NuevaSucursalForm from './NuevaSucursalForm';
import { firestore } from '../../../contexts/FirebaseContext';

export default function ListaSucursales() {
  return <></>;
}
