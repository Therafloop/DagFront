import React, { useCallback } from 'react';
import { Chip } from '@mui/material';
import propTypes from 'prop-types';

Label.propTypes = {
  text: propTypes.string
};

export default function Label({ text = '' }) {
  const getColor = useCallback(() => {
    switch (text) {
      case 'PURCHASE':
        return 'warning';
      case 'QUOTE':
        return 'warning';
      case 'MANUAL_LABEL':
        return 'error';
      default:
        return 'primary';
    }
  }, [text]);

  const getText = useCallback(() => {
    switch (text) {
      case 'PURCHASE':
        return 'Cotización';
      case 'QUOTE':
        return 'Cotización';
      case 'MANUAL_LABEL':
        return 'Guia No generada';
      case 'LABEL_CREATED':
        return 'Guia generada';
      case 'CREATED':
        return 'Guia generada';
      default:
        return text;
    }
  }, [text]);

  return <Chip size="small" label={getText()} color={getColor()} />;
}
