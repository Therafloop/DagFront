import { Grid } from '@mui/material';
import React from 'react';
import ItemCardProduct from './ItemCardProducts';

function CardListProducts({ cartList }) {
  //   console.log(cartList);
  return (
    <>
      <Grid container spacing={1} padding="10px 10px 20px">
        {cartList.map((item) => (
          <Grid key={item.idProducto} item xs={12} sm={6} md={6}>
            <ItemCardProduct item={item} />
          </Grid>
        ))}
      </Grid>
    </>
  );
}

export default CardListProducts;
