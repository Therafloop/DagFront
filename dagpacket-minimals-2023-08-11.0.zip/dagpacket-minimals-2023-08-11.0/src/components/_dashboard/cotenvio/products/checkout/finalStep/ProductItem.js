import { Avatar, Box, Card, Typography } from '@mui/material';
import React from 'react';
import { fCurrency } from '../../../../../../utils/formatNumber';

function ProductItem({ dataItem }) {
  return (
    <Card
      sx={{
        marginBottom: '10px',
        padding: '5px',
        display: 'flex',
        gap: '15px',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%'
      }}
    >
      <Box sx={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
        <Avatar src={dataItem.img} />
        <Typography variant="subtitle2">
          {dataItem.name} x {dataItem.cantidad}
        </Typography>
      </Box>

      <Typography>{fCurrency(dataItem.price_complete)}</Typography>
    </Card>
  );
}

export default ProductItem;
