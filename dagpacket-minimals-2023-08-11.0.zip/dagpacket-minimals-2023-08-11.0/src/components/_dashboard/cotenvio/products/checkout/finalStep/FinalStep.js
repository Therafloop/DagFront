import React, { useEffect, useState } from 'react';
import { Box, Button, Card, Divider, Typography } from '@mui/material';
import { useSelector } from 'react-redux';
import ResumeItem from './ResumeItem';
import ProductItem from './ProductItem';
import { BlobProvider } from '@react-pdf/renderer';
import ReciboEmpaqueVenta from '../../../../productos/ReciboEmpaqueVenta';

function FinalStep({ finalizarPago }) {
  const [successItems, setSuccessItems] = useState([]);
  const [errorItems, setErrorItems] = useState([]);
  const { itemsError, itemsSuccess, cartProducts, itemApproved } = useSelector((state) => state.dagpacketProducts);

  return (
    <Card sx={{ padding: '15px' }}>
      {/* <Typography>Operacion completada</Typography> */}
      {itemApproved && (
        <>
          <Typography textAlign="center" variant="subtitle1">
            Resumen de venta
          </Typography>
          <Divider />
          <Box>
            {itemApproved?.items?.map((item) => (
              <ProductItem key={item.idProducto} dataItem={item} />
            ))}
          </Box>
        </>
      )}

      {!itemApproved && (
        <Typography textAlign="center" variant="subtitle1" color="error">
          Ha ocurrido un error
        </Typography>
      )}

      {itemApproved && (
        <BlobProvider document={<ReciboEmpaqueVenta dataItem={itemApproved} />}>
          {({ url }) => (
            <Button fullWidth variant="contained" href={url} target="_blank" rel="noreferrer">
              Recibo
            </Button>
          )}
        </BlobProvider>
      )}

      <Button onClick={finalizarPago} color="inherit" fullWidth>
        Ver productos comprados
      </Button>
    </Card>
  );
}

export default FinalStep;
