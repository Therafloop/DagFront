import { Box, Button, Card, Chip, Typography } from '@mui/material';
import { BlobProvider } from '@react-pdf/renderer';
import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router';
import ReciboSevRec from '../../../../serviciosRecarga/servRecDetalle/ReciboSevRec';
import { fCurrency } from '../../../../../../utils/formatNumber';

function ResumeItem({ dataItem, success = true }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { name, price_complete, type } = dataItem;

  const redirectDetail = () => {
    console.log('detalle');
  };
  return (
    <Card
      sx={{
        marginBottom: '10px',
        padding: '5px',
        display: 'flex',
        gap: '15px',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%'
      }}
    >
      <Box sx={{ width: '100%', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <Typography>{name}</Typography>
        <Typography fontSize="14px">{fCurrency(price_complete)}</Typography>
        {/* <Typography fontSize="14px">{fDateTime(new Date())}</Typography> */}
      </Box>
      <Box sx={{ display: 'flex', gap: '15px', justifyContent: 'space-between', alignItems: 'center', width: '200px' }}>
        {success ? (
          <>
            <Chip size="small" label="success" color="success" sx={{ color: '#fff' }} />
            {/* <Button variant="contained" size="small" onClick={redirectDetail}>
              Detalle
            </Button> */}
            {/* <BlobProvider document={<ReciboSevRec data={dataItem} />}>
              {({ url }) => (
                <Button size="small" variant="contained" href={url} target="_blank" rel="noreferrer">
                  Recibo
                </Button>
              )}
            </BlobProvider> */}
          </>
        ) : (
          <>
            <Chip size="small" label="fail" color="error" />
            {/* <DialogReportError itemId={object_id} /> */}
            {/* <DialogError itemId={object_id} /> */}
          </>
        )}
      </Box>
    </Card>
  );
}

export default ResumeItem;
