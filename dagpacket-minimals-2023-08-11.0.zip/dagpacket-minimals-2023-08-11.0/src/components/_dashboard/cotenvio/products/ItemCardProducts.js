import React from 'react';
import { Box, Card, CardActions, Chip, Divider, IconButton, Typography } from '@mui/material';
import { fCurrency } from '../../../../utils/formatNumber';
import { fCapitalize } from '../../../../utils/formatText';
import { Icon } from '@iconify/react';
// import { removeItemAction } from '../../../../redux/slices/dagpacket';
import { useDispatch } from 'react-redux';
import { removeItemProducts } from '../../../../redux/slices/dagpacketProducts';

function ItemCardProduct({ item }) {
  const dispatch = useDispatch();
  console.log(item);
  return (
    <Card sx={{ padding: '15px' }}>
      <Box sx={{ display: 'flex', gap: '15px' }}>
        <Typography flexGrow={1} variant="subtitle1" fontSize="15px">
          {item.name} x {item.cantidad}
        </Typography>
        <Typography variant="subtitle1">{fCurrency(item.price_complete)}</Typography>
      </Box>
      <Divider />

      <Box sx={{ display: 'flex', gap: '15px', marginTop: '15px' }}>
        <Box sx={{ flexGrow: 1 }}>
          <Typography>{item.description}</Typography>
          {/* <Box sx={{ display: 'grid', gridTemplateColumns: '80px 1fr' }}>
            <Typography variant="subtitle2" fontSize="13px">
              Account ID:
            </Typography>
            <Typography variant="subtitle2" fontSize="13px">
              {item.accountId}
            </Typography>
          </Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: '80px 1fr' }}>
            <Typography variant="subtitle2" fontSize="13px">
              Categoria:
            </Typography>
            <Typography variant="subtitle2" fontSize="13px">
              {item.category}
            </Typography>
          </Box> */}
        </Box>

        <Box>
          <Chip size="small" label={fCapitalize(item.type)} color={item.type === 'empaque' ? 'error' : 'secondary'} />
        </Box>
      </Box>

      <CardActions disableSpacing>
        <IconButton
          sx={{ marginTop: '10px' }}
          onClick={() => dispatch(removeItemProducts(item.idProducto))}
          color="error"
        >
          <Icon icon="eva:trash-2-fill" />
        </IconButton>
      </CardActions>
    </Card>
  );
}

export default ItemCardProduct;
