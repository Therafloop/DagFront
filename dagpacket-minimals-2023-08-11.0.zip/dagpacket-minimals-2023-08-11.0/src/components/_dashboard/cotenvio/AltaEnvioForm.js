import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
// mui
import { Card, CardHeader, CardContent, Grid, TextField } from '@mui/material';
import { LoadingButton } from '@mui/lab';
// formik Yup
import { useFormik, FormikProvider, Form } from 'formik';
import * as yup from 'yup';
// hooks
import useAuth from '../../../hooks/useAuth';
// firebase
import { firestore } from '../../../contexts/FirebaseContext';
// api
import { hacerEnvio } from '../../../_apis_/dagpacket';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import { addCartAction } from '../../../redux/slices/dagpacket';

AltaEnvioForm.propTypes = {
  edit: PropTypes.bool
};

// eslint-disable-next-line
export default function AltaEnvioForm({ edit = false }) {
  const { user } = useAuth();
  const [setTipoP] = useState('sobre');
  const [amount, setAmount] = useState(200);
  const navigate = useNavigate();
  const { search } = useLocation();
  const dispatch = useDispatch();

  const validationSchema = yup.object().shape({
    name_from: yup.string().required('El nombre del remitente es requerido'),
    street_from: yup.string().required('La calle del remitente es requerida'),
    street2_from: yup.string().required('La calle 2 del remitente es requerida'),
    reference_from: yup.string().required('La referencia del remitente es requerida'),
    zipcode_from: yup.string().required('El codigo postal del remitente es requerido'),
    alias_from: yup.string().required('El alias del remitente es requerido'),
    name_to: yup.string().required('El nombre del remitente es requerido'),
    street_to: yup.string().required('La calle del remitente es requerida'),
    street2_to: yup.string().required('La calle 2 del remitente es requerida'),
    reference_to: yup.string().required('La referencia del remitente es requerida'),
    zipcode_to: yup.string().required('El codigo postal del remitente es requerido'),
    alias_to: yup.string().required('El alias del remitente es requerido'),
    declared_value: yup.number().required('El valor declarado es requerido'),
    weight: yup.number().min(1, 'Minimo 1').integer('Debe ser Numero entero').required('Requerido'),
    length: yup.number().min(1, 'Minimo 1').integer('Debe ser Numero entero').required('Requerido'),
    height: yup.number().min(1, 'Minimo 1').integer('Debe ser Numero entero').required('Requerido'),
    width: yup.number().min(1, 'Minimo 1').integer('Debe ser Numero entero').required('Requerido'),
    description: yup.string()
  });

  const formik = useFormik({
    initialValues: {
      name_from: '',
      street_from: '',
      street2_from: '',
      reference_from: '',
      zipcode_from: '',
      alias_from: 'origen',
      name_to: '',
      street_to: '',
      street2_to: '',
      reference_to: '',
      zipcode_to: '',
      alias_to: 'destino',
      declared_value: 200,
      weight: 1,
      length: 20,
      height: 1,
      width: 10,
      qty: 1,
      description: ''
    },
    validationSchema,
    onSubmit: async (values, { setSubmitting }) => {
      // setSubmitting(true);
      values.weight = Math.ceil(Number(values.weight));
      values.length = Math.ceil(Number(values.length));
      values.height = Math.ceil(Number(values.height));
      values.width = Math.ceil(Number(values.width));
      values.declared_value = Number(amount);
      console.log(values);
      try {
        validationSchema.validate(values);
        const cot = await hacerEnvio(values);
        const shipment = cot;
        const { object_id } = shipment;
        // console.log(shipment);
        await firestore
          .collection('cotizaciones')
          .doc(String(object_id))
          .set({ ...cot, user_id: user.id });
        navigate(`/dashboard/cotizaciones/cart`);
        const obj = { ...cot, object_id };
        dispatch(addCartAction(obj));
        console.log(obj);
        // setSubmitting(false);
      } catch (e) {
        setSubmitting(false);
        console.log(e.response);
      }
    }
  });

  const { errors, touched, isSubmitting, getFieldProps, handleSubmit, setFieldValue } = formik;

  useEffect(() => {
    const queryParams = new URLSearchParams(search);
    // zipcode_from
    if (queryParams.get('zipcode_from')) {
      setFieldValue('zipcode_from', queryParams.get('zipcode_from'));
    }
    // zipcode_to
    if (queryParams.get('zipcode_to')) {
      setFieldValue('zipcode_to', queryParams.get('zipcode_to'));
    }
    // weight
    if (queryParams.get('weight')) {
      setFieldValue('weight', Math.ceil(Number(queryParams.get('weight'))));
    }
    // length
    if (queryParams.get('length')) {
      setFieldValue('length', Math.ceil(Number(queryParams.get('length'))));
    }
    // height
    if (queryParams.get('height')) {
      setFieldValue('height', Math.ceil(Number(queryParams.get('height'))));
    }
    // width
    if (queryParams.get('width')) {
      setFieldValue('width', Math.ceil(Number(queryParams.get('width'))));
    }
    // tipoP
    if (queryParams.get('tipoP')) {
      setTipoP(queryParams.get('tipoP'));
    }
    // precio
    if (queryParams.get('declared_value')) {
      setAmount(queryParams.get('declared_value'));
    }
  }, [search, setFieldValue, setTipoP]);

  return (
    <Card>
      <CardHeader title="Nueva Cotizacion" />
      <CardContent>
        <FormikProvider value={formik}>
          <Form autoComplete="off" noValidate onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Remitente" />
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Nombre Remitente"
                          name="name_from"
                          fullWidth
                          {...getFieldProps('name_from')}
                          error={Boolean(touched.name_from && errors.name_from)}
                          helperText={touched.name_from && errors.name_from}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Direccion Remitente"
                          name="street_from"
                          fullWidth
                          {...getFieldProps('street_from')}
                          error={Boolean(touched.street_from && errors.street_from)}
                          helperText={touched.street_from && errors.street_from}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Colonia Remitente"
                          name="street2_from"
                          fullWidth
                          {...getFieldProps('street2_from')}
                          error={Boolean(touched.street2_from && errors.street2_from)}
                          helperText={touched.street2_from && errors.street2_from}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Referencia"
                          name="reference_from"
                          fullWidth
                          {...getFieldProps('reference_from')}
                          error={Boolean(touched.reference_from && errors.reference_from)}
                          helperText={touched.reference_from && errors.reference_from}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Codigo Potsal Remitente"
                          name="zipcode_from"
                          fullWidth
                          {...getFieldProps('zipcode_from')}
                          error={Boolean(touched.zipcode_from && errors.zipcode_from)}
                          helperText={touched.zipcode_from && errors.zipcode_from}
                        />
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
              <Grid item xs={12}>
                <Card>
                  <CardHeader title="Destinatario" />
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Nombre del Destinatario"
                          name="name_to"
                          fullWidth
                          {...getFieldProps('name_to')}
                          error={Boolean(touched.name_to && errors.name_to)}
                          helperText={touched.name_to && errors.name_to}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Direccion Del Destinatario"
                          name="street_to"
                          fullWidth
                          {...getFieldProps('street_to')}
                          error={Boolean(touched.street_to && errors.street_to)}
                          helperText={touched.street_to && errors.street_to}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Colonia Destinatario"
                          name="street2_to"
                          fullWidth
                          {...getFieldProps('street2_to')}
                          error={Boolean(touched.street2_to && errors.street2_to)}
                          helperText={touched.street2_to && errors.street2_to}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Referencia"
                          name="reference_to"
                          fullWidth
                          {...getFieldProps('reference_to')}
                          error={Boolean(touched.reference_to && errors.reference_to)}
                          helperText={touched.reference_to && errors.reference_to}
                        />
                      </Grid>
                      <Grid item xs={6} md={6}>
                        <TextField
                          label="Codigo Potsal del Destinatario"
                          name="zipcode_to"
                          fullWidth
                          {...getFieldProps('zipcode_to')}
                          error={Boolean(touched.zipcode_to && errors.zipcode_to)}
                          helperText={touched.zipcode_to && errors.zipcode_to}
                        />
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
              {/* <Grid item xs={12}>
                <FormControl
                  value={tipoP}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value === 'sobre') {
                      setFieldValue('height', 0.2);
                      setFieldValue('width', 10);
                      setFieldValue('length', 20);
                      setFieldValue('weight', 0.1);
                    } else {
                      setFieldValue('height', 10);
                      setFieldValue('width', 10);
                      setFieldValue('length', 10);
                      setFieldValue('weight', 0.5);
                    }
                    setTipoP(value);
                  }}
                >
                  <FormLabel>Tipo de envio</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="sobre"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel value="sobre" control={<Radio />} label="Sobre" />
                    <FormControlLabel value="paquete" control={<Radio />} label="Paquete" />
                  </RadioGroup>
                </FormControl>
              </Grid> */}
              {/* {tipoP === 'paquete' && (
                <Grid item xs={12}>
                  <Card>
                    <CardHeader title="Detalles del paquete" />
                    <CardContent>
                      <Grid container spacing={2}>
                        <Grid item xs={6} md={6}>
                          <TextField
                            label="Peso (KG)"
                            fullWidth
                            name="weight"
                            {...getFieldProps('weight')}
                            error={Boolean(touched.weight && errors.weight)}
                            helperText={touched.weight && errors.weight}
                          />
                        </Grid>
                        <Grid item xs={6} md={6}>
                          <TextField
                            label="Ancho (CM)"
                            fullWidth
                            name="width"
                            {...getFieldProps('width')}
                            error={Boolean(touched.width && errors.width)}
                            helperText={touched.width && errors.width}
                          />
                        </Grid>
                        <Grid item xs={6} md={6}>
                          <TextField
                            label="Largo (CM)"
                            fullWidth
                            name="length"
                            {...getFieldProps('length')}
                            error={Boolean(touched.length && errors.length)}
                            helperText={touched.length && errors.length}
                          />
                        </Grid>
                        <Grid item xs={6} md={6}>
                          <TextField
                            label="Alto (CM)"
                            fullWidth
                            name="height"
                            {...getFieldProps('height')}
                            error={Boolean(touched.length && errors.length)}
                            helperText={touched.length && errors.length}
                          />
                        </Grid>
                      </Grid>
                    </CardContent>
                  </Card>
                </Grid>
              )} */}
              <Grid item xs={12}>
                <LoadingButton type="submit" variant="contained" loading={isSubmitting} fullWidth>
                  Cotizar
                </LoadingButton>
              </Grid>
            </Grid>
          </Form>
        </FormikProvider>
      </CardContent>
    </Card>
  );
}
