import * as Yup from 'yup';
import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Form, FormikProvider, useFormik } from 'formik';
import { Box, Card, Grid, Stack, TextField, Typography, FormHelperText, Button, Switch } from '@mui/material';
import { useDispatch } from 'react-redux';
import { firestore } from '../../../contexts/FirebaseContext';
import { setIdSelectedRemit, setIdSelectedDesti, addTemporalDirection } from '../../../redux/slices/dagpacket';
import { LoadingButton } from '@mui/lab';
import { editValues, getInternational, initialValues } from '../direcciones/dialogDirectionUtil';
import { DirectionSimpleDialog } from '../direcciones/DirectionSimpleDialog';
import { useSnackbar } from 'notistack';
import useAutocompleteGoogleMaps from '../../../hooks/components/useAutocompleteGoogleMaps';
import { removeSpcialCharacters } from '../../../utils/formatText';
import AutoCompleteGoogleMaps from '../../maps/autocomplete/AutoCompleteGoogleMaps';
import useAuthUsers from '../../../hooks/useAuthUsers';

export const NewDirectionSchema = Yup.object().shape({
  name: Yup.string()
    .required('El nombre es requerido')
    .max(35, 'ingrese un maximo de 35 caracteres')
    .matches(/^[aA-zZ0-9\s]+$/, 'Ingrese solo letras'),
  email: Yup.string().required('El email es requerido').email('Ingrese email valido'),
  phone: Yup.string()
    .max(10, 'El telefono debe tener 10 numeros')
    .min(10, 'El telefono debe tener 10 numeros')
    .required('El numero de telefono es requerido'),
  street: Yup.string()
    .required('La direccion es requerido')
    .max(39, '39 caracteres como maximo')
    .matches(/^[aA-zZ0-9\s]+$/, 'Ingrese solo letras'),
  exterior_number: Yup.string()
    .required('El numero exterior es requerido')
    .matches(/^[aA-zZ0-9\s]+$/, 'Ingrese solo números'),
  colonia: Yup.string()
    .required('La colonia es requerida')
    .matches(/^[aA-zZ0-9\s]+$/, 'Ingrese solo letras'),
  company: Yup.string(),
  role: Yup.string(),
  estado: Yup.string().required('Ingrese el estado'),
  ciudad: Yup.string().required('Ingrese la ciudad'),
  pais: Yup.string()
});

export default function DireccionForm({
  dataDireccion,
  handleClose,
  user,
  originDirection,
  reason = 'create',
  title = false,
  onlyDirection = false,
  cpNotEdit = ''
}) {
  const dispatch = useDispatch();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [openDirection, setOpenDirection] = useState(true);
  const [submitAction, setSubmitAction] = useState(null);
  const { enqueueSnackbar } = useSnackbar();
  const { currentUser } = useAuthUsers();

  const selectDirection = (originDirection, id) => {
    if (originDirection === 'remit' || originDirection === 'remitente') dispatch(setIdSelectedRemit(id));
    if (originDirection === 'desti' || originDirection === 'destinatario') dispatch(setIdSelectedDesti(id));
  };

  const formik = useFormik({
    enableReinitialize: true,
    initialValues,
    validationSchema: NewDirectionSchema,
    onSubmit: async (values) => {
      const data = {};

      Object.keys(values).forEach((key) => {
        const value = values[key];
        data[key] = typeof value === 'string' ? value.trim() : value;
      });

      if (cpNotEdit) {
        if (cpNotEdit !== data.zipcode)
          return enqueueSnackbar(`El código postal no puede ser cambiado debe ser ${cpNotEdit}`, { variant: 'error' });
      }

      data.phone = data.phone?.toString();
      data.interior_number = data.interior_number === '' ? '' : data.interior_number;
      data.isInternational = getInternational(data.pais);
      setLoading(true);

      if (submitAction === 'unSave') {
        data.id = Date.now().toString();
        dispatch(addTemporalDirection({ ...data, directionTemporal: true }));
        selectDirection(originDirection, data.id);
        handleClose();
        return;
      }

      try {
        if (reason === 'create') {
          data.user = user.id;
          data.hostUser = currentUser.hostUser;
          data.created_at = new Date();
          const response = await firestore.collection('direcciones').add(data);
          if (submitAction === 'select') selectDirection(originDirection, response.id);
        } else if (reason === 'update') {
          data.updated_at = new Date();
          await firestore.collection('direcciones').doc(dataDireccion.id).update(data);
          if (submitAction === 'select') selectDirection(originDirection, dataDireccion.id);
        }
        enqueueSnackbar(reason === 'create' ? 'Guardado correctamente' : 'Actualizado correctamente', {
          variant: 'success'
        });
        setLoading(false);
        handleClose();
      } catch (error) {
        console.log(error);
        setLoading(false);
        enqueueSnackbar('No se pudo hacer la operación', { variant: 'error' });
      }
    }
  });

  const deleteAddress = (id) => {
    firestore
      .collection('direcciones')
      .doc(id)
      .delete()
      .then(() => {
        enqueueSnackbar('Eliminado con éxito', { variant: 'error' });
      })
      .catch(() => {
        enqueueSnackbar('No se pudo hacer la operación', { variant: 'success' });
      });
  };

  const { errors, setValues, touched, handleSubmit, setFieldValue, getFieldProps } = formik;

  const { handleAutocompleteValues, detalleUbicacion, address } = useAutocompleteGoogleMaps();

  useEffect(() => {
    setFieldValue('pais', removeSpcialCharacters(detalleUbicacion?.pais));
    setFieldValue('direccion', removeSpcialCharacters(detalleUbicacion?.address));
    setFieldValue('zipcode', removeSpcialCharacters(detalleUbicacion?.codPost));
    setFieldValue('estado', removeSpcialCharacters(detalleUbicacion?.estado));
    setFieldValue('ciudad', removeSpcialCharacters(detalleUbicacion?.ciudad));
    setFieldValue('colonia', removeSpcialCharacters(detalleUbicacion?.colonia));
    setFieldValue('street', removeSpcialCharacters(detalleUbicacion?.calle));
    setFieldValue('exterior_number', removeSpcialCharacters(detalleUbicacion?.numCalle));
    setFieldValue('isInternational', getInternational(detalleUbicacion?.pais));
  }, [detalleUbicacion, setFieldValue]);

  useEffect(() => {
    if (reason === 'update') {
      setValues(editValues(dataDireccion));
    }
  }, [dataDireccion, reason, setValues]);

  useEffect(() => {
    if (reason === 'update') setOpenDirection(false);
  }, [reason]);

  useEffect(() => {
    if (originDirection === 'remit') {
      setFieldValue('zipcode', queryParams?.get('zipcode_from')?.toString() || '');
      setFieldValue('ciudad', queryParams?.get('city_from')?.toString() || '');
    } else if (originDirection === 'desti') {
      setFieldValue('zipcode', queryParams?.get('zipcode_to')?.toString() || '');
      setFieldValue('ciudad', queryParams?.get('city_to')?.toString() || '');
    }
  }, [originDirection, setFieldValue]);

  return (
    <FormikProvider value={formik}>
      111{cpNotEdit}
      <Form noValidate onSubmit={handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={12}>
            <Card sx={{ p: 3 }}>
              {title && (
                <Typography variant="h4" textAlign="center" mb={2}>
                  {reason === 'create' ? 'Agregar' : 'Actualizar'} Dirección
                </Typography>
              )}
              <Stack spacing={3}>
                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="Nombre completo"
                    {...getFieldProps('name')}
                    error={Boolean(touched.name && errors.name)}
                    helperText={touched.name && errors.name}
                  />
                </Stack>

                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="Correo electronico"
                    type="email"
                    {...getFieldProps('email')}
                    error={Boolean(touched.email && errors.email)}
                    helperText={touched.email && errors.email}
                  />
                  <TextField
                    fullWidth
                    label="Numero telefonico"
                    type="number"
                    {...getFieldProps('phone')}
                    error={Boolean(touched.phone && errors.phone)}
                    helperText={touched.phone && errors.phone}
                  />
                </Stack>

                {reason === 'update' && !onlyDirection && (
                  <Box mt={4} onClick={() => setOpenDirection((o) => !o)} sx={{ cursor: 'pointer' }}>
                    <Switch value={openDirection} />
                    Actualizar una nueva Dirección
                  </Box>
                )}
                <Box mt={2} mb={2}>
                  {openDirection && <AutoCompleteGoogleMaps handleAutocompleteValues={handleAutocompleteValues} />}
                </Box>

                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="País"
                    {...getFieldProps('pais')}
                    error={Boolean(touched.pais && errors.pais)}
                    helperText={touched.pais && errors.pais}
                    InputProps={{
                      readOnly: onlyDirection
                    }}
                    sx={{ opacity: onlyDirection ? 0.5 : 1 }}
                  />
                  <TextField
                    fullWidth
                    sx={{ opacity: onlyDirection ? 0.5 : 1 }}
                    InputProps={{
                      readOnly: onlyDirection
                    }}
                    label="Codigo ZIP"
                    {...getFieldProps('zipcode')}
                    error={Boolean(touched.zipcode && errors.zipcode)}
                    helperText={touched.zipcode && errors.zipcode}
                  />
                </Stack>

                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="Estado"
                    {...getFieldProps('estado')}
                    error={Boolean(touched.estado && errors.estado)}
                    helperText={touched.estado && errors.estado}
                    sx={{ opacity: onlyDirection ? 0.5 : 1 }}
                    InputProps={{
                      readOnly: onlyDirection
                    }}
                  />
                  <TextField
                    fullWidth
                    sx={{ opacity: onlyDirection ? 0.5 : 1 }}
                    InputProps={{
                      readOnly: onlyDirection
                    }}
                    label="Ciudad"
                    {...getFieldProps('ciudad')}
                    error={Boolean(touched.ciudad && errors.ciudad)}
                    helperText={touched.ciudad && errors.ciudad}
                  />
                </Stack>

                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="Colonia"
                    {...getFieldProps('colonia')}
                    error={Boolean(touched.colonia && errors.colonia)}
                    helperText={touched.colonia && errors.colonia}
                  />

                  <TextField
                    fullWidth
                    label="Calle"
                    {...getFieldProps('street')}
                    error={Boolean(touched.street && errors.street)}
                    helperText={touched.street && errors.street}
                  />
                </Stack>

                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="Numero exterior"
                    {...getFieldProps('exterior_number')}
                    error={Boolean(touched.exterior_number && errors.exterior_number)}
                    helperText={touched.exterior_number && errors.exterior_number}
                  />
                  <TextField
                    fullWidth
                    label="Numero interior"
                    {...getFieldProps('interior_number')}
                    error={Boolean(touched.interior_number && errors.interior_number)}
                    helperText={touched.interior_number && errors.interior_number}
                  />
                </Stack>

                <Stack direction={{ xs: 'column', sm: 'row' }} spacing={{ xs: 3, sm: 2 }}>
                  <TextField
                    fullWidth
                    label="Referencia"
                    {...getFieldProps('reference')}
                    error={Boolean(touched.reference && errors.reference)}
                    helperText={touched.reference && errors.reference}
                  />
                </Stack>

                <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end', gap: '15px' }}>
                  {reason === 'update' && (
                    <Button
                      variant="contained"
                      color="error"
                      loading={loading}
                      fullWidth
                      onClick={() => {
                        setOpen(true);
                      }}
                    >
                      Eliminar
                    </Button>
                  )}
                  {originDirection !== null ? (
                    <>
                      <LoadingButton
                        loading={loading}
                        sx={{ textTransform: 'initial' }}
                        variant="contained"
                        fullWidth
                        onClick={() => {
                          setSubmitAction('select');
                          handleSubmit();
                        }}
                      >
                        {reason === 'update' ? 'Actualizar' : 'Guardar'} y selecionar
                      </LoadingButton>
                      <Button
                        sx={{ textTransform: 'initial' }}
                        color="secondary"
                        variant="contained"
                        fullWidth
                        onClick={() => {
                          setSubmitAction('unSave');
                          handleSubmit();
                        }}
                      >
                        Selecionar
                      </Button>
                    </>
                  ) : (
                    <LoadingButton
                      loading={loading}
                      sx={{ textTransform: 'initial' }}
                      variant="contained"
                      fullWidth
                      type="submit"
                    >
                      {reason === 'update' ? 'Actualizar' : 'Guardar'}
                    </LoadingButton>
                  )}
                </Box>
              </Stack>
            </Card>
          </Grid>
        </Grid>
      </Form>
      <DirectionSimpleDialog
        open={open}
        handleClose={() => {
          setOpen(false);
          handleClose();
        }}
        deleteDirection={() => deleteAddress(dataDireccion.id)}
      />
    </FormikProvider>
  );
}
