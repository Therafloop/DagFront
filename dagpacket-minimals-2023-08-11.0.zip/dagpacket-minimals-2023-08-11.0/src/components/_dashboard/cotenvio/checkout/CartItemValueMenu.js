import { Icon } from '@iconify/react';
import { IconButton, Menu, MenuItem } from '@mui/material';
import React from 'react';
import { fCurrency } from '../../../../utils/formatNumber';

function CartItemValueMenu({ providerValue, empaquetadoValue }) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <IconButton
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
        size="small"
      >
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>

      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button'
        }}
      >
        <MenuItem>Precio envio: {fCurrency(providerValue)}</MenuItem>
        {empaquetadoValue && <MenuItem>Precio empaque: {fCurrency(empaquetadoValue)}</MenuItem>}
      </Menu>
    </div>
  );
}

export default CartItemValueMenu;
