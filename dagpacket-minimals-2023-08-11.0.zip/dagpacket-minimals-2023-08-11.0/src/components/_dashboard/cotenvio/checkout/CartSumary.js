import PropTypes from 'prop-types';
// import { Icon } from '@iconify/react';
// import editFill from '@iconify/icons-eva/edit-fill';
// material
import { Box, Card, Stack, Divider, CardHeader, Typography, CardContent } from '@mui/material';
// utils
import { fCurrency } from '../../../../utils/formatNumber';
import DialogDescuentos from './descuentos/DialogDescuentos';
import useUserRole from '../../../../hooks/useUserRole';
import DialogCupones from './cupones/DialogCupones';

// ----------------------------------------------------------------------

CartSumary.propTypes = {
  total: PropTypes.number,
  subtotal: PropTypes.number
};

export default function CartSumary({ paquetes, servRec, products }) {
  // console.log(paquetes, servRec, products);
  const { actualRol } = useUserRole();
  const { admitByRoleName } = useUserRole();
  const roleId = actualRol?.displayName;
  console.log(actualRol);
  return (
    <Card sx={{ mb: 3 }}>
      <CardHeader
        title="Sumario de Compra"
        // action={
        //   enableEdit && (
        //     <Button size="small" type="button" onClick={onEdit} startIcon={<Icon icon={editFill} />}>
        //       Edit
        //     </Button>
        //   )
        // }
      />

      <CardContent>
        <Stack spacing={2}>
          {paquetes.cart.length > 0 && (
            <Card sx={{ padding: '10px' }}>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Sub Total Paquetes
                </Typography>
                <Typography variant="subtitle2">{fCurrency(paquetes.subtotal)}</Typography>
              </Stack>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Sub Total Empaquetado
                </Typography>
                <Typography variant="subtitle2">{fCurrency(paquetes.subtotalEmpaquetado)}</Typography>
              </Stack>

              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Descuento
                </Typography>
                <Typography variant="subtitle2">{fCurrency(paquetes.discount)}</Typography>
              </Stack>

              {admitByRoleName(['almighty', 'plus', 'basic', 'lite'], ['cajero']) && (
                <Box sx={{ marginTop: '10px' }}>
                  <DialogDescuentos />
                </Box>
              )}

              {admitByRoleName(['almighty', 'plus', 'basic', 'lite'], ['cajero']) && (
                <Box sx={{ marginTop: '10px' }}>
                  <DialogCupones />
                </Box>
              )}
            </Card>
          )}
          {products.cart.length > 0 && (
            <Card sx={{ padding: '10px' }}>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Sub Total Productos
                </Typography>
                <Typography variant="subtitle2">{fCurrency(products.subtotal)}</Typography>
              </Stack>

              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Descuento
                </Typography>
                <Typography variant="subtitle2">{/* {discount ? fCurrency(-discount) : '-'} */}-</Typography>
              </Stack>
            </Card>
          )}
          {servRec.cart.length > 0 && (
            <Card sx={{ padding: '10px' }}>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Sub Total Servicios
                </Typography>
                <Typography variant="subtitle2">{fCurrency(servRec.subtotal)}</Typography>
              </Stack>

              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                  Descuento
                </Typography>
                <Typography variant="subtitle2">{/* {discount ? fCurrency(-discount) : '-'} */}-</Typography>
              </Stack>
            </Card>
          )}

          {/* <Stack direction="row" justifyContent="space-between">
            <Typography variant="body2" sx={{ color: 'text.secondary' }}>
              Shipping
            </Typography>
            <Typography variant="subtitle2">dg</Typography>
          </Stack> */}

          <Divider />

          <Stack direction="row" justifyContent="space-between">
            <Typography variant="subtitle1">Total</Typography>
            <Box sx={{ textAlign: 'right' }}>
              <Typography variant="subtitle1" sx={{ color: 'error.main' }}>
                {fCurrency(servRec.total + paquetes.total + products.total)}
              </Typography>
              {/* <Typography variant="caption" sx={{ fontStyle: 'italic' }}>
                (VAT included if applicable)
              </Typography> */}
            </Box>
          </Stack>
        </Stack>
      </CardContent>
    </Card>
  );
}
