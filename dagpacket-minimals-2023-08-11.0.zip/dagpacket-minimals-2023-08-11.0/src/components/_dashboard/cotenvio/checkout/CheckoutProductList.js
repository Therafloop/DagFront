import PropTypes from 'prop-types';
import { Icon } from '@iconify/react';
import plusFill from '@iconify/icons-eva/plus-fill';
import minusFill from '@iconify/icons-eva/minus-fill';
import trash2Fill from '@iconify/icons-eva/trash-2-fill';
// material
import { styled } from '@mui/material/styles';
import { Box, Table, TableRow, TableBody, TableCell, TableHead, Typography, TableContainer } from '@mui/material';
// utils
// import getColorName from '../../../../utils/getColorName';
import { fCurrency } from '../../../../utils/formatNumber';
//
import { MIconButton } from '../../../@material-extend';

// ----------------------------------------------------------------------

const IncrementerStyle = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: theme.spacing(0.5),
  padding: theme.spacing(0.5, 0.75),
  borderRadius: theme.shape.borderRadius,
  border: `solid 1px ${theme.palette.grey[500_32]}`
}));

// ----------------------------------------------------------------------

Incrementer.propTypes = {
  available: PropTypes.number,
  quantity: PropTypes.number,
  onIncrease: PropTypes.func,
  onDecrease: PropTypes.func
};

function Incrementer({ available, quantity, onIncrease, onDecrease }) {
  return (
    <Box sx={{ width: 96, textAlign: 'right' }}>
      <IncrementerStyle>
        <MIconButton size="small" color="inherit" onClick={onDecrease} disabled={quantity <= 1}>
          <Icon icon={minusFill} width={16} height={16} />
        </MIconButton>
        {quantity}
        <MIconButton size="small" color="inherit" onClick={onIncrease} disabled={quantity >= available}>
          <Icon icon={plusFill} width={16} height={16} />
        </MIconButton>
      </IncrementerStyle>
      <Typography variant="caption" sx={{ color: 'text.secondary' }}>
        available: {available}
      </Typography>
    </Box>
  );
}

ProductList.propTypes = {
  formik: PropTypes.object.isRequired,
  onDelete: PropTypes.func
  // onDecreaseQuantity: PropTypes.func,
  // onIncreaseQuantity: PropTypes.func
};

export default function ProductList({ formik, onDelete }) {
  const { products } = formik.values;
  // console.log(products);

  return (
    <TableContainer sx={{ minWidth: 720 }}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Product</TableCell>
            <TableCell align="left">Price</TableCell>
            {/* <TableCell align="left">Quantity</TableCell> */}
            <TableCell>Dimensiones</TableCell>
            {/* <TableCell align="right">Total Price</TableCell> */}
            <TableCell align="right" />
          </TableRow>
        </TableHead>

        <TableBody>
          {products.map((product, id) => {
            const {
              id_object,
              city_from,
              city_to,
              shippingValue,
              street_from,
              street_to,
              weight,
              width,
              height,
              length
            } = product;
            return (
              <TableRow key={id}>
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box>
                      <Typography noWrap variant="h5" sx={{ maxWidth: 240, mb: 0.5 }}>
                        {city_from} a {city_to}
                      </Typography>

                      <Typography noWrap variant="subtitle2" sx={{ maxWidth: 240, mb: 0.5 }}>
                        Calle de origen: {street_from}
                      </Typography>
                      <Typography noWrap variant="subtitle2" sx={{ maxWidth: 240, mb: 0.5 }}>
                        Calle de destino: {street_to}
                      </Typography>
                    </Box>
                  </Box>
                </TableCell>

                <TableCell align="left">{fCurrency(shippingValue)}</TableCell>
                <TableCell align="left">
                  <Typography>Ancho: {width} cm</Typography>
                  <Typography>Largo: {length} cm</Typography>
                  <Typography>Alto: {height} cm</Typography>
                  <Typography>Peso: {weight} kg</Typography>
                </TableCell>

                <TableCell align="right">
                  <MIconButton onClick={() => onDelete(id_object)}>
                    <Icon icon={trash2Fill} width={20} height={20} />
                  </MIconButton>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
