import { Icon } from '@iconify/react';
import { Box, Button, Chip, CircularProgress, IconButton, MenuItem, TextField } from '@mui/material';
import { useSnackbar } from 'notistack';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { updateCartAction, updateCartItem } from '../../../../../../redux/slices/dagpacket';
import { firestore } from '../../../../../../contexts/FirebaseContext';
import useAuthUsers from '../../../../../../hooks/useAuthUsers';
import { LoadingButton } from '@mui/lab';

const optionAction = [
  { value: 'discount', label: 'Descontar', simbol: '-' },
  { value: 'increase', label: 'Aumentar', simbol: '+' }
];

function AplicarDescuento2({ dataItem, descUserData }) {
  const [loading, setLoading] = useState(false);
  // const [descuentoIncrementoValue, setDescuentoIncrementoValue] = useState('');
  // const [actionTypeValue, setActionTypeValue] = useState('discount');

  const dispatch = useDispatch();
  const { currentUser } = useAuthUsers();

  const { enqueueSnackbar } = useSnackbar();

  // const applyAction = (value1, value2) => {
  //   if (actionTypeValue === 'discount') {
  //     return value1 - value2;
  //   }

  //   return value1 + value2;
  // };

  const applyDiscount = async () => {
    setLoading(true);
    const descuentoIncrementoValue = Number(dataItem.originalShippingValue) * Number(descUserData.descuentoValue / 100);

    // const obj = {
    //   descuentoIncremento: true,
    //   descuentoIncrementoType: 'discount',
    //   descuentoIncrementoValue: Number(descuentoIncrementoValue),
    //   shippingValue: Number(dataItem.originalShippingValue) - Number(descuentoIncrementoValue),
    //   // utilidad: Number(dataItem.originalUtilidad), Number(descuentoIncrementoValue),
    //   // utilidadLicen: utilidadLicenciatario - Number(descuentoIncrementoValue),
    //   utilidadEnvioLicen: Number(dataItem.originalUtilidadEnvioLicen), Number(descuentoIncrementoValue),
    //   descuentoIncrementoDate: new Date(),
    //   updated_at: new Date()
    // };
    // await firestore.collection('cotizaciones').doc(dataItem.object_id).update(obj);

    // const updatedObj = await (await firestore.collection('cotizaciones').doc(dataItem.object_id).get()).data();

    // dispatch(updateCartAction(updatedObj));

    // await firestore.collection('reg_descuentoIncremento').add({
    //   userId: currentUser.id,
    //   itemAplicado: dataItem.object_id,
    //   descuentoIncrementoType: 'discount',
    //   descuentoIncrementoValue: Number(descuentoIncrementoValue),
    //   originalValue: Number(dataItem.originalShippingValue),
    //   resultValue: Number(dataItem.originalShippingValue) - Number(descuentoIncrementoValue),
    //   createdAt: new Date(),
    //   updatedAt: new Date()
    // });

    // enqueueSnackbar('Descuento aplicado.', { variant: 'success' });

    setLoading(false);
  };

  return (
    <Box>
      <Box>
        <LoadingButton onClick={applyDiscount} variant="contained" size="small">
          Descontar
        </LoadingButton>
      </Box>
      {/* {!dataItem.descuentoIncremento ? (
        <Box>
          <TextField
            id="outlined-select-currency"
            select
            size="small"
            label="Select"
            onChange={(e) => setActionTypeValue(e.target.value)}
            value={actionTypeValue}
          >
            {optionAction.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            value={descuentoIncrementoValue}
            onChange={(e) => setDescuentoIncrementoValue(e.target.value)}
            type="number"
            label="valor"
            size="small"
            sx={{ width: '150px' }}
          />
          <>
            {!loading && (
              <IconButton color="info" disabled={!descuentoIncrementoValue} onClick={applyDiscount}>
                <Icon icon="el:ok-sign" />
              </IconButton>
            )}
            {loading && <CircularProgress size="small" />}
          </>
        </Box>
      ) : (
        <Chip label="Aplicado" />
      )} */}
    </Box>
  );
}

export default AplicarDescuento2;
