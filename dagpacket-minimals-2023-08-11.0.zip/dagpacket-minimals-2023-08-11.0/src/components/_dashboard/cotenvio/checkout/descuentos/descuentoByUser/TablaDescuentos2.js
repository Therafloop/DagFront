import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import useAuthUsers from '../../../../../../hooks/useAuthUsers';
import { firestore } from '../../../../../../contexts/FirebaseContext';
import PaqueteriaAvatar from '../../../../paquetes/general/PaqueteriaAvatar';
import AplicarDescuento from '../AplicarDescuento';
import AplicarDescuento2 from './AplicarDescuento2';

function TablaDescuentos2() {
  const [descUserData, setDescUserData] = useState(null);
  const { checkout } = useSelector((state) => state.dagpacket);
  const { cart } = checkout;
  const { currentUser } = useAuthUsers();

  // const filteredItems = cart.filter((item) => item.aptoParaDescuento === true);
  const filteredItems = cart.filter((item) => item.aptoParaDescuentoIncremento === true);

  console.log(cart);

  useEffect(() => {
    async function getDataDescuentoUser() {
      const res = await (await firestore.collection('descuento_usersReg').doc(currentUser.id).get()).data();
      setDescUserData(res);
    }

    getDataDescuentoUser();
  }, [currentUser.id]);

  return (
    <>
      {filteredItems.length > 0 && (
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell> </TableCell>
                <TableCell>Origen</TableCell>
                <TableCell>Destino</TableCell>
                <TableCell>Precio total</TableCell>
                <TableCell>Disponible para desc.</TableCell>
                <TableCell>Descuento</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredItems.map((item) => (
                <TableRow key={item.object_id} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                  <TableCell component="th">
                    <Box sx={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                      <PaqueteriaAvatar rate_provider={item.rate_provider} size="small" />
                      <Typography variant="subtitle2">{item.rate_provider}</Typography>
                    </Box>
                  </TableCell>
                  <TableCell>{item.city_from}</TableCell>
                  <TableCell>{item.city_to}</TableCell>
                  <TableCell>{item.shippingValue}</TableCell>
                  <TableCell>{item.originalUtilidadEnvioLicen}</TableCell>
                  <TableCell>
                    <AplicarDescuento2 dataItem={item} descUserData={descUserData} />
                    {/* <Button variant="contained" size="small">
                  Descuento
                </Button> */}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {filteredItems.length === 0 && <Typography>No hay items disponibles para descuetnos</Typography>}
    </>
  );
}

export default TablaDescuentos2;
