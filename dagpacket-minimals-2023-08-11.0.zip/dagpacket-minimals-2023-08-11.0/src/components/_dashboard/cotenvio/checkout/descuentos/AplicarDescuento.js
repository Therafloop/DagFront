import { Icon } from '@iconify/react';
import { Box, Chip, CircularProgress, IconButton, MenuItem, TextField } from '@mui/material';
import { useSnackbar } from 'notistack';
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { updateCartAction, updateCartItem } from '../../../../../redux/slices/dagpacket';
import { firestore } from '../../../../../contexts/FirebaseContext';
import useAuthUsers from '../../../../../hooks/useAuthUsers';
import { LoadingButton } from '@mui/lab';

const optionAction = [
  { value: 'discount', label: 'Descontar', simbol: '-' },
  { value: 'increase', label: 'Aumentar', simbol: '+' }
];

function AplicarDescuento({ dataItem }) {
  const [loading, setLoading] = useState(false);
  const [descuentoIncrementoValue, setDescuentoIncrementoValue] = useState('');
  const [actionTypeValue, setActionTypeValue] = useState('discount');

  console.log(actionTypeValue);

  const dispatch = useDispatch();
  const { currentUser } = useAuthUsers();

  const { enqueueSnackbar } = useSnackbar();

  const applyAction = (value1, value2) => {
    if (actionTypeValue === 'discount') {
      return value1 - value2;
    }

    return value1 + value2;
  };

  const applyDiscount = async () => {
    setLoading(true);
    const utilidadLicenciatario = dataItem?.originalUtilidadLicen
      ? Number(dataItem?.originalUtilidadLicen)
      : Number(dataItem?.originalUtilidad) * 0.7;

    if (utilidadLicenciatario >= Number(descuentoIncrementoValue) && actionTypeValue === 'discount') {
      const obj = {
        descuentoIncremento: true,
        descuentoIncrementoType: actionTypeValue,
        descuentoIncrementoValue: Number(descuentoIncrementoValue),
        shippingValue: applyAction(Number(dataItem.originalShippingValue), Number(descuentoIncrementoValue)),
        utilidad: applyAction(Number(dataItem.originalUtilidad), Number(descuentoIncrementoValue)),
        utilidadLicen: utilidadLicenciatario - Number(descuentoIncrementoValue),
        utilidadEnvioLicen: applyAction(Number(dataItem.originalUtilidadEnvioLicen), Number(descuentoIncrementoValue)),
        descuentoIncrementoDate: new Date(),
        updated_at: new Date()
      };
      await firestore.collection('cotizaciones').doc(dataItem.object_id).update(obj);

      const updatedObj = await (await firestore.collection('cotizaciones').doc(dataItem.object_id).get()).data();

      dispatch(updateCartAction(updatedObj));

      await firestore.collection('reg_descuentoIncremento').add({
        userId: currentUser.id,
        itemAplicado: dataItem.object_id,
        descuentoIncrementoType: actionTypeValue,
        descuentoIncrementoValue: Number(descuentoIncrementoValue),
        originalValue: Number(dataItem.originalShippingValue),
        resultValue: applyAction(Number(dataItem.originalShippingValue), Number(descuentoIncrementoValue)),
        createdAt: new Date(),
        updatedAt: new Date()
      });

      enqueueSnackbar('Descuento aplicado.', { variant: 'success' });

      setLoading(false);
    } else if (actionTypeValue === 'increase') {
      const obj = {
        descuentoIncremento: true,
        descuentoIncrementoType: actionTypeValue,
        descuentoIncrementoValue: Number(descuentoIncrementoValue),
        shippingValue: applyAction(Number(dataItem.originalShippingValue), Number(descuentoIncrementoValue)),
        utilidad: applyAction(Number(dataItem.originalUtilidad), Number(descuentoIncrementoValue)),
        utilidadLicen: utilidadLicenciatario - Number(descuentoIncrementoValue),
        utilidadEnvioLicen: applyAction(Number(dataItem.originalUtilidadEnvioLicen), Number(descuentoIncrementoValue)),
        descuentoIncrementoDate: new Date(),
        updated_at: new Date()
      };
      await firestore.collection('cotizaciones').doc(dataItem.object_id).update(obj);

      const updatedObj = await (await firestore.collection('cotizaciones').doc(dataItem.object_id).get()).data();

      dispatch(updateCartAction(updatedObj));

      await firestore.collection('reg_descuentoIncremento').add({
        userId: currentUser.id,
        itemAplicado: dataItem.object_id,
        descuentoIncrementoType: actionTypeValue,
        descuentoIncrementoValue: Number(descuentoIncrementoValue),
        originalValue: Number(dataItem.originalShippingValue),
        resultValue: applyAction(Number(dataItem.originalShippingValue), Number(descuentoIncrementoValue)),
        createdAt: new Date(),
        updatedAt: new Date()
      });

      enqueueSnackbar('Proceso aplicado aplicado.', { variant: 'success' });

      setLoading(false);
    } else {
      enqueueSnackbar('El descuento no puede ser mayor que la utilidad del usuario.', { variant: 'error' });
      setLoading(false);
    }
  };

  return (
    <Box>
      {/* <Box>
        <TextField
          id="outlined-select-currency"
          select
          size="small"
          label="Select"
          onChange={(e) => setActionTypeValue(e.target.value)}
          value={actionTypeValue}
        >
          {optionAction.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          value={descuentoIncrementoValue}
          onChange={(e) => setDescuentoIncrementoValue(e.target.value)}
          type="number"
          label="valor"
          size="small"
          sx={{ width: '150px' }}
        />
        <>
          {!loading && (
            <IconButton color="info" disabled={!descuentoIncrementoValue} onClick={applyDiscount}>
              <Icon icon="el:ok-sign" />
            </IconButton>
          )}
          {loading && <CircularProgress size="small" />}
        </>
      </Box> */}
      {!dataItem.descuentoIncremento ? (
        <Box sx={{ display: 'flex' }}>
          <TextField
            id="outlined-select-currency"
            select
            size="small"
            label="Select"
            onChange={(e) => setActionTypeValue(e.target.value)}
            value={actionTypeValue}
          >
            {optionAction.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
          <TextField
            value={descuentoIncrementoValue}
            onChange={(e) => setDescuentoIncrementoValue(e.target.value)}
            type="number"
            label="valor"
            size="small"
            sx={{ width: '150px' }}
          />
          <LoadingButton
            // size="small"
            loading={loading}
            variant="contained"
            disabled={!descuentoIncrementoValue}
            onClick={applyDiscount}
          >
            Aplicar
          </LoadingButton>
          {/* <>
            {!loading && (
              <LoadingButton
                // size="small"
                variant="contained"
                disabled={!descuentoIncrementoValue}
                onClick={applyDiscount}
              >
                Aplicar
              </LoadingButton>
            )}
            {loading && <CircularProgress size="small" />}
          </> */}
        </Box>
      ) : (
        <Chip label="Aplicado" />
      )}
    </Box>
  );
}

export default AplicarDescuento;
