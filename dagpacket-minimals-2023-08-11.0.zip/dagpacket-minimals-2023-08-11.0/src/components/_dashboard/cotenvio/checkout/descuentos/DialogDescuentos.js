import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import TablaDescuentos from './TablaDescuentos';
import TablaDescuentos2 from './descuentoByUser/TablaDescuentos2';
import useUserRole from '../../../../../hooks/useUserRole';

export default function DialogDescuentos() {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <Button fullWidth variant="contained" size="small" onClick={() => setOpenDialog(true)}>
        Aplicar descuento
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </>
  );
}

function DialogBody({ open, onClose }) {
  const { actualRol, admitByUserType, admitByRoleName } = useUserRole();

  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        {/* {admitByUserType(['ADMIN', 'LICENCIATARIO', '']) && <TablaDescuentos />} */}
        {admitByRoleName(['almighty', 'plus', 'basic', 'lite'], ['cajero']) && <TablaDescuentos />}
        {/* <TablaDescuentos2 /> */}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
