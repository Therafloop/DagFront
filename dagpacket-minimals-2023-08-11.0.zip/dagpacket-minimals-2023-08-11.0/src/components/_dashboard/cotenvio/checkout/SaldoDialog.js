/* eslint-disable no-const-assign */
import React, { useEffect, useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import {
  getConvertCompras,
  hacerEnvioRedpack,
  hacerEnvioSuperEnvios,
  hacerEnvioUPS
} from '../../../../_apis_/dagpacket';
import { analytics, firestore } from '../../../../contexts/FirebaseContext';
import {
  resetCart,
  setItemsError,
  setItemsSuccess,
  setLoopCounter,
  setCollectedMoney,
  resetLoopCounter,
  resetItemsSuccess,
  resetItemsError,
  resetCollectedMoney,
  updateCartItem,
  removeIdWalletToPay
} from '../../../../redux/slices/dagpacket';
import { Box, Button, Dialog, Icon, TextField, Typography } from '@mui/material';
import { fCurrency } from '../../../../utils/formatNumber';
import { LoadingButton } from '@mui/lab';
import useWallet from '../../../../hooks/useWallet';
import useAuth from '../../../../hooks/useAuth';
import { getBalanceTypeUser } from '../../../../utils/formatWallet';
import { getUserNip } from '../../../../utils/adminTools/getUserNip';
import { useSnackbar } from 'notistack';
import FinalStep from './FinalStep';
import useErrorCheckout from '../../../../hooks/errorsHooks/useErrorCheckout';
import { comprarGuia } from '../../../../_apis_/dagpacket-oneRequest';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../../constants/ticketsErrors';
import useReportError from '../../../../hooks/errorsHooks/useReportError';
import useAuthUsers from '../../../../hooks/useAuthUsers';
import useWalletEvents from '../../../../hooks/useWalletEvents';
import { comprarRecargasServicios } from '../../../../_apis_/dagpacket-recargasServicios';
import useVerifyEnvioSingleUser from '../../../../hooks/envios/useVerifyEnvioSingleUser';
import useEnvios from '../../../../hooks/envios/useEnvios';
import { analyticsEvents } from '../../../../constants/analyticsEvents';
import { contratosList } from '../../../../constants/contratos';

export default function SaldoDialog({ open, setOpen, handleSnackBar, ids }) {
  const [cancelPaymentCode, setCancelPaymentCode] = useState('');
  // const [dataConfirm, setDataConfirm] = useState({});
  const [referenceCode, setReferenceCode] = useState('');
  const [completeTransaction, setCompleteTransaction] = useState(false);
  const [loadingBtn, setLoadingBtn] = useState(false);
  const [itemsLength, setItemsLength] = useState(1);
  const [completed, setCompleted] = useState(false);
  const { checkout, paymentCheckout, idWalletToPay } = useSelector((state) => state.dagpacket);
  const { loopCounter, itemsSuccess, itemsError, collectedMoney } = paymentCheckout;
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();
  const { enqueueSnackbar } = useSnackbar();
  const { addError } = useErrorCheckout();
  const { reportError } = useReportError();
  const { verifyUserNip } = useAuthUsers();

  const { saldoPaqueteria, cobrar } = useWallet();
  const { user } = useAuth();
  const { currentUser } = useAuthUsers();
  const { handleWalletEvent } = useWalletEvents();
  const { verifyWhenTryToPay } = useVerifyEnvioSingleUser();
  const { getMontoEnvioByArray } = useEnvios();

  const handleClose = () => {
    setOpen(false);
  };

  // con esto obtenemos el id user o host user id desde el primer item de la cart dependiendo que user_rol posea el item
  const userIdEnvio =
    checkout?.cart[0]?.user_rol === 'cajero' ? checkout?.cart[0]?.hostUser_id : checkout?.cart[0]?.user_id;

  // console.log(ids);

  const regPayment = useCallback(async () => {
    // const amount = collectedMoney;

    const userId = idWalletToPay || userIdEnvio || user.id;
    const amount = await getMontoEnvioByArray(itemsSuccess, checkout?.cart, userId);

    console.log('el amount resultante-----------------', amount);
    const categoriaId = 'PAQUETERIA';

    const obj = {
      nameEvent: 'SUBSTRACT',
      ownerUserID: userId,
      category_service_id: categoriaId,
      amount,
      message: 'Pago con saldo - envio',
      reason: 'Pago saldo',
      payment_method: 'SALDO',
      payment_source: 'DAGPACKET',

      extraData: {
        concepto: 'Envio pagado con saldo',
        service: 'ENVIO',
        itemsPagados: ids,
        userOperator: currentUser.id,
        roleOperator: currentUser.role
      },

      rerport_id: '',
      reporteAction: false,
      // para que la funcion de registrar reporte se ejecute

      // array de funciones que se ejecutan si toda va bien
      successFuncts: []
      // si deseamos que el snackbar se muestre
      // successSnackbar: true
    };

    handleWalletEvent(obj).then(() => {
      setCompleted(true);
      dispatch(removeIdWalletToPay());
    });
  }, [
    idWalletToPay,
    userIdEnvio,
    user.id,
    getMontoEnvioByArray,
    itemsSuccess,
    checkout?.cart,
    ids,
    currentUser.id,
    currentUser.role,
    handleWalletEvent,
    dispatch
  ]);

  useEffect(() => {
    if (completed) {
      setLoadingBtn(false);
      setCompleteTransaction(true);
    }
  }, [completed]);

  useEffect(() => {
    if (ids.length) {
      setItemsLength(ids.length);
    }
  }, [ids]);

  useEffect(() => {
    if (loopCounter === itemsLength) {
      regPayment();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loopCounter, itemsLength]);

  useEffect(() => {
    dispatch(resetLoopCounter());
    dispatch(resetItemsSuccess());
    dispatch(resetItemsError());
    dispatch(resetCollectedMoney());
  }, [dispatch]);

  const checkSalddo = saldoPaqueteria >= checkout.total;

  const makePayment = async () => {
    setLoadingBtn(true);

    ids.map(async (id) => {
      // const { payment_method, receipt_no } = res.item;

      const itemCart = checkout.cart.find((item) => item.object_id === id);
      console.log(itemCart);
      if (itemCart.typeItem === 'RECARGA-SERVICIO') {
        console.log('recargas y servicios');
        console.log(itemCart);
        const { type, productId, accountId, enteredAmount } = itemCart;

        const obj = {
          productId,
          accountId,
          amount: enteredAmount,
          type
        };

        try {
          const res = await comprarRecargasServicios(obj);

          console.log(res);
          // await firestore.
        } catch (error) {
          const errorData = {
            error: JSON.stringify(error),
            errorAction: actionSectionIdentifier.comprarRecargasYServicios,
            section: sectionIdentifier.cartSection,
            created_at: new Date(),
            updated_at: new Date(),
            description: 'Error al comprar recargas y servicios',
            payment_method: 'SALDO',
            versionApp: localStorage.getItem('versionApp'),
            user_id: user.id,
            detalle: {
              envio_id: id,
              obj,
              rate_provider: itemCart.rate_provider
            }
          };
          console.log(errorData);

          await reportError(errorData);
          console.log(error.response);
        }
      } else {
        const { shippingValue } = itemCart;

        const provider = itemCart.provider?.split('/');
        const { empProveedor } = itemCart;

        // console.log('items de la cart', itemCart);

        try {
          const res = await comprarGuia(itemCart, empProveedor || provider[0]);
          console.log('respuesta compra onerequest', res);

          await firestore.collection('regCompra').add({
            ...res,
            shippingValue: itemCart.shippingValue,
            provider: itemCart.provider || null,
            proveededor: empProveedor || null,
            rate_provider: itemCart.rate_provider || null,
            user_id: itemCart.user_id || null,
            hostUser_id: itemCart.hostUser_id || null,
            idCotItem: id || null,
            zipcode_from: itemCart.zipcode_from || null,
            zipcode_to: itemCart.zipcode_to || null,
            user_rol: itemCart.user_rol || null,
            created_at: new Date(),
            updated_at: new Date()
          });
          // const { respuesta } = res;
          // const { pedido } = respuesta;
          const { tracking_number, purchase_id, tracking_code, label_code, status } = res;

          // const objRegServicesDagpacket = {
          //   service: 'ENVIO',
          //   tipoContrato: currentUser?.contratoLicenciatario ? currentUser?.contratoLicenciatario : contratosList.tradicional.id,
          //   itemId: id,
          //   created_at: new Date(),
          // }

          const newCot = {
            state: 'PAGADO',
            status: 'CREATED',
            payment_source: 'DAGPACKET',
            payment_method: 'SALDO',
            // payment_id: receipt_no,
            trackingNumber: tracking_number,
            purchase_id,
            tracking_code,
            label_code,
            purchased_guia: status,

            tipoContrato: currentUser?.contratoLicenciatario
              ? currentUser?.contratoLicenciatario
              : contratosList.tradicional.id,

            // label: pedido,

            updated_at: new Date()
          };

          console.log(newCot);
          // =========== restar empaque =============
          if (itemCart.empaquetado === true) {
            const doc = await (await firestore.collection('emp_almacenes').doc(itemCart.empaqAlmacenId).get()).data();

            const { productoItems } = doc;
            let arrEmp = [...productoItems];

            itemCart?.empaquetadoDetalle?.items?.map((item) => {
              const finded = doc.productoItems?.find((it) => it.id === item.id);

              const newObj = { ...finded, existencia: Number(finded.existencia) - Number(item.cantidad) };

              const filtered = arrEmp.filter((it) => it.id !== newObj.id);
              arrEmp = [...filtered, newObj];

              return false;
            });

            await firestore.collection('emp_almacenes').doc(itemCart.empaqAlmacenId).update({ productoItems: arrEmp });
          }

          await firestore.collection('cotizaciones').doc(id.toString()).update(newCot);

          dispatch(updateCartItem({ ...itemCart, ...newCot }));

          dispatch(setItemsSuccess(id));
          dispatch(setCollectedMoney(shippingValue));
          dispatch(setLoopCounter());
        } catch (error) {
          const errorData = {
            error: JSON.stringify(error),
            errorAction: actionSectionIdentifier.comprarGuia,
            section: sectionIdentifier.cartSection,
            statusError: statusAction.pending,
            created_at: new Date(),
            updated_at: new Date(),
            description: 'Error al hacer la compra de guia',
            payment_method: 'SALDO',
            versionApp: localStorage.getItem('versionApp'),
            user_id: user.id,
            detalle: {
              envio_id: id,
              provider: empProveedor || provider[0],
              rate_provider: itemCart.rate_provider
            }
          };
          console.log(errorData);

          await reportError(errorData);

          console.error(error);
          dispatch(setItemsError(id));
          dispatch(setLoopCounter());
          addError(error, id, provider[0], provider[1]);
        }
      }

      return false;
    });
    // setLoadingBtn(false);
    // setCompleteTransaction(true);

    console.log('se hizo el pago');
  };

  const finalizarPago = () => {
    dispatch(resetCart());
    navigate(`/dashboard/paquetes/envios`);
    analytics.logEvent(analyticsEvents.purchase, {
      cancelPaymentCode,
      referenceCode
    });
  };

  useEffect(() => {
    setCompleteTransaction(false);
  }, [setCompleteTransaction]);

  const hacerPago = async (dataForm) => {
    console.log(dataForm);
    setLoadingBtn(true);

    if (verifyUserNip(dataForm.nip)) {
      console.log('es valido');
      makePayment();
    } else {
      setLoadingBtn(false);
      enqueueSnackbar('Ingrese un NIP correcto', { variant: 'error' });
    }
  };

  const pagoSubmit = (dataForm) => {
    if (verifyWhenTryToPay()) {
      if (checkSalddo) {
        hacerPago(dataForm);
      } else {
        enqueueSnackbar('Saldo insuficiente', { variant: 'error' });
      }
    } else {
      enqueueSnackbar(
        'Tienes envios de diferentes usuarios, solo se puede hacer el pago de envios del mismo usuario.',
        { variant: 'error' }
      );
    }
  };

  return (
    <Dialog
      open={open}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <Box component="form" onSubmit={handleSubmit(pagoSubmit)}>
        <Box
          id="alert-dialog-title"
          sx={{
            display: 'flex',
            gap: '30px',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '15px',
            marginBottom: '15px'
          }}
        >
          <Typography fontSize="18px" variant="subtitle1">
            Saldo disponible: {fCurrency(saldoPaqueteria)}
          </Typography>

          <Typography fontSize="18px" variant="subtitle1">
            Total envio: {fCurrency(checkout.total)}
          </Typography>
        </Box>
        {!completeTransaction && (
          <Box marginBottom="15px" padding="10px">
            <TextField
              type="password"
              fullWidth
              {...register('nip', { required: true })}
              variant="outlined"
              label="NIP"
            />
            {errors.nip && (
              <Typography color="error" fontSize="13px">
                Ingrese su NIP
              </Typography>
            )}
          </Box>
        )}
        {!completeTransaction && (
          <Box padding="0 15px 15px" sx={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {checkSalddo && (
              <LoadingButton
                size="large"
                loading={!!loadingBtn}
                variant="contained"
                color="primary"
                type="submit"
                // onClick={makePayment}
              >
                Enviar pago
              </LoadingButton>
            )}
            {!checkSalddo && (
              <Button variant="contained" color="error" disabled>
                Saldo insuficiente
              </Button>
            )}
            <Button onClick={handleClose}>atras</Button>
          </Box>
        )}
      </Box>
      {completeTransaction && (
        <>
          <FinalStep finalizarPago={finalizarPago} />
        </>
      )}
    </Dialog>
  );
}

// MessageError.propTypes = {
//   message: PropTypes.string
// };

function MessageError({ message }) {
  return (
    <Typography sx={{ marginLeft: '15px' }} color="error" variant="subtitle2">
      {message}
    </Typography>
  );
}
