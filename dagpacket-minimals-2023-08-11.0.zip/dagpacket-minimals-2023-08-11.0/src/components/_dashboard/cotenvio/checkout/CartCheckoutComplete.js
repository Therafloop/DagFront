import { Icon } from '@iconify/react';
import { useNavigate } from 'react-router-dom';
// import filePdfFilled from '@iconify/icons-ant-design/file-pdf-filled';
import arrowIosBackFill from '@iconify/icons-eva/arrow-ios-back-fill';
// material
import { Box, Button, Typography, Container, Dialog } from '@mui/material';
// redux
// import { useDispatch } from '../../../../redux/store';
// import { resetCart } from '../../../../redux/slices/product';
// routes
// import { PATH_DASHBOARD } from '../../../../routes/paths';
//

// import { OrderCompleteIllustration } from '../../../../assets';

import PropTypes from 'prop-types';
// import { useTheme } from '@mui/material/styles';

// ----------------------------------------------------------------------

// ----------------------------------------------------------------------

CartCheckoutComplete.propTypes = {
  open: PropTypes.bool,
  setOpen: PropTypes.func
};

export default function CartCheckoutComplete({ open, setOpen }) {
  const navigate = useNavigate();

  const handleResetStep = () => {
    // dispatch(resetCart());
    navigate('/dashboard/paquetes/envios');
    // console.log('asfs');
    setOpen(false);
  };

  return (
    <Dialog open={open}>
      <Box sx={{ p: 4, maxWidth: 480, margin: 'auto' }}>
        {/* <Box sx={{ textAlign: 'center' }}>
          <Typography variant="h4" paragraph>
            Gracias por su envío
          </Typography>

          <Box display="flex" justifyContent="center" marginY="20px">
            <img width="40%" src="/static/illustrations/complete.svg" alt="complte" />
          </Box>

          <Typography align="left">
            Te enviaremos una notificacion mostrando el envio exitoso
            <br /> <br /> Si tienes alguna duda puedes contactarte con nosotros <br /> <br /> Te deseamos la mejor de
            las suertes.
          </Typography>
        </Box>

        <Divider sx={{ my: 3 }} /> */}
        <Container>
          <Box>
            <Typography
              variant="h4"
              color="text.primary"
              align="center"
              gutterBottom
              sx={{
                fontWeight: 700
              }}
            >
              Tu compra se ha registrado exitosamente
            </Typography>
            <Typography
              variant="subtitle1"
              component="p"
              color="text.secondary"
              sx={{ fontWeight: 400, fontSize: '15px' }}
              align="center"
            >
              Te enviaremos una notificacion mostrando el envio exitoso Si tienes alguna duda puedes contactarte con
              nosotros <br /> <br /> Te deseamos la mejor de las suertes.
            </Typography>
            <Box
              display="flex"
              flexDirection={{ xs: 'column', sm: 'row' }}
              alignItems={{ xs: 'stretched', sm: 'flex-start' }}
              justifyContent="center"
              marginTop={4}
            >
              <Button
                onClick={handleResetStep}
                variant="contained"
                color="primary"
                startIcon={<Icon icon={arrowIosBackFill} />}
              >
                Volver a la lista de envíos
              </Button>
              {/* <Box marginTop={{ xs: 2, sm: 0 }} marginLeft={{ sm: 2 }} width={{ xs: '100%', md: 'auto' }}>
                <Button onClick={handleResetStep} color="inherit" startIcon={<Icon icon={arrowIosBackFill} />}>
                  Volver a la lista de envíos
                </Button>
              </Box> */}
            </Box>
          </Box>
        </Container>

        {/* <Stack direction={{ xs: 'column-reverse', sm: 'row' }} justifyContent="space-between" spacing={2}>
          <Button onClick={handleResetStep} color="inherit" startIcon={<Icon icon={arrowIosBackFill} />}>
            Volver a la lista de envíos
          </Button>
          <Button variant="contained" startIcon={<Icon icon={filePdfFilled} />}>
            Descargar PDF
          </Button>
        </Stack> */}
      </Box>
    </Dialog>
  );
}
