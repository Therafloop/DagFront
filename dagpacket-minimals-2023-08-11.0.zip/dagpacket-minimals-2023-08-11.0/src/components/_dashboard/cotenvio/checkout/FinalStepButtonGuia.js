import { Button } from '@mui/material';
import React, { useEffect, useState } from 'react';
import {
  getGuia99Superenvios,
  getGuiaAltospack,
  getGuiaDHL,
  getGuiaJyT,
  getGuiaMienvio,
  getGuiaPaqueteXpress,
  getGuiaPdfSuperenvios,
  getGuiaUPS,
  getGuiaVencedor,
  getPDFRedpackUrl
} from '../../../../_apis_/dagpacket';

function FinalStepButtonGuia({ itemsArr }) {
  const [activeInternational, setActiveInternational] = useState(false);
  //   console.log(itemsArr);
  const verGuia = () => {
    // console.log('ver guia');
    // console.log(itemsArr);
    itemsArr.map((item) => {
      const provider = item.provider.split('/');
      const codigo = item.trackingNumber;
      const { rate_provider, label_code } = item;

      if (provider[0] === 'UPS') {
        const url = getGuiaUPS(codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === 'Redpack') {
        const url = getPDFRedpackUrl(codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === 'mienvio' || provider[0] === 'MiEnvio') {
        const url = getGuiaMienvio(codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === 'SuperEnvios') {
        const url = getGuiaPdfSuperenvios(rate_provider, codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === '99minutos') {
        const url = getGuia99Superenvios(codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === 'PaqueteExpress') {
        const url = getGuiaPaqueteXpress(codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === 'DHL') {
        const url = getGuiaDHL(codigo);
        window.open(url, '_blank');
      }
      if (provider[0] === 'altospack') {
        const url = getGuiaAltospack(label_code);
        window.open(url, '_blank');
      }
      if (provider[0] === 'vencedor') {
        const url = getGuiaVencedor(label_code);
        window.open(url, '_blank');
      }
      if (provider[0] === 'J&T') {
        const url = getGuiaJyT(label_code);
        window.open(url, '_blank');
      }

      return false;
    });
  };

  useEffect(() => {
    if (itemsArr.length) {
      const filterInternacional = itemsArr.filter((item) => item?.tipo_destino === 'internacional');

      if (filterInternacional.length) {
        setActiveInternational(true);
      }
    }
  }, [itemsArr]);
  return (
    <>
      <Button variant="contained" fullWidth onClick={verGuia}>
        Ver guia
      </Button>
      {activeInternational && (
        <Button variant="contained" fullWidth>
          <a
            style={{ color: 'inherit', textDecoration: 'none' }}
            target="_blank"
            rel="noreFerrer"
            href="/docs/factura_comercial.pdf"
          >
            Descargar Factura comercial
          </a>
        </Button>
      )}
    </>
  );
}

export default FinalStepButtonGuia;
