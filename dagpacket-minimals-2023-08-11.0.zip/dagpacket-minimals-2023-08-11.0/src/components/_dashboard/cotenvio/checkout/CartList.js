import React, { useState } from 'react';
import {
  Box,
  Table,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  Typography,
  Grid,
  styled,
  Divider,
  Paper,
  CardActions,
  IconButton,
  Collapse,
  Stack,
  Chip
} from '@mui/material';
// import { MIconButton } from '../../../@material-extend';
import { fCurrency } from '../../../../utils/formatNumber';
// import plusFill from '@iconify/icons-eva/plus-fill';
// import minusFill from '@iconify/icons-eva/minus-fill';
// import trash2Fill from '@iconify/icons-eva/trash-2-fill';
import { Icon } from '@iconify/react';
import { removeItemAction } from '../../../../redux/slices/dagpacket';
import { useDispatch } from 'react-redux';
// import SimpleTable from '../../paquetes/SimpleTable';
import PropTypes from 'prop-types';
import PaqueteriaAvatar from '../../paquetes/general/PaqueteriaAvatar';
import { fCapitalize } from '../../../../utils/formatText';
import CartItemValueMenu from './CartItemValueMenu';
import CartItemEmpaquetadoMenu from './CartItemEmpaquetadoMenu';

CartList.propTypes = {
  cartList: PropTypes.array
};

function CartList({ cartList }) {
  // const dispatch = useDispatch();
  return (
    <>
      <Grid container spacing={1} padding="10px 10px 20px">
        {cartList.map((item) => (
          <Grid key={item.object_id} item xs={12} sm={6} md={6}>
            <ItemCard item={item} />
          </Grid>
        ))}
      </Grid>
    </>
  );
}

export default CartList;

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
  display: 'flex',
  flexDirection: 'column'
  // height: '100%'
}));

const DataSec = styled(Box)(() => ({
  // display: 'flex',
  // justifyContent: 'space-between',
  width: '100%',
  // height: '50px',
  // margin: 'auto',
  // gap: '10px'
  display: 'grid',
  gridTemplateColumns: '50px 1fr',
  // border: 'solid 1px #000',
  // padding: '0 20px',
  textAlign: 'initial',
  marginTop: 1
}));

const ExpandMore = styled((props) => {
  // eslint-disable-next-line no-unused-vars
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
  marginLeft: 'auto',
  transition: theme.transitions.create('transform', {
    duration: theme.transitions.duration.shortest
  })
}));

ItemCard.propTypes = {
  item: PropTypes.object
};

const CuztomBox = styled(Box)(() => ({
  display: 'grid',
  gap: '10px',
  gridTemplateColumns: '70px 1fr'
}));

function ItemCard({ item }) {
  const [expanded, setExpanded] = useState(true);
  const dispatch = useDispatch();
  // const [dimensiones, setDimensiones] = useState({});

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  console.log('item cart', item);
  const {
    object_id,
    city_from,
    city_to,
    street_from,
    street_to,
    weight,
    width,
    height,
    length,
    name_from,
    name_to,
    reference_from,
    reference_to,
    shippingValue,
    rate_provider,
    tipo_envio,
    service,
    colonia_from,
    interior_number_from,
    exterior_number_from,
    phone_from,
    email_from,
    colonia_to,
    exterior_number_to,
    interior_number_to,
    phone_to,
    email_to,
    zipcode_from,
    zipcode_to,
    seguro,
    empaquetadoValue,
    providerValue,
    empaquetado,
    empaquetadoDetalle
  } = item;

  return (
    <Item elevation={10}>
      <Box>
        <Box display="flex" gap={2} justifyContent="space-between" alignItems="center">
          <Box sx={{ display: 'flex', gap: '5px', alignItems: 'center' }}>
            <PaqueteriaAvatar rate_provider={rate_provider} size="small" />
            <Box>
              <Typography variant="subtitle2">{rate_provider}</Typography>
              <Typography textAlign="initial" variant="subtitle2" fontSize="11px">
                {service}
              </Typography>
            </Box>
          </Box>

          <Box>
            <Box sx={{ display: 'flex', gap: '5px' }}>
              <Typography variant="subtitle1" fontSize="18px">
                {fCurrency(shippingValue)}
              </Typography>
              <CartItemValueMenu providerValue={providerValue || shippingValue} empaquetadoValue={empaquetadoValue} />
            </Box>

            {empaquetado && <CartItemEmpaquetadoMenu empaquetadoDetalle={empaquetadoDetalle} />}
          </Box>
        </Box>
        <Typography marginTop="10px" variant="subtitle1" color="grey.700" textAlign="initial" marginBottom={1}>
          {city_from} <span style={{ fontSize: '13px' }}>a</span> {city_to}
        </Typography>
      </Box>
      <Divider sx={{ marginBottom: '10px' }} />
      <Box sx={{ display: 'flex' }}>
        <Box sx={{ flexGrow: 1 }}>
          <DataSec>
            <Typography variant="subtitle2">De:</Typography>
            <Typography fontSize="14px">{name_from}</Typography>
          </DataSec>
          <DataSec>
            <Typography variant="subtitle2">Para:</Typography>
            <Typography fontSize="14px">{name_to}</Typography>
          </DataSec>
        </Box>
        <Stack direction="column" gap="3px">
          <Chip size="small" label={fCapitalize(tipo_envio)} color={tipo_envio === 'sobre' ? 'primary' : 'info'} />
          {/* <Chip size="small" label={seguro} color="info" /> */}
        </Stack>
        {/* <Box>

        </Box> */}
      </Box>

      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <Box sx={{ marginTop: '15px' }}>
          <Box textAlign="initial">
            {empaquetado && (
              <Box sx={{ marginBottom: '15px' }}>
                <Typography variant="subtitle1">Empaque</Typography>
                <Divider />
                {empaquetadoDetalle.items.map((item, i) => (
                  <Box sx={{ display: 'flex', gap: '14px' }} key={i}>
                    <Typography variant="subtitle2" fontSize="13px">
                      {item.name}
                    </Typography>
                    <Typography fontSize="13px">{fCurrency(item.precio)}</Typography>
                  </Box>
                ))}
              </Box>
            )}
            <Typography variant="subtitle1">Origen</Typography>
            <Divider />
            <CuztomBox>
              <Typography variant="subtitle2" fontSize="13px">
                Ciudad:
              </Typography>
              <Typography fontSize="13px">{city_from}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2" fontSize="13px">
                Colonia:
              </Typography>
              <Typography fontSize="13px">{colonia_from}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">C.P.:</Typography>
              <Typography fontSize="13px">{zipcode_from}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Calle:</Typography>
              <Typography fontSize="13px">
                {street_from} {exterior_number_from} {interior_number_from}
              </Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Nombre:</Typography>
              <Typography fontSize="13px">{name_from}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Telefono:</Typography>
              <Typography fontSize="13px">{phone_from}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Email:</Typography>
              <Typography fontSize="13px">{email_from}</Typography>
            </CuztomBox>
          </Box>

          <Box textAlign="initial" marginTop="15px">
            <Typography variant="subtitle1">Destino</Typography>
            <Divider />
            <CuztomBox>
              <Typography variant="subtitle2" fontSize="13px">
                Ciudad:
              </Typography>
              <Typography fontSize="13px">{city_to}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2" fontSize="13px">
                Colonia:
              </Typography>
              <Typography fontSize="13px">{colonia_to}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">C.P.:</Typography>
              <Typography fontSize="13px">{zipcode_to}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Calle:</Typography>
              <Typography fontSize="13px">
                {street_to} {exterior_number_to} {interior_number_to}
              </Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Nombre:</Typography>
              <Typography fontSize="13px">{name_to}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Telefono:</Typography>
              <Typography fontSize="13px">{phone_to}</Typography>
            </CuztomBox>
            <CuztomBox>
              <Typography variant="subtitle2">Email:</Typography>
              <Typography fontSize="13px">{email_to}</Typography>
            </CuztomBox>
          </Box>

          {tipo_envio === 'paquete' && (
            <>
              <Typography marginTop="10px" variant="subtitle1">
                Dimensiones
              </Typography>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontSize: '12px' }}>Ancho</TableCell>
                    <TableCell sx={{ fontSize: '12px' }}>Alto</TableCell>
                    <TableCell sx={{ fontSize: '12px' }}>Largo</TableCell>
                    <TableCell sx={{ fontSize: '12px' }}>Peso</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell sx={{ fontSize: '12px' }}>{width} cm</TableCell>
                    <TableCell sx={{ fontSize: '12px' }}>{height} cm</TableCell>
                    <TableCell sx={{ fontSize: '12px' }}>{length} cm</TableCell>
                    <TableCell sx={{ fontSize: '12px' }}>{weight} kg</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </>
          )}
        </Box>
      </Collapse>

      <CardActions disableSpacing>
        <IconButton sx={{ marginTop: '10px' }} onClick={() => dispatch(removeItemAction(object_id))} color="error">
          <Icon icon="eva:trash-2-fill" />
        </IconButton>
        <ExpandMore expand={expanded} onClick={handleExpandClick} aria-expanded={expanded} aria-label="show more">
          <Icon icon="eva:chevron-down-fill" />
        </ExpandMore>
      </CardActions>
    </Item>
  );
}
