/* eslint-disable no-const-assign */
import React, { useEffect, useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import {
  getConvertCompras,
  hacerEnvioRedpack,
  hacerEnvioSuperEnvios,
  hacerEnvioUPS
} from '../../../../_apis_/dagpacket';
import { analytics, firestore } from '../../../../contexts/FirebaseContext';
import {
  resetCart,
  setItemsError,
  setItemsSuccess,
  setLoopCounter,
  setCollectedMoney,
  resetLoopCounter,
  resetItemsSuccess,
  resetItemsError,
  resetCollectedMoney,
  updateCartItem,
  removeIdWalletToPay
} from '../../../../redux/slices/dagpacket';
import { Box, Button, Dialog, Icon, TextField, Typography } from '@mui/material';
import { fCurrency } from '../../../../utils/formatNumber';
import { LoadingButton } from '@mui/lab';
import useWallet from '../../../../hooks/useWallet';
import useAuth from '../../../../hooks/useAuth';
import { getBalanceTypeUser } from '../../../../utils/formatWallet';
import { getUserNip } from '../../../../utils/adminTools/getUserNip';
import { useSnackbar } from 'notistack';
import FinalStep from './FinalStep';
import useErrorCheckout from '../../../../hooks/errorsHooks/useErrorCheckout';
import useAuthUsers from '../../../../hooks/useAuthUsers';
import useHostWallet from '../../../../hooks/useHostWallet';
import { comprarGuia } from '../../../../_apis_/dagpacket-oneRequest';
import useReportError from '../../../../hooks/errorsHooks/useReportError';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../../constants/ticketsErrors';
import useWalletEvents from '../../../../hooks/useWalletEvents';
import useEnvios from '../../../../hooks/envios/useEnvios';
import { analyticsEvents } from '../../../../constants/analyticsEvents';
import { contratosList } from '../../../../constants/contratos';

export default function SaldoDialogAssigned({ open, setOpen, handleSnackBar, ids }) {
  const [cancelPaymentCode, setCancelPaymentCode] = useState('');
  // const [dataConfirm, setDataConfirm] = useState({});
  const [referenceCode, setReferenceCode] = useState('');
  const [completeTransaction, setCompleteTransaction] = useState(false);
  const [loadingBtn, setLoadingBtn] = useState(false);
  const [itemsLength, setItemsLength] = useState(1);
  // const [counterItems, setCounterItems] = useState(0);
  // // let counterItems = 0;
  // const [collectedMoney, setCollectedMoney] = useState(0);
  // // let collectedMoney = 0;
  // const [itemsError, setItemsError] = useState([]);
  // // const itemsError = [];
  // const [itemsSuccess, setItemsSuccess] = useState([]);
  // // const itemsSuccess = [];
  const [completed, setCompleted] = useState(false);
  const { checkout, paymentCheckout, idWalletToPay } = useSelector((state) => state.dagpacket);
  const { loopCounter, itemsSuccess, itemsError, collectedMoney } = paymentCheckout;
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();
  const { enqueueSnackbar } = useSnackbar();
  const { addError } = useErrorCheckout();
  const { reportError } = useReportError();

  console.log('items length', itemsLength);
  console.log('items counter', loopCounter);
  console.log('items success', itemsSuccess);
  console.log('items error', itemsError);

  const { cobrar } = useWallet();
  const { hostWallet } = useHostWallet();
  const { saldoPaqueteria } = hostWallet;

  console.log('saldo de hoste', hostWallet);
  // const { user } = useAuth();
  const { currentUser, currentHostUser, verifyUserNip } = useAuthUsers();
  const { handleWalletEvent } = useWalletEvents();
  const { getMontoEnvioByArray } = useEnvios();

  const handleClose = () => {
    setOpen(false);
  };

  // con esto obtenemos el id user o host user id desde el primer item de la cart dependiendo que user_rol posea el item
  const userIdEnvio =
    checkout?.cart[0]?.user_rol === 'cajero' ? checkout?.cart[0]?.hostUser_id : checkout?.cart[0]?.user_id;

  console.log(ids);

  const regPayment = useCallback(async () => {
    const hostUserId = idWalletToPay || userIdEnvio || currentUser.hostUser;
    // const amount = collectedMoney;
    const amount = await getMontoEnvioByArray(itemsSuccess, checkout?.cart, hostUserId);
    // const walletId = currentUser.hostUser;
    const categoriaId = 'PAQUETERIA';

    const obj = {
      nameEvent: 'SUBSTRACT',
      ownerUserID: hostUserId,
      category_service_id: categoriaId,
      amount,
      message: 'Pago con saldo - envio',
      reason: 'Cajero - pago saldo',
      payment_method: 'SALDO',
      payment_source: 'DAGPACKET',

      extraData: {
        concepto: 'Envio pagado con saldo',
        service: 'ENVIO',
        itemsPagados: ids,
        userOperator: currentUser.id,
        roleOperator: currentUser.role
      },

      rerport_id: '',
      reporteAction: false,
      // para que la funcion de registrar reporte se ejecute

      // array de funciones que se ejecutan si toda va bien
      successFuncts: []
      // si deseamos que el snackbar se muestre
      // successSnackbar: true
    };

    handleWalletEvent(obj).then(() => {
      setCompleted(true);
      dispatch(removeIdWalletToPay());
    });
  }, [
    checkout?.cart,
    currentUser.hostUser,
    currentUser.id,
    currentUser.role,
    dispatch,
    getMontoEnvioByArray,
    handleWalletEvent,
    idWalletToPay,
    ids,
    itemsSuccess,
    userIdEnvio
  ]);

  useEffect(() => {
    if (completed) {
      setLoadingBtn(false);
      setCompleteTransaction(true);
    }
  }, [completed]);

  useEffect(() => {
    if (ids.length) {
      setItemsLength(ids.length);
    }
  }, [ids]);

  useEffect(() => {
    if (loopCounter === itemsLength) {
      regPayment();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loopCounter, itemsLength]);

  useEffect(() => {
    dispatch(resetLoopCounter());
    dispatch(resetItemsSuccess());
    dispatch(resetItemsError());
    dispatch(resetCollectedMoney());
  }, [dispatch]);

  const checkSalddo = saldoPaqueteria >= checkout.total;

  const makePayment = async () => {
    setLoadingBtn(true);

    ids.map(async (id) => {
      // const { payment_method, receipt_no } = res.item;

      const itemCart = checkout.cart.find((item) => item.object_id === id);
      console.log(itemCart);
      const { shippingValue } = itemCart;

      const provider = itemCart.provider?.split('/');

      const { empProveedor } = itemCart;

      try {
        const res = await comprarGuia(itemCart, empProveedor || provider[0]);
        console.log('respuesta compra onerequest', res);
        // const { respuesta } = res;
        // const { pedido } = respuesta;
        await firestore.collection('regCompra').add({
          ...res,
          shippingValue: itemCart.shippingValue,
          provider: itemCart.provider || null,
          proveededor: empProveedor || null,
          rate_provider: itemCart.rate_provider || null,
          user_id: itemCart.user_id || null,
          hostUser_id: itemCart.hostUser_id || null,
          idCotItem: id || null,
          zipcode_from: itemCart.zipcode_from || null,
          zipcode_to: itemCart.zipcode_to || null,
          user_rol: itemCart.user_rol || null,
          created_at: new Date(),
          updated_at: new Date()
        });

        const { tracking_number, purchase_id, tracking_code, label_code, status } = res;

        const newCot = {
          state: 'PAGADO',
          status: 'CREATED',
          payment_source: 'DAGPACKET',
          payment_method: 'SALDO',
          // payment_id: receipt_no,
          trackingNumber: tracking_number,
          purchase_id,
          tracking_code,
          label_code,
          purchased_guia: status === 'ACTIVE' ? 'GENERATED' : 'PENDING',

          tipoContrato: currentHostUser?.contratoLicenciatario
            ? currentHostUser?.contratoLicenciatario
            : contratosList.tradicional.id,

          // label: pedido,

          updated_at: new Date()
        };

        // console.log(newCot);
        await firestore.collection('cotizaciones').doc(id.toString()).update(newCot);

        dispatch(updateCartItem({ ...itemCart, ...newCot }));

        dispatch(setItemsSuccess(id));
        dispatch(setCollectedMoney(shippingValue));
        dispatch(setLoopCounter());
      } catch (error) {
        console.error(error);
        const errorData = {
          error,
          errorAction: actionSectionIdentifier.comprarGuia,
          section: sectionIdentifier.cartSection,
          statusError: statusAction.pending,
          created_at: new Date(),
          updated_at: new Date(),
          description: 'Error al hacer la compra de guia',
          payment_method: 'SALDO',
          versionApp: localStorage.getItem('versionApp'),
          user_id: currentUser.id,
          detalle: {
            envio_id: id,
            provider: empProveedor || provider[0],
            rate_provider: itemCart.rate_provider
          }
        };
        await reportError(errorData);

        dispatch(setItemsError(id));
        dispatch(setLoopCounter());
        addError(error, id, provider[0]);
      }

      return false;
    });
    // setLoadingBtn(false);
    // setCompleteTransaction(true);

    console.log('se hizo el pago');
  };

  const finalizarPago = () => {
    dispatch(resetCart());
    navigate(`/dashboard/paquetes/envios`);
    analytics.logEvent(analyticsEvents.purchase, {
      cancelPaymentCode,
      referenceCode
    });
  };

  useEffect(() => {
    setCompleteTransaction(false);
  }, [setCompleteTransaction]);

  const hacerPago = async (dataForm) => {
    console.log(dataForm);
    setLoadingBtn(true);

    // let userNip;
    // try {
    //   userNip = await getUserNip(currentUser.id);
    // } catch (error) {
    //   console.log(error);
    //   setLoadingBtn(false);
    //   enqueueSnackbar('Se ha producido un error al obtener el nip', { variant: 'error' });
    // }

    if (verifyUserNip(dataForm.nip)) {
      console.log('es valido');
      makePayment();
    } else {
      setLoadingBtn(false);
      enqueueSnackbar('Ingrese un NIP correcto', { variant: 'error' });
    }
  };

  const pagoSubmit = (dataForm) => {
    if (checkSalddo) {
      hacerPago(dataForm);
    } else {
      enqueueSnackbar('Saldo insuficiente', { variant: 'error' });
    }
  };

  return (
    <Dialog
      open={open}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      cajero
      <Box component="form" onSubmit={handleSubmit(pagoSubmit)}>
        <Box
          id="alert-dialog-title"
          sx={{
            display: 'flex',
            gap: '30px',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '15px',
            marginBottom: '15px'
          }}
        >
          <Typography fontSize="18px" variant="subtitle1">
            Saldo disponible: {fCurrency(saldoPaqueteria)}
          </Typography>
          <Typography fontSize="18px" variant="subtitle1">
            Total envio: {fCurrency(checkout.total)}
          </Typography>
        </Box>
        {!completeTransaction && (
          <Box marginBottom="15px" padding="10px">
            <TextField
              type="password"
              fullWidth
              {...register('nip', { required: true })}
              variant="outlined"
              label="NIP"
            />
            {errors.nip && (
              <Typography color="error" fontSize="13px">
                Ingrese su NIP
              </Typography>
            )}
          </Box>
        )}
        {!completeTransaction && (
          <Box padding="0 15px 15px" sx={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {checkSalddo && (
              <LoadingButton
                size="large"
                loading={!!loadingBtn}
                variant="contained"
                color="primary"
                type="submit"
                // onClick={makePayment}
              >
                Enviar pago
              </LoadingButton>
            )}
            {!checkSalddo && (
              <Button variant="contained" color="error" disabled>
                Saldo insuficiente
              </Button>
            )}
            <Button onClick={handleClose}>atras</Button>
          </Box>
        )}
      </Box>
      {completeTransaction && (
        <>
          <FinalStep finalizarPago={finalizarPago} />
        </>
        // <Box padding="20px" display="flex" flexDirection="column" alignItems="center" justifyContent="center" gap={2}>
        //   {/* <img width="30%" src="/static/illustrations/complete_img.svg" alt="complete" /> */}
        //   <Typography variant="subtitle1" fontSize="25px">
        //     Finalizado
        //   </Typography>

        //   <Typography variant="subtitle1">Completados</Typography>
        //   {itemsSuccess.map((item) => (
        //     <div key={item}>
        //       <Typography variant="subtitle2">{item}</Typography>
        //     </div>
        //   ))}

        //   <Typography variant="subtitle1">No completados</Typography>
        //   {itemsError.map((item) => (
        //     <div key={item}>
        //       <Typography variant="subtitle2">{item}</Typography>
        //     </div>
        //   ))}

        //   <Typography>Gracias por preferir DAGPACKET donde tus envios estan seguros.</Typography>
        //   {/* <Typography fontSize="14px" component="div" sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        //   Si desea cancelar la transacción haga click aquí <Button onClick={submitDelete}>Cancelar token</Button>{' '}
        // </Typography> */}
        //   <Button variant="contained" fullWidth onClick={finalizarPago}>
        //     Finalizar
        //   </Button>
        // </Box>
      )}
    </Dialog>
  );
}

// MessageError.propTypes = {
//   message: PropTypes.string
// };

function MessageError({ message }) {
  return (
    <Typography sx={{ marginLeft: '15px' }} color="error" variant="subtitle2">
      {message}
    </Typography>
  );
}
