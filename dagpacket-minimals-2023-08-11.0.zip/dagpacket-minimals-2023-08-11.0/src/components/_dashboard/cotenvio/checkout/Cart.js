import React from 'react';
import { Button, Card, CardHeader, Grid, Typography } from '@mui/material';
import Scrollbar from '../../../Scrollbar';
import EmptyContent from '../../../EmptyContent';
// import CheckoutSummary from './CheckoutSummary';
// import CheckoutProductList from './CheckoutProductList';
import CartList from './CartList';
import { Link as RouterLink } from 'react-router-dom';
import arrowIosBackFill from '@iconify/icons-eva/arrow-ios-back-fill';
import { useDispatch, useSelector } from 'react-redux';
import { Icon } from '@iconify/react';
import CartSumary from './CartSumary';
import { onNextStep } from '../../../../redux/slices/dagpacket';
import CardListRecServ from '../recargaServicio/CardListRecServ';
import { onNextStepServRec } from '../../../../redux/slices/dagpacketServRec';
import { onNextStepProducts } from '../../../../redux/slices/dagpacketProducts';
import CardListProducts from '../products/CardListProducts';
import useVerifyEnvioSingleUser from '../../../../hooks/envios/useVerifyEnvioSingleUser';
import { useSnackbar } from 'notistack';

function Cart() {
  const { cartServRec, totalServRec, subtotalServRec } = useSelector((state) => state.dagpacketServRec);
  const { cartProducts, totalProducts, subtotalProducts } = useSelector((state) => state.dagpacketProducts);
  const { checkout } = useSelector((state) => state.dagpacket);
  //   const [isEmptyCart, setIsEmptyCart] = useState(0);
  const { cart, subtotal, total, discount, subtotalEmpaquetado } = checkout;
  const isEmptyCart = cart.length === 0 && cartProducts.length === 0 && cartServRec.length === 0;
  const dispatch = useDispatch();
  const { verifyWhenTryToPay } = useVerifyEnvioSingleUser();
  const { enqueueSnackbar } = useSnackbar();

  const objPaq = {
    cart,
    subtotal,
    subtotalEmpaquetado,
    total,
    discount
  };
  const objServ = {
    cart: cartServRec,
    subtotal: subtotalServRec,
    total: totalServRec
  };
  const objProducts = {
    cart: cartProducts,
    subtotal: subtotalProducts,
    total: totalProducts
  };

  const nextStepEnvio = () => {
    if (verifyWhenTryToPay()) {
      dispatch(onNextStep());
    } else {
      enqueueSnackbar('Hay items de usuarios diferentes, solo se puede pagar los items de un mismo usuario', {
        variant: 'error'
      });
    }
  };

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={8}>
        <Card sx={{ mb: 3 }}>
          {/* <CardHeader
            title={
              <Typography variant="h6">
                Card
                <Typography component="span" sx={{ color: 'text.secondary' }}>
                  &nbsp;(2 item)
                </Typography>
              </Typography>
            }
            sx={{ mb: 3 }}
          /> */}

          {!isEmptyCart ? (
            <Scrollbar>
              <CartList cartList={cart.filter((item) => item.typeItem !== 'RECARGA-SERVICIO')} />

              <CardListProducts cartList={cartProducts} />
              <CardListRecServ cartList={cartServRec} />
            </Scrollbar>
          ) : (
            <EmptyContent
              title="El carrito de compras esta vacio"
              description="Parece que no hiciste ninguna cotizacion"
              img="/static/illustrations/illustration_empty_cart.svg"
            />
          )}
        </Card>

        <Button
          color="inherit"
          component={RouterLink}
          to="/dashboard/cotizaciones/new"
          startIcon={<Icon icon={arrowIosBackFill} />}
          sx={{ textTransform: 'initial' }}
        >
          Agregar otro paquete
        </Button>
      </Grid>

      <Grid item xs={12} md={4}>
        <CartSumary
          paquetes={objPaq}
          servRec={objServ}
          products={objProducts}
          // total={total}
          //   enableDiscount
          //   discount={discount}
          // subtotal={subtotal}
          //   onApplyDiscount={handleApplyDiscount}
        />
        <Grid container spacing={1}>
          {cart.length > 0 && (
            <Grid item xs={12}>
              <Button
                disabled={cart.length === 0}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                onClick={nextStepEnvio}
              >
                Pagar paqueteria
              </Button>
            </Grid>
          )}

          {cartServRec.length > 0 && (
            <Grid item xs={12}>
              <Button
                disabled={cartServRec.length === 0}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                onClick={() => dispatch(onNextStepServRec())}
              >
                Pago servicios
              </Button>
            </Grid>
          )}

          {cartProducts.length > 0 && (
            <Grid item xs={12}>
              <Button
                disabled={cartProducts.length === 0}
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                onClick={() => dispatch(onNextStepProducts())}
              >
                Pagar empaque
              </Button>
            </Grid>
          )}
        </Grid>
      </Grid>
    </Grid>
  );
}

export default Cart;
