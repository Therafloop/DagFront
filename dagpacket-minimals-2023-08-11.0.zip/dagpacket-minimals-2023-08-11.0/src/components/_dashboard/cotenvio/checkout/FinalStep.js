import React, { useEffect, useState } from 'react';
import { Box, Button, Card, Chip, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import PaqueteriaAvatar from '../../paquetes/general/PaqueteriaAvatar';
import { fCurrency } from '../../../../utils/formatNumber';
import { useNavigate } from 'react-router';
import { resetCart } from '../../../../redux/slices/dagpacket';
import DialogError from '../DialogError';
import CardReportErrorCartPurchase from '../../errors/cards/CardReportErrorCartPurchase';
import FinalStepButtonGuia from './FinalStepButtonGuia';
import { Icon } from '@iconify/react';

function FinalStep({ finalizarPago }) {
  const [successItems, setSuccessItems] = useState([]);
  const [errorItems, setErrorItems] = useState([]);
  const { checkout, paymentCheckout } = useSelector((state) => state.dagpacket);
  const { itemsSuccess, itemsError } = paymentCheckout;

  useEffect(() => {
    if (itemsSuccess.length) {
      const newArr = [];
      itemsSuccess.map((item) => {
        const findedItem = checkout.cart.find((it) => it.object_id === item);
        newArr.push(findedItem);
        return false;
      });
      setSuccessItems(newArr);
    }
  }, [checkout, itemsSuccess]);

  useEffect(() => {
    if (itemsError.length) {
      const newArr = [];
      itemsError.map((item) => {
        const findedItem = checkout.cart.find((it) => it.object_id === item);
        newArr.push(findedItem);
        return false;
      });
      setErrorItems(newArr);
    }
  }, [checkout, itemsError]);
  return (
    <Box padding="20px" display="flex" flexDirection="column" alignItems="center" justifyContent="center" gap={2}>
      {/* <img width="30%" src="/static/illustrations/complete_img.svg" alt="complete" /> */}
      <Typography variant="subtitle1" fontSize="20px">
        Resumen de compra
      </Typography>

      {successItems.length > 0 && (
        <>
          {/* <Typography variant="subtitle1">Completados</Typography> */}
          {successItems.map((item) => (
            <ResumeItem key={item.object_id} dataItem={item} />
          ))}
        </>
      )}

      {errorItems.length > 0 && (
        <>
          {/* <Typography variant="subtitle1">No completados</Typography> */}
          {checkout.cart.map((item) => (
            <ResumeItem key={item.object_id} dataItem={item} success={false} />
          ))}
        </>
      )}

      {errorItems.length > 0 && <CardReportErrorCartPurchase />}

      <Typography>Gracias por preferir DAGPACKET donde tus envios estan seguros.</Typography>
      {/* <Typography fontSize="14px" component="div" sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            Si desea cancelar la transacción haga click aquí <Button onClick={submitDelete}>Cancelar token</Button>{' '}
          </Typography> */}
      <FinalStepButtonGuia itemsArr={successItems} />

      <Box textAlign="initial" width="100%">
        <Button
          sx={{ textTransform: 'initial' }}
          color="inherit"
          onClick={finalizarPago}
          startIcon={<Icon icon="eva:arrow-back-fill" />}
        >
          Volver al inicio
        </Button>
      </Box>
    </Box>
  );
}

export default FinalStep;

function ResumeItem({ dataItem, success = true }) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    rate_provider,
    shippingValue,
    provider,
    trackingNumber,
    purchase_id,
    tracking_code,
    label_code,
    payment_id,
    object_id,
    oneRequest
  } = dataItem;

  const redirectDetail = () => {
    // to={`${id}?payment_id=${payment_id}&paqueteria=${rate_provider}&provider=${provider}&codigo=${trackingNumber}`}
    navigate(
      `/dashboard/paquetes/envios/${object_id}?payment_id=${payment_id}&oneRequest=${oneRequest}&paqueteria=${rate_provider}&provider=${provider}&codigo=${trackingNumber}&tracking_code=${tracking_code}`
    );
    dispatch(resetCart());
  };

  return (
    <Card
      sx={{
        marginBottom: '10px',
        padding: '5px',
        display: 'flex',
        gap: '15px',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '100%'
      }}
    >
      <Box sx={{ width: '100%', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <PaqueteriaAvatar rate_provider={rate_provider} size="tiny" />
        <Typography fontSize="14px">{fCurrency(shippingValue)}</Typography>
        {/* <Typography fontSize="14px">{fDateTime(new Date())}</Typography> */}
      </Box>
      <Box sx={{ display: 'flex', gap: '15px', justifyContent: 'space-between', alignItems: 'center', width: '200px' }}>
        {success ? (
          <>
            <Chip size="small" label="success" color="success" sx={{ color: '#fff' }} />
            <Button variant="contained" size="small" onClick={redirectDetail}>
              Detalle
            </Button>
          </>
        ) : (
          <>
            <Chip size="small" label="fail" color="error" />
            {/* <DialogReportError itemId={object_id} /> */}
            <DialogError itemId={object_id} />
          </>
        )}
      </Box>
    </Card>
  );
}
