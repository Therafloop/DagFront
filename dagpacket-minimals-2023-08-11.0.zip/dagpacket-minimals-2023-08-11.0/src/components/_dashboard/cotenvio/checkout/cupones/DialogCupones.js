import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import useUserRole from '../../../../../hooks/useUserRole';
import TablaItemsApplyCupones from './TablaItemsApplyCupones';

export default function DialogCupones() {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <Button fullWidth variant="outlined" size="small" onClick={() => setOpenDialog(true)}>
        Usar cupones
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </>
  );
}

function DialogBody({ open, onClose }) {
  const { actualRol, admitByUserType } = useUserRole();

  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="md"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <TablaItemsApplyCupones />
        {/* <TablaDescuentos2 /> */}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
