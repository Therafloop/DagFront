import { LoadingButton } from '@mui/lab';
import { Box, Button, TextField, Typography } from '@mui/material';
import React from 'react';
import { useForm } from 'react-hook-form';
import useCupones from '../../../../../hooks/cuponesDescuentos/useCupones';
import { useSnackbar } from 'notistack';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../../../constants/ticketsErrors';
import useAuthUsers from '../../../../../hooks/useAuthUsers';
import useReportError from '../../../../../hooks/errorsHooks/useReportError';

function AplicarCupon({ dataItem }) {
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    formState: { errors, isSubmitting }
  } = useForm();

  const { reportError } = useReportError();

  const { usarCupon } = useCupones();
  const { enqueueSnackbar } = useSnackbar();
  const { currentUser } = useAuthUsers();

  const onSubmit = async (dataForm) => {
    console.log(dataForm);
    try {
      await usarCupon(dataForm.cuponCode, dataItem);
      enqueueSnackbar('Cupon aplicado', { variant: 'success' });
    } catch (error) {
      console.log({ errorCupon: error });
      enqueueSnackbar('El cupon no se pudo aplicar', { variant: 'error' });
      const errorData = {
        error,
        errorAction: actionSectionIdentifier.aplicarCupon,
        section: sectionIdentifier.tablaCuponesSection,
        statusError: statusAction.pending,
        created_at: new Date(),
        updated_at: new Date(),
        description: 'Error al aplicar cupón',
        versionApp: localStorage.getItem('versionApp'),
        user_id: currentUser.id
      };
      reportError(errorData);
    }
  };
  return (
    <>
      {!dataItem.cuponAplicado && (
        <Box sx={{ display: 'flex' }} component="form" onSubmit={handleSubmit(onSubmit)}>
          <TextField
            {...register('cuponCode', { required: true })}
            error={!!errors.cuponCode}
            label="Ingrese cupon"
            size="small"
          />
          <LoadingButton type="submit" loading={isSubmitting} size="small" variant="contained">
            Aplicar
          </LoadingButton>
        </Box>
      )}

      {dataItem.cuponAplicado && <Typography variant="subtitle2">Cupon aplicado</Typography>}
    </>
  );
}

export default AplicarCupon;
