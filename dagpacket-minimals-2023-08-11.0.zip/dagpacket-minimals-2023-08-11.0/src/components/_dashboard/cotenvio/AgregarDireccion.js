// import { useState } from 'react';
import {
  Box,
  Button,
  DialogContent,
  Dialog,
  // CardContent,
  // DialogActions,
  // DialogContentText,
  // DialogTitle,
  Grid,
  TextField,
  Typography
} from '@mui/material';
import { useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
// import { useLocation } from 'react-router';
import { addDirectionDesti, setIdSelectedRemit, setIdSelectedDesti } from '../../../redux/slices/dagpacket';
import { useDispatch } from 'react-redux';
import PropTypes from 'prop-types';
// import { Icon } from '@iconify/react';
import { firestore } from '../../../contexts/FirebaseContext';
import DireccionForm from './DireccionForm';

// function a11yProps(index) {
//   return {
//     id: `simple-tab-${index}`,
//     'aria-controls': `simple-tabpanel-${index}`
//   };
// }

// const CuztomTab = styled(Tab)(({ theme }) => ({
//   background: theme.palette.primary.main,
//   padding: '0 20px'
// }));

AgregarDireccion.propTypes = {
  open: PropTypes.bool,
  handleClose: PropTypes.func,
  user: PropTypes.object
};

export default function AgregarDireccion({ open, handleClose, user, originDirection, cpNotEdit }) {
  // const [value, setValue] = useState(0);

  // const handleChange = (event, newValue) => {
  //   setValue(newValue);
  // };
  // console.log(user);
  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        maxWidth="md"
      >
        <DialogContent>
          <Box sx={{ width: '100%' }}>
            {/* <Box sx={{ borderBottom: 1, borderColor: 'divider' }}></Box> */}
            {originDirection}
            <DireccionForm
              handleClose={handleClose}
              user={user}
              originDirection={originDirection}
              cpNotEdit={cpNotEdit}
            />
            {/* <DirectionForm handleClose={handleClose} user={user} /> */}
          </Box>
        </DialogContent>
      </Dialog>
    </div>
  );
}

DirectionForm.propTypes = {
  handleClose: PropTypes.func,
  user: PropTypes.object
};

function DirectionForm({ handleClose, user }) {
  const dispatch = useDispatch();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();

  const onSubmitRemitente = (data) => {
    data.user = user.id;
    data.zipcode = queryParams.get('zipcode_from').toString();
    data.name = data.name.replace(/[^a-zA-Z0-9' ']/g, '');
    data.street = data.street.replace(/[^a-zA-Z0-9' ']/g, '');
    data.street2 = data.street2.replace(/[^a-zA-Z0-9' ']/g, '');
    // handleClose();
    console.log(data);
    firestore
      .collection('direcciones')
      .add(data)
      .then((res) => {
        dispatch(setIdSelectedRemit(res.id));
        handleClose();
      });
  };

  const onSubmitDestinatario = (data) => {
    data.user = user.id;
    data.zipcode = queryParams.get('zipcode_to').toString();
    data.name = data.name.replace(/[^a-zA-Z0-9' ']/g, '');
    data.street = data.street.replace(/[^a-zA-Z0-9' ']/g, '');
    data.street2 = data.street2.replace(/[^a-zA-Z0-9' ']/g, '');
    // handleClose();
    // console.log(data);
    firestore
      .collection('direcciones')
      .add(data)
      .then((res) => {
        dispatch(setIdSelectedDesti(res.id));
        handleClose();
      });
  };
  return (
    <Box component="form">
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField label="Nombre" name="name" fullWidth {...register('name', { required: true })} />
          {errors.name?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
        <Grid item xs={12}>
          <TextField label="Direccion" name="street" fullWidth {...register('street', { required: true })} />
          {errors.street?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
        <Grid item xs={12}>
          <TextField label="Colonia" name="street2" fullWidth {...register('street2', { required: true })} />
          {errors.street2?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
        <Grid item xs={12}>
          <TextField label="Referencia" name="reference" fullWidth {...register('reference', { required: true })} />
          {errors.reference?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
      </Grid>
      <Box sx={{ display: 'flex', gap: '10px' }}>
        <Button onClick={handleSubmit(onSubmitRemitente)} variant="contained" fullWidth sx={{ marginTop: '20px' }}>
          Guardar remitente
        </Button>
        <Button
          onClick={handleSubmit(onSubmitDestinatario)}
          color="secondary"
          variant="contained"
          fullWidth
          sx={{ marginTop: '20px' }}
        >
          Guardar destinatario
        </Button>
      </Box>
    </Box>
  );
}

DestinatarioForm.propTypes = {
  handleClose: PropTypes.func
};

function DestinatarioForm({ handleClose }) {
  const dispatch = useDispatch();
  // const { search } = useLocation();
  // const queryParams = new URLSearchParams(search);
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();
  const onSubmit = (data) => {
    // data.zipcode_to = queryParams.get('zipcode_to');
    // console.log(data);
    dispatch(addDirectionDesti(data));
    handleClose();
  };
  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            label="Nombre del Destinatario"
            name="name_to"
            fullWidth
            {...register('name_to', { required: true })}
          />
          {errors.name_to?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Direccion Del Destinatario"
            name="street_to"
            fullWidth
            {...register('street_to', { required: true })}
          />
          {errors.street_to?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Colonia Destinatario"
            name="street2_to"
            fullWidth
            {...register('street2_to', { required: true })}
          />
          {errors.street2_to?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Referencia"
            name="reference_to"
            fullWidth
            {...register('reference_to', { required: true })}
          />
          {errors.reference_to?.type === 'required' && <MessageError message="Ingrese los datos" />}
        </Grid>
      </Grid>
      <Button type="submit" variant="contained" fullWidth sx={{ marginTop: '20px' }}>
        Guardar direccion
      </Button>
    </Box>
  );
}

TabPanel.propTypes = {
  children: PropTypes.object,
  value: PropTypes.number,
  index: PropTypes.number
};

function TabPanel({ children, value, index, ...other }) {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ marginTop: '15px' }}>{children}</Box>}
    </div>
  );
}

MessageError.propTypes = {
  message: PropTypes.string
};

function MessageError({ message }) {
  return (
    <Typography sx={{ marginLeft: '15px' }} color="error" variant="subtitle2">
      {message}
    </Typography>
  );
}
