import React, { useEffect, useState } from 'react';
import { Alert, Button, Dialog, DialogActions, DialogContent, DialogTitle, Typography } from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useSelector } from 'react-redux';

export default function DialogError({ itemId }) {
  const [openDialog, setOpenDialog] = useState(false);
  const [dataError, setDataError] = useState({});
  const { paymentCheckout } = useSelector((state) => state.dagpacket);
  const { listErrors } = paymentCheckout;

  useEffect(() => {
    const findedErrorObj = listErrors.find((err) => err.id === itemId);
    console.log('el error', findedErrorObj);
    if (findedErrorObj) {
      setDataError(findedErrorObj);
    }
  }, [itemId, listErrors]);

  return (
    <Box>
      <Button size="small" variant="contained" color="error" onClick={() => setOpenDialog(true)}>
        Detalle
      </Button>
      <DetailDialogError open={openDialog} onClose={setOpenDialog} dataError={dataError} />
    </Box>
  );
}

function DetailDialogError({ open, onClose, dataError }) {
  const { detail } = dataError;
  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        {detail?.response && (
          <Alert icon={false} severity="error">
            {JSON.stringify(detail?.response, null, 2)}
          </Alert>
        )}
        <hr />
        <Alert icon={false} severity="error">
          <pre>{JSON.stringify(detail, null, 2)}</pre>
        </Alert>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<KeyboardBackspaceIcon />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
