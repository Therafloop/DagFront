import { Grid } from '@mui/material';
import React from 'react';
import ItemCardRecServ from './ItemCardRecServ';

function CardListRecServ({ cartList }) {
  //   console.log(cartList);
  return (
    <>
      <Grid container spacing={1} padding="10px 10px 20px">
        {cartList.map((item) => (
          <Grid key={item.object_id} item xs={12} sm={6} md={6}>
            <ItemCardRecServ item={item} />
          </Grid>
        ))}
      </Grid>
    </>
  );
}

export default CardListRecServ;
