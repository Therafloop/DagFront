/* eslint-disable no-await-in-loop */
import { Icon } from '@iconify/react';
import { LoadingButton } from '@mui/lab';
import { Box, Button, Dialog, TextField, Typography } from '@mui/material';
import { useSnackbar } from 'notistack';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import {
  resetCartServRec,
  resetItemsErrorServRec,
  resetItemsSuccessServRec,
  setItemsErrorServRec,
  setItemsSuccessServRec
} from '../../../../../redux/slices/dagpacketServRec';
import { firestore } from '../../../../../contexts/FirebaseContext';
import useErrorCheckout from '../../../../../hooks/errorsHooks/useErrorCheckout';
import useAuth from '../../../../../hooks/useAuth';
import { fCurrency } from '../../../../../utils/formatNumber';
import { clipDeleteTransaction, clipPaymentConfirm, clipTransaction } from '../../../../../_apis_/dagpacket';
import { comprarRecargasServicios } from '../../../../../_apis_/dagpacket-recargasServicios';
import FinalStep from './finalStep/FinalStep';
import useReportError from '../../../../../hooks/errorsHooks/useReportError';
import useAuthUsers from '../../../../../hooks/useAuthUsers';
import { actionSectionIdentifier, sectionIdentifier } from '../../../../../constants/ticketsErrors';

export default function ClipDialog({ open, setOpen, handleSnackBar, ids }) {
  const [cancelPaymentCode, setCancelPaymentCode] = useState('');
  // const [dataConfirm, setDataConfirm] = useState({});
  const [referenceCode, setReferenceCode] = useState('');
  const [completeTransaction, setCompleteTransaction] = useState(false);
  const [loadingBtn, setLoadingBtn] = useState(false);
  const [itemsLength, setItemsLength] = useState(1);
  const { reportError } = useReportError();
  const { currentUser } = useAuthUsers();

  const [counterError, setCounterError] = useState(0);
  const [timerFunc, setTimerFunc] = useState();
  const countErrorLimit = 5;

  const { cartServRec, totalServRec } = useSelector((state) => state.dagpacketServRec);
  const [loopCounter, setLoopCounter] = useState(0);
  // const [serviceCollectedMoney, setServiceCollectedMoney] = useState(0);
  // const [recargaCollectedMoney, setRecargaceCollectedMoney] = useState(0);

  const [completed, setCompleted] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { addError } = useErrorCheckout();
  const { enqueueSnackbar } = useSnackbar();
  const { user } = useAuth();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();

  const handleClose = () => {
    setOpen(false);
  };

  console.log(ids);

  useEffect(() => {
    if (completed) {
      setLoadingBtn(false);
      setCompleteTransaction(true);
    }
  }, [completed]);

  useEffect(() => {
    if (ids.length) {
      setItemsLength(ids.length);
    }
  }, [ids]);

  useEffect(() => {
    if (loopCounter === itemsLength) {
      setCompleted(true);
    }
  }, [loopCounter, itemsLength]);

  useEffect(() => {
    setCompleteTransaction(false);
    setLoadingBtn(false);
    setCompleted(false);
    setLoopCounter(0);
    // setServiceCollectedMoney(0);
    // setRecargaceCollectedMoney(0);
    dispatch(resetItemsSuccessServRec());
    dispatch(resetItemsErrorServRec());
  }, [dispatch]);

  useEffect(() => {
    if (counterError === countErrorLimit) {
      console.log('se debe cancelar');
      clearInterval(timerFunc);
      setLoadingBtn(false);
      enqueueSnackbar('El codigo de referencia no se encontró, vuelve a intentarlo', { variant: 'error' });
    }
  }, [counterError, timerFunc, enqueueSnackbar]);

  const getConfirm = (reference) => {
    // clipPaymentConfirm('AqjgQIT')
    //   .then((res) => console.log('respuesta', res))
    //   .catch((error) => console.log(error.response));

    const confirm = setInterval(() => {
      // referenceCode
      clipPaymentConfirm(reference)
        .then((res) => {
          console.log('confirmadicimo---', res);

          // setCompleteTransaction(true);
          clearInterval(confirm);
          return res;
        })
        .then(async (res) => {
          console.log(ids);
          // eslint-disable-next-line no-restricted-syntax
          for (const id of ids) {
            const itemCart = cartServRec.find((item) => item.object_id === id);
            //   console.log(itemCart);
            const { type, productId, accountId, enteredAmount } = itemCart;

            const obj = {
              productId,
              accountId,
              amount: enteredAmount,
              type
            };

            try {
              const res = await comprarRecargasServicios(obj);

              const newObj = {
                ...res,
                ...itemCart,
                state: 'PAGADO',
                status: 'PAGADO',
                payment_source: 'DAGPACKET',
                payment_method: 'SALDO',
                updated_at: new Date(),
                payment_date: new Date()
              };

              await firestore.collection('servicioRecarga').doc(newObj.id.toString()).set(newObj);

              // if (newObj.type === 'recarga') {
              //   setRecargaceCollectedMoney((value) => value + Number(enteredAmount));
              // }
              // if (newObj.type === 'servicio') {
              //   setServiceCollectedMoney((value) => value + Number(enteredAmount));
              // }

              setLoopCounter((value) => value + 1);
              dispatch(setItemsSuccessServRec(itemCart.object_id));
              console.log('la resp', res, newObj);
            } catch (error) {
              const errorData = {
                error: JSON.stringify(error),
                errorAction: actionSectionIdentifier.comprarGuiaClipDialog,
                section: sectionIdentifier.clipDialog,
                created_at: new Date(),
                updated_at: new Date(),
                description: 'Error en compra recargas y servicios CLIP',
                versionApp: localStorage.getItem('versionApp'),
                user_id: currentUser.id
              };
              reportError(errorData);
              console.log(error.response);
              setLoopCounter((value) => value + 1);
              dispatch(setItemsErrorServRec(itemCart.object_id));
            }
          }
          // ids.map(async (id) => {
          //   const { payment_method, receipt_no } = res.item;

          //   const itemCart = checkout.cart.find((item) => item.object_id === id);
          //   console.log(itemCart);
          //   const { shippingValue } = itemCart;

          //   const provider = itemCart.provider?.split('/');
          //   const { empProveedor } = itemCart;

          //   return false;
          // });
        })
        .catch((error) => {
          setCounterError((count) => count + 1);
          console.log(error.response);
        });
      // console.log('confirmando');
    }, 3000);
    setTimerFunc(confirm);
    return () => clearInterval(confirm);
    // console.log('cond');
  };

  const onSubmit = (data) => {
    // data.zipcode_to = queryParams.get('zipcode_to');
    setLoadingBtn(true);
    setLoopCounter(0);
    setReferenceCode(data.reference);
    data.amount = totalServRec.toString();
    // data.reference = new Date().getTime().toString();
    console.log(data);

    clipTransaction(data)
      .then((res) => {
        // setLoadingBtn(false);
        setCancelPaymentCode(res.payment_request_code);

        console.log(res);
        getConfirm(data.reference);
      })
      .catch((error) => {
        setLoadingBtn(false);
        console.log(error.response);
      });
  };

  const submitDelete = () => {
    // console.log('asfsd');
    clipDeleteTransaction(cancelPaymentCode).then(() => {
      handleSnackBar(true);
      handleClose();
    });
  };

  const finalizarPago = () => {
    dispatch(resetCartServRec());
    navigate(`/dashboard/servicios/serviciosRecargas`);
  };

  useEffect(() => {
    setCompleteTransaction(false);
  }, [setCompleteTransaction]);

  return (
    <Dialog
      open={open}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      fullWidth
    >
      <Box
        id="alert-dialog-title"
        sx={{ display: 'flex', gap: '10px', alignItems: 'center', justifyContent: 'space-between', padding: '15px' }}
      >
        <img width="40%" src="/static/illustrations/Clip_logo.png" alt="clip" />

        <Typography fontSize="30px" variant="subtitle1">
          Total: {fCurrency(totalServRec)}
        </Typography>
        {/* ----------------este es el boton de pruebas------------ */}
        {/* <Button onClick={() => getConfirm('AqjgQIT')}>confirmar</Button> */}
      </Box>
      {!completeTransaction && (
        <Box padding="0 15px 15px" component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box marginTop={2}>
            <TextField
              label="E-mail"
              type="email"
              name="assigned_user"
              fullWidth
              {...register('assigned_user', { required: true })}
            />
            {errors.assigned_user?.type === 'required' && <MessageError message="Ingrese los datos" />}
          </Box>
          <Box marginTop={2}>
            <TextField label="Reference" name="reference" fullWidth {...register('reference', { required: true })} />
            {errors.reference?.type === 'required' && <MessageError message="Ingrese los datos" />}
          </Box>
          <Box marginTop={2}>
            <TextField label="Mensaje" name="message" fullWidth {...register('message')} />
          </Box>
          <Box sx={{ position: 'relative' }} marginTop={3} display="flex" justifyContent="center" gap={3}>
            <Button size="small" sx={{ position: 'absolute', left: '0px', top: '25%' }} onClick={handleClose}>
              <Icon fontSize="20px" icon="eva:arrow-back-fill" /> Atras
            </Button>
            <LoadingButton size="large" loading={!!loadingBtn} type="submit" variant="contained" color="primary">
              Enviar pago
            </LoadingButton>
          </Box>
        </Box>
      )}
      {completeTransaction && (
        <>
          <FinalStep finalizarPago={finalizarPago} />
        </>
        // <Box padding="20px" display="flex" flexDirection="column" alignItems="center" justifyContent="center" gap={2}>
        //   <img width="30%" src="/static/illustrations/complete_img.svg" alt="complete" />
        //   <Typography variant="subtitle1" fontSize="25px">
        //     Transacción exitosa
        //   </Typography>
        //   {/* <Alert icon={false} severity="success" sx={{ fontSize: '30px' }}>
        //     {referenceCode}
        //   </Alert>
        //   <Alert icon={false} severity="error" sx={{ fontSize: '30px' }}>
        //     {cancelPaymentCode}
        //   </Alert> */}
        //   <Typography>Gracias por preferir DAGPACKET donde tus envios estan seguros.</Typography>
        //   {/* <Typography fontSize="14px" component="div" sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
        //     Si desea cancelar la transacción haga click aquí <Button onClick={submitDelete}>Cancelar token</Button>{' '}
        //   </Typography> */}
        //   <Button variant="contained" fullWidth onClick={finalizarPago}>
        //     Finalizar
        //   </Button>
        // </Box>
      )}
    </Dialog>
  );
}

function MessageError({ message }) {
  return (
    <Typography sx={{ marginLeft: '15px' }} color="error" variant="subtitle2">
      {message}
    </Typography>
  );
}
