// import * as Yup from 'yup';
import { Icon } from '@iconify/react';
// import { useFormik, Form, FormikProvider } from 'formik';
import arrowIosBackFill from '@iconify/icons-eva/arrow-ios-back-fill';
// material
import {
  Grid,
  Button,
  Card,
  CardHeader,
  CardContent,
  styled,
  FormControlLabel,
  Radio,
  Box,
  Typography,
  RadioGroup,
  Dialog,
  TextField,
  Snackbar,
  Alert
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useForm } from 'react-hook-form';
// import { LoadingButton } from '@mui/lab';
// redux
import { useDispatch, useSelector } from '../../../../../redux/store';
// import { onGotoStep, onBackStep, onNextStep, applyShipping } from '../../../../redux/slices/product';
// import {
//   onBackStep,
//   resetCart,
//   resetCollectedMoney,
//   resetItemsError,
//   resetItemsSuccess,
//   resetLoopCounter,
//   setCollectedMoney,
//   setItemsError,
//   setItemsSuccess,
//   setLoopCounter,
//   updateCartItem
// } from '../../../../redux/slices/dagpacket';
//
import CheckoutSummary from '../../checkout/CheckoutSummary';
import { fCurrency } from '../../../../../utils/formatNumber';
import PropTypes from 'prop-types';
// import CheckoutDelivery from './CheckoutDelivery';
// import CheckoutBillingInfo from './CheckoutBillingInfo';
// import CheckoutPaymentMethods from './CheckoutPaymentMethods';
// import ButtonMercPago from '../../../pagos/mercadopago/ButtonMercPago';
import { useEffect, useState } from 'react';
import checkmarkCircle2Fill from '@iconify/icons-eva/checkmark-circle-2-fill';
import {
  clipTransaction,
  clipDeleteTransaction,
  // clipConfirm,
  clipPaymentConfirm,
  getConvertCompras,
  hacerEnvioRedpack,
  hacerEnvioUPS,
  hacerEnvioSuperEnvios
  // updateEnvio
} from '../../../../../_apis_/dagpacket';
import { useNavigate } from 'react-router';
import { firestore, analytics } from '../../../../../contexts/FirebaseContext';
// import SaldoDialog from './SaldoDialog';
// import FinalStep from './FinalStep';
// import SaldoDialogAssigned from './SaldoDialogAssigned';
import { useSnackbar } from 'notistack';
// import { comprarGuia } from '../../../../_apis_/dagpacket-oneRequest';
import useErrorCheckout from '../../../../../hooks/errorsHooks/useErrorCheckout';
// import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../../constants/ticketsErrors';
import useAuth from '../../../../../hooks/useAuth';
import { onBackStepServRec } from '../../../../../redux/slices/dagpacketServRec';
import SaldoDialog from './SaldoDialog';
import ClipDialog from './ClipDialog';
import SaldoDialogAssigned from './SaldoDialogAssigned';

// ----------------------------------------------------------------------

const DELIVERY_OPTIONS = [
  {
    value: 0,
    title: 'CLIP',
    description: 'Usa CLIP para hacer tu pago'
  },
  // {
  //   value: 1,
  //   title: 'Mercado Pago',
  //   description: 'Usa Mercado Pago para hacer tu pago'
  // },
  {
    value: 2,
    title: 'Saldo',
    description: 'Usa tu saldo para hacer tu pago'
  }
];

// ----------------------------------------------------------------------
const OptionStyle = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 2.5),
  justifyContent: 'space-between',
  borderRadius: theme.shape.borderRadius,
  transition: theme.transitions.create('all'),
  border: `solid 1px ${theme.palette.grey[500_32]}`
}));

export default function CheckPaymentServRec() {
  const dispatch = useDispatch();
  const { subtotalServRec, totalServRec, discountServRec, cartServRec } = useSelector(
    (state) => state.dagpacketServRec
  );
  //   const { checkout } = useSelector((state) => state.dagpacket);
  const { actualRol } = useSelector((state) => state.dagpacketRoles);
  //   const { total, discount, subtotal, shipping, cart } = checkout;
  const [items, setItems] = useState([]);
  const [arrObjId, setArrObjId] = useState([]);
  const [selectValue, setSelectValue] = useState(0);
  const [openDialog, setOpenDialog] = useState(false);
  const [openSnackBar, setOpenSnackBar] = useState(false);
  const [openSaldoDialog, setOpenSaldoDialog] = useState(false);
  // const [showButton, setShowButton] = useState(false);
  // const [loading, setLoading] = useState(false);
  // console.log(arrObjId);

  useEffect(() => {
    const arr = [];
    const arrId = [];
    // eslint-disable-next-line array-callback-return
    cartServRec.map((item) => {
      const paq = {
        title: `Entrega para ${item.name_to}`,
        unit_price: item.shippingValue,
        quantity: 1
      };
      // console.log(paq);
      arr.push(paq);
      arrId.push(item.object_id);
    });
    // console.log(arr);
    setItems(arr);
    setArrObjId(arrId);
  }, [setItems, cartServRec]);

  const handleBackStep = () => {
    dispatch(onBackStepServRec());
  };

  const handleChangeSelected = (event) => {
    setSelectValue(Number(event.target.value));
  };

  const handleCloseSnackBar = () => {
    setOpenSnackBar(false);
  };

  let showBtn;

  if (selectValue === 0) {
    showBtn = (
      <>
        <Button fullWidth variant="contained" onClick={() => setOpenDialog(true)}>
          Pagar
        </Button>
        <ClipDialog ids={arrObjId} open={openDialog} setOpen={setOpenDialog} handleSnackBar={setOpenSnackBar} />
      </>
    );
  }
  // else if (selectValue === 1) {
  //   showBtn = (
  //     <>
  //       <ButtonMercPago ids={arrObjId.toString()} items={items} />
  //     </>
  //   );
  // }
  else {
    showBtn = (
      <>
        <Button fullWidth variant="contained" onClick={() => setOpenSaldoDialog(true)}>
          Comprar
        </Button>
        {/* <SaldoDialog ids={arrObjId} open={openSaldoDialog} setOpen={setOpenSaldoDialog} /> */}
        {actualRol.id === 'cajero' ? (
          <SaldoDialogAssigned ids={arrObjId} open={openSaldoDialog} setOpen={setOpenSaldoDialog} />
        ) : (
          <SaldoDialog ids={arrObjId} open={openSaldoDialog} setOpen={setOpenSaldoDialog} />
        )}
      </>
    );
  }

  // console.log(items);

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} md={8}>
        <Card>
          <CardHeader title="Metodos de Pago" />
          <CardContent>
            <RadioGroup value={selectValue} onChange={handleChangeSelected}>
              <Grid container spacing={2}>
                {DELIVERY_OPTIONS.map((delivery) => {
                  const { value, title, description } = delivery;
                  return (
                    <Grid key={value} item xs={12} md={6}>
                      <OptionStyle
                        sx={{
                          ...(selectValue === value && {
                            boxShadow: (theme) => theme.customShadows.z8
                          })
                        }}
                      >
                        <FormControlLabel
                          value={value}
                          control={<Radio checkedIcon={<Icon icon={checkmarkCircle2Fill} />} />}
                          label={
                            <Box sx={{ ml: 1 }}>
                              <Typography variant="subtitle2">{title}</Typography>
                              <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                                {description}
                              </Typography>
                            </Box>
                          }
                          sx={{ py: 3, flexGrow: 1, mr: 0 }}
                        />
                      </OptionStyle>
                    </Grid>
                  );
                })}
              </Grid>
            </RadioGroup>
          </CardContent>
        </Card>
        <Button
          sx={{ marginTop: '20px' }}
          type="button"
          size="small"
          color="inherit"
          onClick={handleBackStep}
          startIcon={<Icon icon={arrowIosBackFill} />}
        >
          Atras
        </Button>
      </Grid>

      <Grid item xs={12} md={4}>
        <CheckoutSummary
          title="Sumario de servicios"
          enableEdit
          total={totalServRec}
          subtotal={subtotalServRec}
          discount={discountServRec}
          //   shipping={shipping}
          // onEdit={() => handleGotoStep(0)}
        />
        {showBtn}
      </Grid>
      <Snackbar open={openSnackBar} autoHideDuration={6000} onClose={handleCloseSnackBar}>
        <Alert onClose={handleCloseSnackBar} severity="warning" sx={{ width: '100%' }}>
          La transacción con Clip ha sido cancelada
        </Alert>
      </Snackbar>
    </Grid>
  );
}

// ClipDialog.propTypes = {
//   open: PropTypes.bool,
//   setOpen: PropTypes.func,
//   handleSnackBar: PropTypes.func,
//   ids: PropTypes.array
// };

// function ClipDialog({ open, setOpen, handleSnackBar, ids }) {
//   const [cancelPaymentCode, setCancelPaymentCode] = useState('');
//   // const [dataConfirm, setDataConfirm] = useState({});
//   const [referenceCode, setReferenceCode] = useState('');
//   const [completeTransaction, setCompleteTransaction] = useState(false);
//   const [loadingBtn, setLoadingBtn] = useState(false);
//   const [itemsLength, setItemsLength] = useState(1);

//   const [counterError, setCounterError] = useState(0);
//   const [timerFunc, setTimerFunc] = useState();
//   const countErrorLimit = 5;

//   const { checkout, paymentCheckout } = useSelector((state) => state.dagpacket);
//   const [completed, setCompleted] = useState(false);
//   const { loopCounter, itemsSuccess, itemsError, collectedMoney } = paymentCheckout;
//   const dispatch = useDispatch();
//   const navigate = useNavigate();
//   const { addError } = useErrorCheckout();
//   const { enqueueSnackbar } = useSnackbar();
//   const { user } = useAuth();
//   const {
//     register,
//     handleSubmit,
//     formState: { errors }
//   } = useForm();

//   console.log('items length', itemsLength);
//   console.log('items counter', loopCounter);
//   console.log('items success', itemsSuccess);
//   console.log('items error', itemsError);

//   const handleClose = () => {
//     setOpen(false);
//   };

//   console.log(ids);

//   useEffect(() => {
//     if (completed) {
//       setLoadingBtn(false);
//       setCompleteTransaction(true);
//     }
//   }, [completed]);

//   useEffect(() => {
//     if (ids.length) {
//       setItemsLength(ids.length);
//     }
//   }, [ids]);

//   useEffect(() => {
//     if (loopCounter === itemsLength) {
//       setCompleted(true);
//     }
//   }, [loopCounter, itemsLength]);

//   useEffect(() => {
//     dispatch(resetLoopCounter());
//     dispatch(resetItemsSuccess());
//     dispatch(resetItemsError());
//     dispatch(resetCollectedMoney());
//   }, [dispatch]);

//   useEffect(() => {
//     if (counterError === countErrorLimit) {
//       console.log('se debe cancelar');
//       clearInterval(timerFunc);
//       setLoadingBtn(false);
//       enqueueSnackbar('El codigo de referencia no se encontró, vuelve a intentarlo', { variant: 'error' });
//     }
//   }, [counterError, timerFunc, enqueueSnackbar]);

//   const getConfirm = (reference) => {
//     // clipPaymentConfirm('AqjgQIT')
//     //   .then((res) => console.log('respuesta', res))
//     //   .catch((error) => console.log(error.response));

//     const confirm = setInterval(() => {
//       // referenceCode
//       clipPaymentConfirm(reference)
//         .then((res) => {
//           console.log('confirmadicimo---', res);

//           // setCompleteTransaction(true);
//           clearInterval(confirm);
//           return res;
//         })
//         .then((res) => {
//           console.log(ids);
//           ids.map(async (id) => {
//             const { payment_method, receipt_no } = res.item;

//             const itemCart = checkout.cart.find((item) => item.object_id === id);
//             console.log(itemCart);
//             const { shippingValue } = itemCart;

//             const provider = itemCart.provider?.split('/');
//             const { empProveedor } = itemCart;

//             try {
//               const res = await comprarGuia(itemCart, empProveedor);
//               console.log('respuesta compra onerequest', res);
//               // const { respuesta } = res;
//               // const { pedido } = respuesta;

//               await firestore.collection('regCompra').add({
//                 ...res,
//                 shippingValue: itemCart.shippingValue,
//                 provider: itemCart.provider || null,
//                 proveededor: empProveedor || null,
//                 rate_provider: itemCart.rate_provider || null,
//                 user_id: itemCart.user_id || null,
//                 hostUser_id: itemCart.hostUser_id || null,
//                 idCotItem: id || null,
//                 zipcode_from: itemCart.zipcode_from || null,
//                 zipcode_to: itemCart.zipcode_to || null,
//                 user_rol: itemCart.user_rol || null,
//                 created_at: new Date(),
//                 updated_at: new Date()
//               });

//               const { tracking_number, purchase_id, tracking_code, label_code } = res;

//               const newCot = {
//                 state: 'PAGADO',
//                 status: 'CREATED',
//                 payment_source: 'CLIP',
//                 payment_method,
//                 payment_id: receipt_no,
//                 trackingNumber: tracking_number,
//                 purchase_id,
//                 tracking_code,
//                 label_code,
//                 // label: pedido,

//                 updated_at: new Date()
//               };

//               // console.log(newCot);
//               await firestore.collection('cotizaciones').doc(id.toString()).update(newCot);

//               dispatch(updateCartItem({ ...itemCart, ...newCot }));

//               dispatch(setItemsSuccess(id));
//               dispatch(setCollectedMoney(shippingValue));
//               dispatch(setLoopCounter());
//             } catch (error) {
//               const errorData = {
//                 error: JSON.stringify(error),
//                 errorAction: actionSectionIdentifier.comprarGuia,
//                 section: sectionIdentifier.cartSection,
//                 statusError: statusAction.pending,
//                 created_at: new Date(),
//                 updated_at: new Date(),
//                 description: 'Error al hacer la compra de guia',
//                 payment_method: 'CLIP',
//                 versionApp: localStorage.getItem('versionApp'),
//                 user_id: user.id,
//                 detalle: {
//                   envio_id: id,
//                   provider: empProveedor || provider[0],
//                   rate_provider: itemCart.rate_provider
//                 }
//               };
//               console.log(errorData);

//               await reportError(errorData);
//               console.error(error);
//               dispatch(setItemsError(id));
//               dispatch(setLoopCounter());
//               addError(error, id, provider[0]);
//             }

//             return false;
//           });
//         })
//         .catch((error) => {
//           setCounterError((count) => count + 1);
//           console.log(error.response);
//         });
//       // console.log('confirmando');
//     }, 3000);
//     setTimerFunc(confirm);
//     return () => clearInterval(confirm);
//     // console.log('cond');
//   };

//   const onSubmit = (data) => {
//     // data.zipcode_to = queryParams.get('zipcode_to');
//     setLoadingBtn(true);
//     setReferenceCode(data.reference);
//     data.amount = checkout.total.toString();
//     // data.reference = new Date().getTime().toString();
//     console.log(data);

//     clipTransaction(data)
//       .then((res) => {
//         // setLoadingBtn(false);
//         setCancelPaymentCode(res.payment_request_code);

//         console.log(res);
//         getConfirm(data.reference);
//       })
//       .catch((error) => {
//         setLoadingBtn(false);
//         console.log(error.response);
//       });
//   };

//   const submitDelete = () => {
//     // console.log('asfsd');
//     clipDeleteTransaction(cancelPaymentCode).then(() => {
//       handleSnackBar(true);
//       handleClose();
//     });
//   };

//   const finalizarPago = () => {
//     dispatch(resetCart());
//     navigate(`/dashboard/paquetes/envios`);
//     analytics.logEvent('purchase', {
//       cancelPaymentCode,
//       referenceCode,
//       currency: 'MXN',
//       payment_type: ''
//     });
//   };

//   useEffect(() => {
//     setCompleteTransaction(false);
//   }, [setCompleteTransaction]);

//   return (
//     <Dialog
//       open={open}
//       // onClose={handleClose}
//       aria-labelledby="alert-dialog-title"
//       aria-describedby="alert-dialog-description"
//       fullWidth
//     >
//       <Box
//         id="alert-dialog-title"
//         sx={{ display: 'flex', gap: '10px', alignItems: 'center', justifyContent: 'space-between', padding: '15px' }}
//       >
//         <img width="40%" src="/static/illustrations/Clip_logo.png" alt="clip" />

//         <Typography fontSize="30px" variant="subtitle1">
//           Total: {fCurrency(checkout.total)}
//         </Typography>
//         {/* ----------------este es el boton de pruebas------------ */}
//         {/* <Button onClick={() => getConfirm('AqjgQIT')}>confirmar</Button> */}
//       </Box>
//       {!completeTransaction && (
//         <Box padding="0 15px 15px" component="form" onSubmit={handleSubmit(onSubmit)}>
//           <Box marginTop={2}>
//             <TextField
//               label="E-mail"
//               type="email"
//               name="assigned_user"
//               fullWidth
//               {...register('assigned_user', { required: true })}
//             />
//             {errors.assigned_user?.type === 'required' && <MessageError message="Ingrese los datos" />}
//           </Box>
//           <Box marginTop={2}>
//             <TextField label="Reference" name="reference" fullWidth {...register('reference', { required: true })} />
//             {errors.reference?.type === 'required' && <MessageError message="Ingrese los datos" />}
//           </Box>
//           <Box marginTop={2}>
//             <TextField label="Mensaje" name="message" fullWidth {...register('message')} />
//           </Box>
//           <Box sx={{ position: 'relative' }} marginTop={3} display="flex" justifyContent="center" gap={3}>
//             <Button size="small" sx={{ position: 'absolute', left: '0px', top: '25%' }} onClick={handleClose}>
//               <Icon fontSize="20px" icon="eva:arrow-back-fill" /> Atras
//             </Button>
//             <LoadingButton size="large" loading={!!loadingBtn} type="submit" variant="contained" color="primary">
//               Enviar pago
//             </LoadingButton>
//           </Box>
//         </Box>
//       )}
//       {completeTransaction && (
//         <>
//           <FinalStep finalizarPago={finalizarPago} />
//         </>
//         // <Box padding="20px" display="flex" flexDirection="column" alignItems="center" justifyContent="center" gap={2}>
//         //   <img width="30%" src="/static/illustrations/complete_img.svg" alt="complete" />
//         //   <Typography variant="subtitle1" fontSize="25px">
//         //     Transacción exitosa
//         //   </Typography>
//         //   {/* <Alert icon={false} severity="success" sx={{ fontSize: '30px' }}>
//         //     {referenceCode}
//         //   </Alert>
//         //   <Alert icon={false} severity="error" sx={{ fontSize: '30px' }}>
//         //     {cancelPaymentCode}
//         //   </Alert> */}
//         //   <Typography>Gracias por preferir DAGPACKET donde tus envios estan seguros.</Typography>
//         //   {/* <Typography fontSize="14px" component="div" sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
//         //     Si desea cancelar la transacción haga click aquí <Button onClick={submitDelete}>Cancelar token</Button>{' '}
//         //   </Typography> */}
//         //   <Button variant="contained" fullWidth onClick={finalizarPago}>
//         //     Finalizar
//         //   </Button>
//         // </Box>
//       )}
//     </Dialog>
//   );
// }

// MessageError.propTypes = {
//   message: PropTypes.string
// };

// function MessageError({ message }) {
//   return (
//     <Typography sx={{ marginLeft: '15px' }} color="error" variant="subtitle2">
//       {message}
//     </Typography>
//   );
// }
