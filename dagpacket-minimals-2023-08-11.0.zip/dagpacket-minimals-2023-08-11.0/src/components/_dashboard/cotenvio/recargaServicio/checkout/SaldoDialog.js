/* eslint-disable no-await-in-loop */
/* eslint-disable no-const-assign */
import React, { useEffect, useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import {
  getConvertCompras,
  hacerEnvioRedpack,
  hacerEnvioSuperEnvios,
  hacerEnvioUPS
} from '../../../../../_apis_/dagpacket';
import { analytics, firestore } from '../../../../../contexts/FirebaseContext';
import {
  resetCart,
  setItemsError,
  setItemsSuccess,
  setLoopCounter,
  setCollectedMoney,
  resetLoopCounter,
  resetItemsSuccess,
  resetItemsError,
  resetCollectedMoney,
  updateCartItem
} from '../../../../../redux/slices/dagpacket';
import { Box, Button, Card, Dialog, Icon, TextField, Typography } from '@mui/material';
import { fCurrency } from '../../../../../utils/formatNumber';
import { LoadingButton } from '@mui/lab';
import useWallet from '../../../../../hooks/useWallet';
import useAuth from '../../../../../hooks/useAuth';
import { getBalanceTypeUser } from '../../../../../utils/formatWallet';
import { getUserNip } from '../../../../../utils/adminTools/getUserNip';
import { useSnackbar } from 'notistack';
import useErrorCheckout from '../../../../../hooks/errorsHooks/useErrorCheckout';
import { comprarGuia } from '../../../../../_apis_/dagpacket-oneRequest';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../../../constants/ticketsErrors';
import useReportError from '../../../../../hooks/errorsHooks/useReportError';
import useAuthUsers from '../../../../../hooks/useAuthUsers';
import useWalletEvents from '../../../../../hooks/useWalletEvents';
import { comprarRecargasServicios } from '../../../../../_apis_/dagpacket-recargasServicios';
import FinalStep from './finalStep/FinalStep';
import {
  resetCartServRec,
  resetItemsErrorServRec,
  resetItemsSuccessServRec,
  setItemsErrorServRec,
  setItemsSuccessServRec,
  updateCartServRecItem
} from '../../../../../redux/slices/dagpacketServRec';

export default function SaldoDialog({ open, setOpen, handleSnackBar, ids }) {
  const [cancelPaymentCode, setCancelPaymentCode] = useState('');
  // const [dataConfirm, setDataConfirm] = useState({});
  const [referenceCode, setReferenceCode] = useState('');
  const [completeTransaction, setCompleteTransaction] = useState(false);
  const [loadingBtn, setLoadingBtn] = useState(false);
  const [itemsLength, setItemsLength] = useState(1);
  const [completed, setCompleted] = useState(false);
  const { cartServRec, totalServRec, subtotalServ, subtotalRec } = useSelector((state) => state.dagpacketServRec);
  const [loopCounter, setLoopCounter] = useState(0);
  const [serviceCollectedMoney, setServiceCollectedMoney] = useState(0);
  const [recargaCollectedMoney, setRecargaceCollectedMoney] = useState(0);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();
  const { enqueueSnackbar } = useSnackbar();
  const { addError } = useErrorCheckout();
  const { reportError } = useReportError();
  const { verifyUserNip } = useAuthUsers();

  console.log(serviceCollectedMoney, recargaCollectedMoney);

  const { saldoPaqueteria, saldoServicio, saldoRecarga, cobrar } = useWallet();
  const { user } = useAuth();
  const { handleWalletEvent } = useWalletEvents();

  const handleClose = () => {
    setOpen(false);
  };

  // console.log(ids);

  const regPayment = useCallback(async () => {
    if (serviceCollectedMoney > 0) {
      const amount = serviceCollectedMoney;
      const walletId = user.id;
      const categoriaId = 'SERVICIO';

      const obj = {
        nameEvent: 'SUBSTRACT',
        ownerUserID: user.id,
        category_service_id: categoriaId,
        amount,
        message: 'Pago con saldo',
        reason: 'Pago saldo',
        payment_method: 'SALDO',
        payment_source: 'DAGPACKET',

        rerport_id: '',
        reporteAction: false,
        // para que la funcion de registrar reporte se ejecute

        // array de funciones que se ejecutan si toda va bien
        successFuncts: []
        // si deseamos que el snackbar se muestre
        // successSnackbar: true
      };
      handleWalletEvent(obj);
    }
    if (recargaCollectedMoney > 0) {
      const amount = recargaCollectedMoney;
      const walletId = user.id;
      const categoriaId = 'RECARGA';

      const obj = {
        nameEvent: 'SUBSTRACT',
        ownerUserID: user.id,
        category_service_id: categoriaId,
        amount,
        message: 'Pago con saldo',
        reason: 'Pago saldo',
        payment_method: 'SALDO',
        payment_source: 'DAGPACKET',

        rerport_id: '',
        reporteAction: false,
        // para que la funcion de registrar reporte se ejecute

        // array de funciones que se ejecutan si toda va bien
        successFuncts: []
        // si deseamos que el snackbar se muestre
        // successSnackbar: true
      };
      handleWalletEvent(obj);
    }

    setCompleted(true);
  }, [serviceCollectedMoney, recargaCollectedMoney, user.id, handleWalletEvent]);

  useEffect(() => {
    if (completed) {
      setLoadingBtn(false);
      setCompleteTransaction(true);
    }
  }, [completed]);

  useEffect(() => {
    if (ids.length) {
      setItemsLength(ids.length);
    }
  }, [ids]);

  useEffect(() => {
    if (loopCounter === itemsLength) {
      regPayment();
      console.log('se activa cuando todos los ids se realizaron');
      //   setLoadingBtn(false);
      setLoopCounter(0);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loopCounter, itemsLength]);

  useEffect(() => {
    setCompleteTransaction(false);
    setLoadingBtn(false);
    setCompleted(false);
    setLoopCounter(0);
    setServiceCollectedMoney(0);
    setRecargaceCollectedMoney(0);
    dispatch(resetItemsSuccessServRec());
    dispatch(resetItemsErrorServRec());
  }, [dispatch]);

  const checkSalddo = saldoPaqueteria >= totalServRec;

  const makePayment = async () => {
    // setLoadingBtn(true);
    setLoopCounter(0);

    // eslint-disable-next-line no-restricted-syntax
    for (const id of ids) {
      const itemCart = cartServRec.find((item) => item.object_id === id);
      //   console.log(itemCart);
      const { type, productId, accountId, enteredAmount } = itemCart;

      const obj = {
        productId,
        accountId,
        amount: enteredAmount,
        type
      };

      try {
        const res = await comprarRecargasServicios(obj);

        const newObj = {
          ...res,
          ...itemCart,
          state: 'PAGADO',
          status: 'PAGADO',
          payment_source: 'DAGPACKET',
          payment_method: 'SALDO',
          updated_at: new Date(),
          payment_date: new Date()
        };

        await firestore.collection('servicioRecarga').doc(newObj.id.toString()).set(newObj);
        dispatch(updateCartServRecItem(newObj));

        if (newObj.type === 'recarga') {
          setRecargaceCollectedMoney((value) => value + Number(enteredAmount));
        }
        if (newObj.type === 'servicio') {
          setServiceCollectedMoney((value) => value + Number(enteredAmount));
        }

        setLoopCounter((value) => value + 1);
        dispatch(setItemsSuccessServRec(itemCart.object_id));
        console.log('la resp', res, newObj);
      } catch (error) {
        console.log(error.response);
        setLoopCounter((value) => value + 1);
        dispatch(setItemsErrorServRec(itemCart.object_id));
      }
    }
  };

  const finalizarPago = () => {
    dispatch(resetCartServRec());
    navigate(`/dashboard/servicios/serviciosRecargas`);
  };

  useEffect(() => {
    setCompleteTransaction(false);
  }, [setCompleteTransaction]);

  const hacerPago = async (dataForm) => {
    console.log(dataForm);
    setLoadingBtn(true);

    if (verifyUserNip(dataForm.nip)) {
      console.log('es valido');
      //   console.log('funcion pra el pago');
      makePayment();
    } else {
      setLoadingBtn(false);
      enqueueSnackbar('Ingrese un NIP correcto', { variant: 'error' });
    }
  };

  const pagoSubmit = (dataForm) => {
    if (checkSalddo) {
      hacerPago(dataForm);
    } else {
      enqueueSnackbar('Saldo insuficiente', { variant: 'error' });
    }
  };

  return (
    <Dialog
      open={open}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <Box component="form" onSubmit={handleSubmit(pagoSubmit)}>
        <Box
          id="alert-dialog-title"
          sx={{
            display: 'flex',
            gap: '30px',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '15px',
            marginBottom: '15px'
          }}
        >
          <Box>
            <Typography fontSize="18px" variant="subtitle1">
              Saldo servicios: {fCurrency(saldoServicio)}
            </Typography>
            <Typography fontSize="18px" variant="subtitle1">
              Saldo recarga: {fCurrency(saldoRecarga)}
            </Typography>
          </Box>

          <Box>
            <Typography fontSize="18px" variant="subtitle1">
              Total servicios: {fCurrency(subtotalServ)}
            </Typography>
            <Typography fontSize="18px" variant="subtitle1">
              Total recarga: {fCurrency(subtotalRec)}
            </Typography>
          </Box>

          {/* <Typography fontSize="18px" variant="subtitle1">
            Total envio: {fCurrency(totalServRec)}
          </Typography> */}
        </Box>
        {!completeTransaction && (
          <Box marginBottom="15px" padding="10px">
            <TextField
              type="password"
              fullWidth
              {...register('nip', { required: true })}
              variant="outlined"
              label="NIP"
            />
            {errors.nip && (
              <Typography color="error" fontSize="13px">
                Ingrese su NIP
              </Typography>
            )}
          </Box>
        )}
        {!completeTransaction && (
          <Box padding="0 15px 15px" sx={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            {saldoServicio >= subtotalServ && saldoRecarga >= subtotalRec && (
              <LoadingButton
                size="large"
                loading={!!loadingBtn}
                variant="contained"
                color="primary"
                type="submit"
                // onClick={makePayment}
              >
                Enviar pago
              </LoadingButton>
            )}
            {!(saldoServicio >= subtotalServ && saldoRecarga >= subtotalRec) && (
              <Button variant="contained" color="error" disabled>
                Saldo insuficiente
              </Button>
            )}
            <Button onClick={handleClose}>atras</Button>
          </Box>
        )}
      </Box>
      {completeTransaction && (
        <>
          {/* <FinalStep finalizarPago={finalizarPago} /> */}
          <FinalStep finalizarPago={finalizarPago} />
        </>
      )}
    </Dialog>
  );
}

// MessageError.propTypes = {
//   message: PropTypes.string
// };

function MessageError({ message }) {
  return (
    <Typography sx={{ marginLeft: '15px' }} color="error" variant="subtitle2">
      {message}
    </Typography>
  );
}
