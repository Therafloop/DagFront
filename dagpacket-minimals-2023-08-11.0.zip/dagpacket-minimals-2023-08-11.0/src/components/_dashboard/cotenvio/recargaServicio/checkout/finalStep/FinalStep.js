import React, { useEffect, useState } from 'react';
import { Button, Card, Typography } from '@mui/material';
import { useSelector } from 'react-redux';
import ResumeItem from './ResumeItem';

function FinalStep({ finalizarPago }) {
  const [successItems, setSuccessItems] = useState([]);
  const [errorItems, setErrorItems] = useState([]);
  const { itemsError, itemsSuccess, cartServRec } = useSelector((state) => state.dagpacketServRec);

  useEffect(() => {
    if (itemsSuccess.length) {
      const newArr = [];
      itemsSuccess.map((item) => {
        const findedItem = cartServRec.find((it) => it.object_id === item);
        newArr.push(findedItem);
        return false;
      });
      setSuccessItems(newArr);
    }
  }, [cartServRec, itemsSuccess]);

  useEffect(() => {
    if (itemsError.length) {
      const newArr = [];
      itemsError.map((item) => {
        const findedItem = cartServRec.find((it) => it.object_id === item);
        newArr.push(findedItem);
        return false;
      });
      setErrorItems(newArr);
    }
  }, [cartServRec, itemsError]);
  return (
    <Card sx={{ padding: '15px' }}>
      <Typography>Operacion completada</Typography>
      {successItems.length > 0 && (
        <>
          {/* <Typography variant="subtitle1">Completados</Typography> */}
          {successItems.map((item) => (
            <ResumeItem key={item.object_id} dataItem={item} />
          ))}
        </>
      )}

      {errorItems.length > 0 && (
        <>
          {/* <Typography variant="subtitle1">No completados</Typography> */}
          {errorItems.map((item) => (
            <ResumeItem key={item.object_id} dataItem={item} success={false} />
          ))}
        </>
      )}
      <Button onClick={finalizarPago} variant="contained" fullWidth>
        Ver lista de transacciones
      </Button>
    </Card>
  );
}

export default FinalStep;
