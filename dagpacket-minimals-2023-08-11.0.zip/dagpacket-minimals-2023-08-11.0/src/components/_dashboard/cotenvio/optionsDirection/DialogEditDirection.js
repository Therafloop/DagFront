import React, { useState } from 'react';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  ListItemIcon,
  ListItemText,
  MenuItem,
  Typography
} from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import DireccionForm from '../DireccionForm';
import useAuthUsers from '../../../../hooks/useAuthUsers';

export default function DialogEditDirection({ direction, tipo }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      {/* <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Abrir dialogo
      </Button> */}
      <MenuItem onClick={() => setOpenDialog(true)}>
        <ListItemIcon>
          <Icon icon="grommet-icons:update" />
        </ListItemIcon>
        <ListItemText>Editar</ListItemText>
      </MenuItem>
      <DialogBody open={openDialog} onClose={setOpenDialog} direction={direction} tipo={tipo} />
    </>
  );
}

function DialogBody({ open, onClose, direction, tipo }) {
  const { currentUser } = useAuthUsers();

  const handleClose = () => {
    onClose(false);
  };

  console.log(direction);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <DireccionForm
          dataDireccion={direction}
          handleClose={handleClose}
          user={currentUser}
          reason="update"
          onlyDirection
          originDirection={tipo}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
