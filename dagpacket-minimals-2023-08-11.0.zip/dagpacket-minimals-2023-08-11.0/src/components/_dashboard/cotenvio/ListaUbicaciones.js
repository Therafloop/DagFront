/* eslint-disable no-nested-ternary */
import {
  Card,
  Box,
  Typography,
  Button,
  Divider,
  Grid,
  IconButton,
  Dialog,
  DialogTitle,
  styled,
  MenuItem,
  Menu,
  ListItemIcon,
  ListItemText,
  TextField,
  InputAdornment,
  Tooltip,
  DialogContent
} from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import {
  selectRemitDireccion,
  selectDestiDireccion,
  setIdSelectedRemit,
  setIdSelectedDesti,
  resetDirectionDestitSelect,
  resetDirectionRemitSelect
} from '../../../redux/slices/dagpacket';
import { Icon } from '@iconify/react';
import { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import PropTypes from 'prop-types';
import DialogEditDirection from './optionsDirection/DialogEditDirection';
import { NewDirectionSchema } from './DireccionForm';
import { useSnackbar } from 'notistack';

export default function ListaUbicaciones({ handleClickOpen, sestOriginDirection }) {
  const [showRemitDirec, setShowRemitDirec] = useState(false);
  const [showDestiDirec, setShowDestiDirec] = useState(false);
  const [searchRemit, setSearchRemit] = useState('');
  const [searchDesti, setSearchDesti] = useState('');
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const { direccionesCot } = useSelector((state) => state.dagpacket);
  const dispatch = useDispatch();
  const { direcciones, direccionRemitSelec, direccionDestiSelec, idSelectedRemit, idSelectedDesti } = direccionesCot;

  // console.log('este es el seleccionado', direcciones);

  const direcRemitente = direcciones
    .filter((dir) => dir.zipcode === queryParams.get('zipcode_from')?.toString())
    .filter((item) => {
      if (searchRemit === '') {
        return item;
      }
      if (item.name.toLowerCase().includes(searchRemit.toLowerCase())) {
        return item;
      }
      return false;
    });

  const direcDestinatario = direcciones
    .filter((dir) => dir.zipcode === queryParams.get('zipcode_to')?.toString())
    // eslint-disable-next-line array-callback-return
    .filter((item) => {
      if (searchDesti === '') {
        return item;
      }
      if (item.name.toLowerCase().includes(searchDesti.toLowerCase())) {
        return item;
      }
      return false;
    });

  useEffect(() => {
    const remit = direcciones.find((direc) => direc.id === idSelectedRemit);
    const desti = direcciones.find((direc) => direc.id === idSelectedDesti);

    // queryParamsEffect es lo mismo que queryParams solo que esta en el iiseefect xdP
    const queryParamsEffect = new URLSearchParams(search);
    if (idSelectedRemit) {
      // console.log('---------', remit);
      if (remit === undefined) {
        dispatch(setIdSelectedRemit(null));
        dispatch(resetDirectionRemitSelect());
      } else if (remit.zipcode !== queryParamsEffect.get('zipcode_from')?.toString()) {
        dispatch(setIdSelectedRemit(null));
        dispatch(resetDirectionRemitSelect());
      } else {
        const direct = {
          id_from: remit.id || '',
          name_from: remit.name || '',
          street_from: remit.street || '',
          calle_from: remit.street || '',
          colonia_from: remit.colonia || '',
          reference_from: remit.reference,
          zipcode_from: remit.zipcode,
          interior_number_from: remit.interior_number || '',
          exterior_number_from: remit.exterior_number || '',
          phone_from: remit.phone || '',
          email_from: remit.email || '',
          role_from: remit.role || '',
          company_from: remit.company || ''
        };
        dispatch(selectRemitDireccion(direct));
      }
    }
    // else {
    //   dispatch(resetDirectionRemitSelect());
    //   dispatch(setIdSelectedRemit());
    // }

    if (idSelectedDesti) {
      // console.log('---------', desti);
      if (desti === undefined) {
        dispatch(resetDirectionDestitSelect());
        dispatch(setIdSelectedDesti(null));
      } else if (desti.zipcode !== queryParamsEffect.get('zipcode_to')?.toString()) {
        dispatch(resetDirectionDestitSelect());
        dispatch(setIdSelectedDesti(null));
      } else {
        const direct = {
          id_to: desti?.id || '',
          name_to: desti?.name || '',
          street_to: desti?.street || '',
          calle_to: desti?.calle || '',
          colonia_to: desti?.colonia || '',
          reference_to: desti?.reference,
          zipcode_to: desti?.zipcode,
          interior_number_to: desti?.interior_number || '',
          exterior_number_to: desti?.exterior_number || '',
          phone_to: desti?.phone || '',
          email_to: desti?.email || '',
          role_to: desti?.role || '',
          company_to: desti?.company || ''
        };
        dispatch(selectDestiDireccion(direct));
      }
    }
  }, [direcciones, dispatch, idSelectedRemit, idSelectedDesti, search]);

  return (
    <Grid container spacing={2}>
      <Grid item xs={12} md={6}>
        {/* ---------------------seccion remitente ------------------------ */}
        <Card sx={{ padding: '10px', flexGrow: 1 }}>
          <Typography variant="subtitle1" textAlign="center">
            Direcciones del remitente con codigo ZIP {queryParams.get('zipcode_from')}
          </Typography>

          <Divider />

          <Box marginTop="15px" display="flex" gap="15px" height="150px" justifyContent="center">
            <Button
              onClick={() => setShowRemitDirec(true)}
              variant="contained"
              color="info"
              endIcon={<Icon icon="eva:search-fill" />}
            >
              Buscar dirección
            </Button>
            <Button
              onClick={() => {
                handleClickOpen();
                sestOriginDirection('remit');
              }}
              variant="contained"
              color="error"
              endIcon={<Icon icon="eva:plus-outline" />}
            >
              Agregar dirección
            </Button>
          </Box>

          <Dialog
            open={showRemitDirec}
            onClose={() => setShowRemitDirec(false)}
            // maxWidth="md"
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <Box padding="10px 25px">
              <Typography variant="subtitle1">
                Lista de direcciones con el codigo ZIP {queryParams.get('zipcode_from')}
              </Typography>
              <Box marginTop="15px" display="flex" justifyContent="space-between" alignItems="center">
                <TextField
                  sx={{ marginTop: '15px' }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Icon fontSize="25px" icon="eva:search-fill" />
                      </InputAdornment>
                    )
                  }}
                  label="Buscar"
                  variant="outlined"
                  value={searchRemit}
                  onChange={(e) => setSearchRemit(e.target.value)}
                />
              </Box>
            </Box>
            <DialogContent>
              <Box>
                {direcRemitente.length === 0 && <EmptyCart />}
                {direcRemitente.map((direc) => (
                  <CardDirection key={direc.id} direction={direc} tipo="remitente" onClose={setShowRemitDirec} />
                ))}
              </Box>
            </DialogContent>
          </Dialog>

          {Object.entries(direccionRemitSelec).length !== 0 ? (
            <Box>
              <Box padding="0 15px">
                <Typography variant="subtitle2" marginTop="15px">
                  Dirección selecionada:
                </Typography>
              </Box>
              <SelectedDirectionCard data={direccionRemitSelec} tipo="remit" />
            </Box>
          ) : null}
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        {/* ---------------------seccion destinatario ------------------------ */}
        <Card sx={{ padding: '10px', flexGrow: 1 }}>
          <Typography variant="subtitle1" textAlign="center">
            Direcciones del destinatario con codigo ZIP {queryParams.get('zipcode_to')}
          </Typography>
          <Divider />

          <Box marginTop="15px" display="flex" gap="15px" height="150px" justifyContent="center">
            <Button
              onClick={() => setShowDestiDirec(true)}
              variant="contained"
              color="info"
              endIcon={<Icon icon="eva:search-fill" />}
            >
              Buscar dirección
            </Button>
            <Button
              onClick={() => {
                handleClickOpen();
                sestOriginDirection('desti');
              }}
              variant="contained"
              color="error"
              endIcon={<Icon icon="eva:plus-outline" />}
            >
              Agregar dirección
            </Button>
          </Box>

          <Dialog
            open={showDestiDirec}
            onClose={() => setShowDestiDirec(false)}
            // maxWidth="md"
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <Box padding="10px 25px">
              <Typography variant="subtitle1">
                Lista de direcciones con el codigo ZIP {queryParams.get('zipcode_to')}
              </Typography>
              <Box marginTop="15px" display="flex" justifyContent="space-between" alignItems="center">
                <TextField
                  sx={{ marginTop: '15px' }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Icon fontSize="25px" icon="eva:search-fill" />
                      </InputAdornment>
                    )
                  }}
                  label="Buscar"
                  variant="outlined"
                  value={searchDesti}
                  onChange={(e) => setSearchDesti(e.target.value)}
                />
                {/* <Box>
                  <Tooltip title="Agregar remitente">
                    <IconButton
                      onClick={() => {
                        handleClickOpen();
                        sestOriginDirection('remit');
                      }}
                      variant="contained"
                      color="error"
                    >
                      <Icon icon="eva:plus-outline" />
                    </IconButton>
                  </Tooltip>
                </Box> */}
              </Box>
            </Box>
            <DialogContent>
              <Box>
                {direcDestinatario.length === 0 && <EmptyCart />}
                {direcDestinatario.map((direc) => (
                  <CardDirection key={direc.id} direction={direc} tipo="destinatario" onClose={setShowDestiDirec} />
                ))}
              </Box>
            </DialogContent>
          </Dialog>

          {Object.entries(direccionDestiSelec).length !== 0 ? (
            <Box>
              <Box padding="0 15px">
                <Typography variant="subtitle2" marginTop="15px">
                  Dirección selecionada:
                </Typography>
              </Box>
              <SelectedDirectionCard data={direccionDestiSelec} tipo="desti" />
            </Box>
          ) : null}

          {/* <Box>
            <Box padding="0 15px">
              <Typography variant="subtitle2" marginTop="15px">
                Dirección selecionada:
              </Typography>
            </Box>

            {Object.entries(direccionDestiSelec).length !== 0 ? (
              <SelectedDirectionCard data={direccionDestiSelec} tipo="desti" />
            ) : (
              <EmptyCart tipo="dir_select" />
            )}
          </Box> */}
        </Card>
      </Grid>
    </Grid>
  );
}

const CuztomCard = styled(Card)(() => ({
  marginTop: '15px',
  padding: '20px 15px',
  display: 'flex',
  alignItems: 'center'
}));

const BoxData = styled(Box)(() => ({
  display: 'grid',
  gridTemplateColumns: '90px 1fr'
}));

CardDirection.propTypes = {
  direction: PropTypes.object,
  tipo: PropTypes.string
};

function CardDirection({ direction, tipo, onClose }) {
  // menu
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClickMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleCloseMenu = () => {
    setAnchorEl(null);
  };
  // ---------
  const [openDialog, setOpenDialog] = useState(false);
  const { name, street, street2, reference, colonia, exterior_number } = direction;
  const dispatch = useDispatch();
  const { direccionesCot } = useSelector((state) => state.dagpacket);
  const { enqueueSnackbar } = useSnackbar();
  const { idSelectedRemit, idSelectedDesti } = direccionesCot;

  const seleccionarDireccion = (data) => {
    NewDirectionSchema.validate(data)
      .then((validatedData) => {
        // console.log(validatedData);
        if (tipo === 'remitente') {
          // const direct = {
          //   id_from: data.id,
          //   name_from: data.name,
          //   street_from: data.street,
          //   colonia_from: data.colonia || '',
          //   reference_from: data.reference,
          //   zipcode_from: data.zipcode,
          //   interior_number_from: data.interior_number || '',
          //   exterior_number_from: data.exterior_number || '',
          //   phone_from: data.phone || '',
          //   email_from: data.email || '',
          //   role_from: data.role || '',
          //   company_from: data.company || ''
          // };
          // console.log(direct);
          // dispatch(selectRemitDireccion(direct));
          dispatch(setIdSelectedRemit(data.id));
        } else {
          // const direct = {
          //   id_to: data.id,
          //   name_to: data.name,
          //   street_to: data.street,
          //   colonia_to: data.colonia || '',
          //   reference_to: data.reference,
          //   zipcode_to: data.zipcode,
          //   interior_number_to: data.interior_number || '',
          //   exterior_number_to: data.exterior_number || '',
          //   phone_to: data.phone || '',
          //   email_to: data.email || '',
          //   role_to: data.role || '',
          //   company_to: data.company || ''
          // };
          // console.log(direct);
          // dispatch(selectDestiDireccion(direct));
          dispatch(setIdSelectedDesti(data.id));
        }
      })
      .catch((e) => {
        console.log(e.message);
        enqueueSnackbar(`Esta direccion no cumple con el formato correcto, ${e.message}`, { variant: 'error' });
      });

    // console.log(data);
  };

  // useEffect(() => {
  //   if (direction.id === idSelectedRemit || direction.id === idSelectedDesti) {
  //     seleccionarDireccion(direction);
  //   }
  //   // eslint-disable-next-line
  // }, [direction, idSelectedDesti, idSelectedRemit]);

  const deleteDirection = () => {
    firestore
      .collection('direcciones')
      .doc(direction.id)
      .delete()
      .then(() => console.log('Eliminado'));
  };

  const handleClickOpen = () => {
    setOpenDialog(true);
  };

  const handleClose = () => {
    setOpenDialog(false);
  };
  return (
    <CuztomCard>
      <Box sx={{ flexGrow: 1 }}>
        {direction?.directionTemporal && (
          <BoxData>
            <Typography variant="subtitle2"> </Typography>
            <Typography variant="subtitle2" color="red" fontStyle="italic">
              Dirección Temporal
            </Typography>
          </BoxData>
        )}
        <BoxData>
          <Typography variant="subtitle2">Nombre:</Typography>
          <Typography variant="body2">{name}</Typography>
        </BoxData>
        <BoxData>
          <Typography variant="subtitle2" width="90px">
            Dirección:
          </Typography>
          <Typography variant="body2">
            {street} {exterior_number}
          </Typography>
        </BoxData>
        <BoxData>
          <Typography variant="subtitle2" width="90px">
            Colonia:
          </Typography>
          <Typography variant="body2">{colonia}</Typography>
        </BoxData>
        <BoxData>
          <Typography variant="subtitle2" width="90px">
            Referencia:
          </Typography>
          <Typography variant="body2">{reference}</Typography>
        </BoxData>
      </Box>
      <Box sx={{ display: 'flex', gap: '5px', justifyContent: 'center', alignItems: 'center' }}>
        <Button
          // color={
          //   tipo === 'remitente'
          //     ? idSelectedRemit === direction.id
          //       ? 'info'
          //       : 'primary'
          //     : idSelectedDesti === direction.id
          //     ? 'info'
          //     : 'primary'
          // }
          onClick={() => {
            seleccionarDireccion(direction);
            // este onclose es para que se cierre el dialogo
            onClose(false);
          }}
          size="small"
        >
          {tipo === 'remitente' ? (
            idSelectedRemit === direction.id ? (
              <Icon fontSize="20px" icon="eva:checkmark-circle-2-fill" />
            ) : (
              'Elegir'
            )
          ) : idSelectedDesti === direction.id ? (
            <Icon fontSize="20px" icon="eva:checkmark-circle-2-fill" />
          ) : (
            'Elegir'
          )}
        </Button>
        {!direction?.directionTemporal && (
          <Box>
            <IconButton
              color="error"
              size="small"
              id="basic-button"
              aria-controls={open ? 'basic-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              onClick={handleClickMenu}
            >
              <Icon icon="eva:more-vertical-fill" />
            </IconButton>
            <Menu
              id="basic-menu"
              anchorEl={anchorEl}
              open={open}
              onClose={handleCloseMenu}
              MenuListProps={{
                'aria-labelledby': 'basic-button'
              }}
            >
              <DialogEditDirection direction={direction} tipo={tipo} />
            </Menu>
          </Box>
        )}
        {/* <IconButton color="error" size="small" onClick={handleClickOpen}>
          <Icon icon="eva:trash-2-fill" />
        </IconButton> */}
        <SimpleDialog open={openDialog} handleClose={handleClose} deleteDirection={deleteDirection} />
      </Box>
    </CuztomCard>
  );
}

const VoidCard = styled(Card)(() => ({
  marginTop: '15px',
  padding: '30px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '20px'
}));

function EmptyCart({ tipo = 'direciones' }) {
  // const { search } = useLocation();
  // const queryParams = new URLSearchParams(search);

  return (
    <VoidCard>
      {tipo === 'direciones' && (
        <>
          <img width="15%" src="/static/illustrations/empty_data.svg" alt="empty" />
          <Typography variant="subtitle2">Aun no tienes direcciones con este codigo ZIP</Typography>
        </>
      )}
      {tipo === 'dir_select' && (
        <>
          <img width="15%" src="/static/illustrations/empty.svg" alt="empty" />
          <Box>
            <Typography variant="subtitle1">Aun no has selecionado ninguna dirección</Typography>
            <Typography variant="subtitle2">Ve a buscar dirección y selecciona alguna.</Typography>
          </Box>
        </>
      )}
    </VoidCard>
  );
}

SimpleDialog.propTypes = {
  handleClose: PropTypes.func,
  open: PropTypes.bool,
  deleteDirection: PropTypes.func
};

function SimpleDialog({ handleClose, open, deleteDirection }) {
  return (
    <Dialog onClose={handleClose} open={open}>
      <DialogTitle>¿Seguro que desea eliminar esta direccion?</DialogTitle>

      <Box display="flex" justifyContent="center" gap={5} marginBottom={2} marginTop={5} paddingX={2}>
        <Button variant="contained" color="error" onClick={deleteDirection}>
          Eliminar
        </Button>
        <Button variant="contained" onClick={handleClose} color="primary">
          Cancelar
        </Button>
      </Box>
    </Dialog>
  );
}

function SelectedDirectionCard({ data, tipo }) {
  const dispatch = useDispatch();
  const removeDirection = () => {
    if (tipo === 'remit') {
      dispatch(setIdSelectedRemit(null));
      dispatch(resetDirectionRemitSelect());
    } else {
      dispatch(setIdSelectedDesti(null));
      dispatch(resetDirectionDestitSelect());
    }
  };
  return (
    <CuztomCard>
      {tipo === 'remit' ? (
        <Box sx={{ flexGrow: 1 }}>
          <BoxData>
            <Typography variant="subtitle2">Nombre:</Typography>
            <Typography variant="body2">{data.name_from}</Typography>
          </BoxData>
          <BoxData>
            <Typography variant="subtitle2" width="90px">
              Dirección:
            </Typography>
            <Typography variant="body2">
              {data.street_from} {data.exterior_number_from}
            </Typography>
          </BoxData>
          <BoxData>
            <Typography variant="subtitle2" width="90px">
              Colonia:
            </Typography>
            <Typography variant="body2">{data.colonia_from}</Typography>
          </BoxData>
          <BoxData>
            <Typography variant="subtitle2" width="90px">
              Referencia:
            </Typography>
            <Typography variant="body2">{data.reference_from}</Typography>
          </BoxData>
        </Box>
      ) : (
        <Box sx={{ flexGrow: 1 }}>
          <BoxData>
            <Typography variant="subtitle2">Nombre:</Typography>
            <Typography variant="body2">{data.name_to}</Typography>
          </BoxData>
          <BoxData>
            <Typography variant="subtitle2" width="90px">
              Dirección:
            </Typography>
            <Typography variant="body2">
              {data.street_to} {data.exterior_number_to}
            </Typography>
          </BoxData>
          <BoxData>
            <Typography variant="subtitle2" width="90px">
              Colonia:
            </Typography>
            <Typography variant="body2">{data.colonia_to}</Typography>
          </BoxData>
          <BoxData>
            <Typography variant="subtitle2" width="90px">
              Referencia:
            </Typography>
            <Typography variant="body2">{data.reference_to}</Typography>
          </BoxData>
        </Box>
      )}
      <Box sx={{ display: 'flex', gap: '5px', justifyContent: 'center', alignItems: 'center' }}>
        <Tooltip title="Dirección selecionada">
          <IconButton size="large" color="info">
            <Icon fontSize="30px" icon="eva:checkmark-circle-2-fill" />
          </IconButton>
        </Tooltip>
        <IconButton size="large" color="info" onClick={removeDirection}>
          <Icon icon="eva:trash-2-outline" />
        </IconButton>
      </Box>
    </CuztomCard>
  );
}
