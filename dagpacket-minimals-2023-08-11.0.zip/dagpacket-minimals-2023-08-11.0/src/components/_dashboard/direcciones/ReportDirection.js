import { useEffect, useState } from 'react';
import ReporteExcelButton from '../../atomos/ReporteExcelButton';

export function ReportDirection({ directions }) {
  const [directionsReport, setDirectionsReport] = useState([]);

  useEffect(() => {
    const reporte = directions.map((d) => ({
      Nombre: d?.name ?? '',
      Email: d?.email ?? '',
      Telefono: d?.phone ?? '',
      Pais: d?.pais ?? '',
      CP: d?.zipcode ?? '',
      Estado: d?.estado ?? '',
      Ciudad: d?.ciudad ?? '',
      Colonia: d?.colonia ?? '',
      Calle: d?.street ?? '',
      Numero_Exterior: d?.exterior_number ?? '',
      Numero_Interior: d?.interior_number ?? '',
      Referencia: d?.reference ?? '',
      Usuario: d?.user?.displayName,
      Usuario_Email: d?.user?.email,
      Usuario_Rol: d?.user?.role,
      Licensatario: d?.licensee?.displayName,
      Licensatario_Email: d?.licensee?.email
    }));
    setDirectionsReport(reporte);
  }, [directions]);

  return <ReporteExcelButton dataList={directionsReport} notSort />;
}
