import { Table, TableRow, TableBody, TableCell, TableContainer, TablePagination, Box } from '@mui/material';
import { ProductListHead } from '../../e-commerce/product-list';
import SearchNotFound from '../../../SearchNotFound';
import { TABLE_HEAD } from '../dialogDirectionUtil';
import { filter } from 'lodash';
import { emptyRowsF } from '../../../../utils/pagination';
import { useState } from 'react';
import { getComparator } from '../../../../utils/tableUtils';
import { TableRowDirection } from './TableRowDirection';

function applySortFilter(array, comparator, filterName) {
  const query = filterName?.trim();
  const stabilizedThis = array?.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });

  if (query) {
    return filter(
      array,
      (item) =>
        item?.zipcode?.toLowerCase().indexOf(query.toLowerCase()) !== -1 ||
        item?.name?.toLowerCase().indexOf(query.toLowerCase()) !== -1 ||
        item?.estado?.toLowerCase().indexOf(query.toLowerCase()) !== -1 ||
        item?.ciudad?.toLowerCase().indexOf(query.toLowerCase()) !== -1 ||
        item?.street?.toLowerCase().indexOf(query.toLowerCase()) !== -1 ||
        item?.colonia?.toLowerCase().indexOf(query.toLowerCase()) !== -1
    );
  }

  return stabilizedThis.map((el) => el[0]);
}

export function TableDirection({ directions, editClick, filterName, isLoading }) {
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [orderBy, setOrderBy] = useState('createdAt');
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');

  const emptyRows = emptyRowsF(page, rowsPerPage, directions);
  const isProductNotFound = filteredData?.length === 0;
  const filteredData = applySortFilter(directions, getComparator(order, orderBy), filterName);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };
  return (
    <>
      <TableContainer sx={{ minWidth: 800 }}>
        <Table>
          <ProductListHead
            order={order}
            orderBy={orderBy}
            headLabel={TABLE_HEAD}
            rowCount={directions?.length}
            onRequestSort={handleRequestSort}
            checkbox={false}
          />
          <TableBody>
            {filteredData?.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
              <TableRowDirection key={row.id} direction={row} editClick={editClick} />
            ))}
            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={6} />
              </TableRow>
            )}
          </TableBody>
          {isLoading && (
            <Box display="flex" justifyContent="center" p={4}>
              Cargando...
            </Box>
          )}
          {isProductNotFound && !isLoading && (
            <TableBody>
              <TableRow>
                <TableCell align="center" colSpan={6}>
                  <Box sx={{ py: 3 }}>
                    <SearchNotFound searchQuery={filterName} />
                  </Box>
                </TableCell>
              </TableRow>
            </TableBody>
          )}
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={directions?.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={(event, newPage) => setPage(newPage)}
        onRowsPerPageChange={(event) => {
          setRowsPerPage(parseInt(event.target.value, 10));
          setPage(0);
        }}
      />
    </>
  );
}
