import { TableRow, TableCell, Typography, Button, Box } from '@mui/material';
import Label from '../../../Label';

export function TableRowDirection({ direction, editClick, admin }) {
  const { id, zipcode, name, estado, ciudad, pais, isInternational, street, exterior_number, user, licensee } =
    direction;

  return (
    <TableRow hover key={id} tabIndex={-1} role="checkbox">
      <TableCell component="th" scope="row" padding="none">
        <Box
          sx={{
            py: 2,
            display: 'flex',
            alignItems: 'center'
          }}
        >
          <Typography variant="subtitle2" noWrap>
            {zipcode}
          </Typography>
        </Box>
      </TableCell>
      <TableCell align="right">{name}</TableCell>

      <TableCell align="right">
        <Label color={!isInternational ? 'success' : 'error'}>{!isInternational ? 'SI' : 'NO'}</Label>
      </TableCell>
      <TableCell align="right">{pais ?? '--'}</TableCell>
      <TableCell>
        {street} {exterior_number} {ciudad} {estado} {ciudad}
      </TableCell>
      <TableCell>{user?.displayName}</TableCell>
      <TableCell>{licensee?.displayName}</TableCell>
      <TableCell align="right" onClick={() => editClick(direction)}>
        <Button variant="contained">Detalle</Button>
      </TableCell>
    </TableRow>
  );
}
