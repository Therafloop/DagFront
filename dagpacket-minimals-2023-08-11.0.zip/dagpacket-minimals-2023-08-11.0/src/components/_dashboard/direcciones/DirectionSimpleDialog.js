import { Box, Button, Dialog, DialogTitle } from '@mui/material';

export function DirectionSimpleDialog({ handleClose, open, deleteDirection }) {
  return (
    <Dialog onClose={handleClose} open={open}>
      <DialogTitle>¿Seguro que desea eliminar esta direccion?</DialogTitle>

      <Box display="flex" justifyContent="center" gap={5} marginBottom={2} marginTop={5} paddingX={2}>
        <Button
          variant="contained"
          color="error"
          onClick={() => {
            deleteDirection();
            handleClose();
          }}
        >
          Eliminar
        </Button>
        <Button variant="contained" onClick={handleClose} color="primary">
          Cancelar
        </Button>
      </Box>
    </Dialog>
  );
}
