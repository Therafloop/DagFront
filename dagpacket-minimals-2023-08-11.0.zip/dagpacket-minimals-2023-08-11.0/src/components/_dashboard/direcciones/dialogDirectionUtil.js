import { removeSpcialCharacters } from '../../../utils/formatText';

export const initialValues = {
  name: '',
  email: '',
  phone: '',
  street: '',
  interior_number: '',
  exterior_number: '',
  colonia: '',
  reference: '',
  company: '',
  role: '',
  avatarUrl: null,
  zipcode: '',
  estado: '',
  ciudad: '',
  pais: '',
  isInternational: false
};

export const editValues = (dataDireccion) => ({
  name: dataDireccion?.name || '',
  email: dataDireccion?.email || '',
  phone: dataDireccion?.phone || '',
  street: dataDireccion?.street || '',
  interior_number: dataDireccion?.interior_number || '',
  exterior_number: dataDireccion?.exterior_number || '',
  colonia: dataDireccion?.colonia || '',
  reference: dataDireccion?.reference || '',
  company: dataDireccion?.company || '',
  role: dataDireccion?.role || '',
  avatarUrl: dataDireccion?.avatarUrl || null,
  zipcode: dataDireccion?.zipcode || '',
  estado: dataDireccion?.estado || '',
  ciudad: dataDireccion?.ciudad || '',
  pais: dataDireccion?.pais || '',
  isInternational: dataDireccion?.isInternational || false
});

export const TABLE_HEAD = [
  { id: 'zipcode', label: 'C.P', alignRight: false },
  { id: 'name', label: 'Nombre', alignRight: true },
  { id: 'isInternacional', label: 'Nacional', alignRight: true },
  { id: 'pais', label: 'Pais', alignRight: true },
  { id: 'direccion', label: 'Dirección', alignRight: false },
  { id: 'user', label: 'Usuario', alignRight: false },
  { id: 'Licensatario', label: 'Licensatario', alignRight: false },
  { id: '' }
];
export const getInternational = (text) => {
  const value = removeSpcialCharacters(text);
  const pais = ['mexico', 'méxico', 'mx', 'república mexicana', 'méjico', 'mex', 'usa-mex', 'eum'];

  return !pais.includes(String(value).toLowerCase());
};
