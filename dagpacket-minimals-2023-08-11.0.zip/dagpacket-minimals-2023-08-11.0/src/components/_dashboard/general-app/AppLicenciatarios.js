import React, { useState, useEffect } from 'react';
import { Card, CardContent, TableContainer, Table, TableRow, TableCell, TableHead, TableBody } from '@mui/material';
import PropTypes from 'prop-types';
import { firestore } from '../../../contexts/FirebaseContext';

// ----------------------------------------------------------------------

UserItem.propTypes = {
  user: PropTypes.object
};

function UserItem({ user }) {
  return (
    <TableRow>
      <TableCell>{user.name}</TableCell>
      <TableCell>{user.email}</TableCell>
      <TableCell>{user.role}</TableCell>
    </TableRow>
  );
}

// ----------------------------------------------------------------------

export default function AppUsuarios() {
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    async function getUsuarios() {
      await firestore.collection('licenciatarios').onSnapshot((queryS) => {
        const dat = [];
        queryS.forEach((doc) => {
          dat.push({
            id: doc.id,
            ...doc.data()
          });
        });
        console.log(dat);
        setUsuarios(dat);
      });
    }
    getUsuarios();
  }, []);
  return (
    <Card>
      <CardContent>
        <h3>Licenciatarios</h3>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Nombre</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>Rol</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {usuarios.map((user) => (
                <UserItem key={user.id} user={user} />
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </CardContent>
    </Card>
  );
}
