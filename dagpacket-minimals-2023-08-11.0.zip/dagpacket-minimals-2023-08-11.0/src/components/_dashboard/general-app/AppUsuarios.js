import React, { useState, useEffect } from 'react';
import { TableContainer, Table, TableRow, TableCell, TableHead, TableBody } from '@mui/material';
import PropTypes from 'prop-types';
import { firestore } from '../../../contexts/FirebaseContext';

// ----------------------------------------------------------------------

UserItem.propTypes = {
  user: PropTypes.object
};

function UserItem({ user }) {
  return (
    <TableRow>
      <TableCell>{user.nombre}</TableCell>
      <TableCell>{user.email}</TableCell>
      <TableCell>{user.nuser}</TableCell>
    </TableRow>
  );
}

// ----------------------------------------------------------------------

export default function AppUsuarios() {
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    async function getUsuarios() {
      await firestore.collection('usuarios').onSnapshot((queryS) => {
        const dat = [];
        queryS.forEach((doc) => {
          dat.push({
            id: doc.id,
            ...doc.data()
          });
        });
        setUsuarios(dat);
      });
    }
    getUsuarios();
  }, []);
  return (
    <TableContainer>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Nombre</TableCell>
            <TableCell>Email</TableCell>
            <TableCell>id de usuario</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {usuarios.map((user) => (
            <UserItem key={user.id} user={user} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
