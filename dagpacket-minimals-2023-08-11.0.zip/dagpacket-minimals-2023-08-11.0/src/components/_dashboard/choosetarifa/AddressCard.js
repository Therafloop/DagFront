import React from 'react';
// mui
import { Card, CardHeader, CardContent, Typography } from '@mui/material';

import PropTypes from 'prop-types';

AddressCard.propTypes = {
  title: PropTypes.string,
  address: PropTypes.object.isRequired
};

export default function AddressCard({ title = '', address }) {
  const { city, country, zipcode, name, level_3, street, street2 } = address;

  return (
    <Card>
      <CardHeader title={title} />
      <CardContent>
        <Typography variant="body1">Nombre: {name}</Typography>
        <Typography variant="body1">CP: {zipcode}</Typography>
        <Typography variant="body1">{country}</Typography>
        <Typography variant="body1">{level_3}</Typography>
        <Typography variant="body1">{city}</Typography>
        <Typography variant="body1">{street}</Typography>
        <Typography variant="body1">{street2}</Typography>
      </CardContent>
    </Card>
  );
}
