import { Card, CardContent, CardHeader, Typography, Grid } from '@mui/material';
import NuevaSucursalForm from './NuevaSucursalForm';
import PropTypes from 'prop-types';

SucursalCard.propTypes = {
  info: PropTypes.object
};

export default function SucursalCard({ info }) {
  const { id, nombre, domicilio, ubicacion } = info;

  return (
    <Card>
      <CardHeader
        title={nombre}
        action={
          <>
            <NuevaSucursalForm id={id} edit />
          </>
        }
      />
      <CardContent>
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Typography variant="h3">{domicilio}</Typography>
          </Grid>
          <Grid item xs={12}>
            map
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
}
