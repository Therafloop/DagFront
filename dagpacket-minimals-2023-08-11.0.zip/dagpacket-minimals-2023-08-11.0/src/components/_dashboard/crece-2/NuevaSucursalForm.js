import { useState, useEffect } from 'react';

import { Button, Dialog, Card, CardContent, Grid, TextField, CardHeader } from '@mui/material';
import { LoadingButton } from '@mui/lab';

import { useFormik, FormikProvider, Form } from 'formik';
import * as yup from 'yup';
import { firestore } from '../../../contexts/FirebaseContext';
import PropTypes from 'prop-types';

import { v4 as uuidV4 } from 'uuid';

NuevaSucursalForm.propTypes = {
  id: PropTypes.string,
  edit: PropTypes.bool
};

export default function NuevaSucursalForm({ id, edit = false }) {
  const [open, setOpen] = useState(false);

  const clickOpen = () => {
    setOpen(true);
  };

  const clickClose = () => {
    setOpen(false);
  };

  const validationSchema = yup.object().shape({});

  const formik = useFormik({
    validationSchema,
    initialValues: {
      nombre: '',
      identificador: '',
      domicilio: '',
      ubicacion: { lat: 0, lgt: 0 }
    },
    onSubmit: async () => {}
  });

  const { getFieldProps, isSubmitting, setFieldValue, handleSubmit } = formik;

  useEffect(() => {
    (async function () {
      const doc = await firestore.collection('sucursales').doc(id).get();
      if (!doc.exists()) return;

      const data = doc.data();
      const keys = Object.keys(data);
      keys.forEach((d) => {
        setFieldValue(d, data[d]);
      });
    })();
  }, [id]);

  return (
    <>
      <Button variant="contained" onClick={clickOpen}>
        {edit ? 'Editar' : 'Nueva Sucursal'}
      </Button>
      <Dialog open={open} onClose={clickClose}>
        <Card>
          <CardHeader title={edit ? 'Nueva Sucursal' : 'Editar Sucursal'} />
          <CardContent>
            <FormikProvider formik={formik}>
              <Form autoComplete="off" onSubmit={handleSubmit}>
                <Grid container spacing={1}>
                  <Grid item xs={12}>
                    <TextField label="identificador" {...getFieldProps('identificador')} fullWidth />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField label="Domicilio" {...getFieldProps('domicilio')} />
                  </Grid>
                </Grid>
                <Grid item xs={12}>
                  <LoadingButton variant="contained" loading={isSubmitting} type="submit" fullwidth>
                    {edit ? 'Crear' : 'Guardar Cambios'}
                  </LoadingButton>
                </Grid>
              </Form>
            </FormikProvider>
          </CardContent>
        </Card>
      </Dialog>
    </>
  );
}
