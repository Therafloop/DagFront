import React, { useState, useEffect } from 'react';
import { Box } from '@mui/material';
import Loading from '../../../LoadingScreen';
import CTA from './CtaWithCoverImage';
import { firestore } from '../../../../contexts/FirebaseContext';
import PropTypes from 'prop-types';

CTASub.propTypes = {
  id: PropTypes.string.isRequired
};

export default function CTASub({ id }) {
  const [infoCTA, setInfoCTA] = useState(null);

  useEffect(() => {
    async function getCTA() {
      await firestore
        .collection('ctas')
        .doc(id)
        .onSnapshot((doc) => {
          if (doc.exists) {
            setInfoCTA(doc.data());
          }
        });
    }
    getCTA();
  }, [id]);

  return <Box>{infoCTA ? <CTA info={infoCTA} /> : <Loading />}</Box>;
}
