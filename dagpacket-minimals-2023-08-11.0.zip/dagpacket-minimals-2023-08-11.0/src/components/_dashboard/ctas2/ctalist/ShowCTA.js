import React, { useState, useEffect } from 'react';
import { Box } from '@mui/material';
import CTASub from './CTASub';
import MainMenuCTA from './MainMenuCTA';

// hooks
import useMember from '../../../../hooks/useMember';
import useAuth from '../../../../hooks/useAuth';

import { firestore } from '../../../../contexts/FirebaseContext';
import PropTypes from 'prop-types';

ShowCTA.propTypes = {
  locationId: PropTypes.string.isRequired
};

export default function ShowCTA({ locationId }) {
  const { user } = useAuth();
  const { etapas } = useMember();
  const [ctaAtract, setCTAAtract] = useState(null);
  const [ctaInteract, setCTAInteraccion] = useState(null);
  const [ctaDeleite, setCTADeleite] = useState(null);

  useEffect(() => {
    const etapa = etapas[locationId];
    if (!etapa && user.id) {
      const newEtapaObj = {};
      newEtapaObj[locationId] = 'atraccion';
      firestore.collection('ctaEtapas').doc(user.id).set(newEtapaObj);
    }
  }, [etapas, user, locationId]);

  useEffect(() => {
    async function getCTAs() {
      await firestore
        .collection('ctalocations')
        .doc(`${locationId}`)
        .onSnapshot((doc) => {
          if (doc.exists) {
            const data = doc.data();
            setCTAAtract(data.atraccion || null);
            setCTAInteraccion(data.interaccion || null);
            setCTADeleite(data.deleite || null);
          }
        });
    }
    getCTAs();
  }, [locationId, user]);

  return (
    <Box>
      <MainMenuCTA locationId={locationId} />
      {ctaAtract && etapas[locationId] === 'atraccion' && <CTASub id={ctaAtract} />}
      {ctaInteract && etapas[locationId] === 'interaccion' && <CTASub id={ctaInteract} />}
      {ctaDeleite && etapas[locationId] === 'deleite' && <CTASub id={ctaDeleite} />}
    </Box>
  );
}
