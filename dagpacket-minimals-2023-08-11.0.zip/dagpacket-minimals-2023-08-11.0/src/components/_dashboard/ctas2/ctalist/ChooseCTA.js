import React, { useState, useEffect } from 'react';
import { Box } from '@mui/material';
import CTAOption from './CTAOption';

import { firestore } from '../../../../contexts/FirebaseContext';
import PropTypes from 'prop-types';

ChooseCTA.propTypes = {
  locationId: PropTypes.string.isRequired,
  role: PropTypes.string
};

export default function ChooseCTA({ locationId, role = '' }) {
  const [ctas, setCTAs] = useState([]);
  const [roles, setRoles] = useState([]);
  const [location, setLocation] = useState(null);
  const guion = role ? '-' : '';

  useEffect(() => {
    async function getCTAs() {
      await firestore.collection('ctas').onSnapshot((snapshot) => {
        const ctasS = snapshot.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
        setCTAs(ctasS);
      });
    }
    async function getLocation() {
      await firestore
        .collection('ctalocations')
        .doc(`${locationId}${guion}${role}`)
        .onSnapshot((doc) => {
          if (doc.exists) {
            const data = doc.data();
            setLocation(data);
          }
        });
    }
    async function getRoles() {
      await firestore.collection('roles').onSnapshot((queryS) => {
        const rolesS = queryS.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
        setRoles(rolesS);
      });
    }
    getRoles();
    getLocation();
    getCTAs();
  }, [locationId, role, guion]);

  return (
    <Box>
      {ctas.map((cta) => (
        <CTAOption key={cta.id} id={cta.id} locationId={locationId} role={role} />
      ))}
    </Box>
  );
}
