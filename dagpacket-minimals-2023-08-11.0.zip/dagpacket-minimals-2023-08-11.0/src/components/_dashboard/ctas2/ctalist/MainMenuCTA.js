import React, { useState, useEffect } from 'react';
import { Grid } from '@mui/material';
import { ListA } from '../../../moleculas';
import CustomDialog from '../CustomDialog';
import AltaCTA from '../AltaCTA';
import ChooseCTA from './ChooseCTA';
import { firestore } from '../../../../contexts/FirebaseContext';

export default function MainMenuCTA({ locationId }) {
  const [roles, setRoles] = useState([]);

  useEffect(() => {
    async function getRoles() {
      await firestore.collection('roles').onSnapshot((queryS) => {
        const rolesS = queryS.docs.map((doc) => doc.id);
        setRoles(rolesS);
      });
    }
    getRoles();
  }, []);

  return (
    <CustomDialog button buttonChildren={<>Menu Cta</>} size="lg">
      <Grid container spacing={2}>
        <Grid item xs={3}>
          <ListA>
            <AltaCTA listItem />
          </ListA>
        </Grid>
        <Grid item xs={9}>
          {roles.map((role) => (
            <ChooseCTA key={role} locationId={locationId} role={role} />
          ))}
          {/* <ChooseCTA locationId={locationId} /> */}
        </Grid>
      </Grid>
    </CustomDialog>
  );
}
