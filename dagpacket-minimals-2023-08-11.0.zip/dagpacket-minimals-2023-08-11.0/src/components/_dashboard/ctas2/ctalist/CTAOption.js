import React, { useState, useEffect } from 'react';
import { MenuItem, Card, CardContent, CardHeader } from '@mui/material';
import FloatMenu from '../FloatMenu';
import CTASub from './CTASub';

import { firestore } from '../../../../contexts/FirebaseContext';

export default function CTAOption({ id, locationId }) {
  const [location, setLocation] = useState({});

  useEffect(() => {
    async function getLocation() {
      await firestore
        .collection('ctalocations')
        .doc(locationId)
        .onSnapshot((doc) => {
          if (doc.exists) {
            setLocation(doc.data());
          }
        });
    }
    getLocation();
  }, [locationId]);

  const setCTAShow = async (etapa, ctaId) => {
    const obj = {};
    obj[etapa] = ctaId;
    await firestore
      .collection('ctalocations')
      .doc(locationId)
      .get()
      .then((doc) => {
        if (doc.exists) {
          firestore.collection('ctalocations').doc(locationId).update(obj);
        } else {
          firestore.collection('ctalocations').doc(locationId).set(obj);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Card>
      <CardHeader
        action={
          <FloatMenu>
            {location.atraccion !== id && (
              <MenuItem onClick={() => setCTAShow('atraccion', id)}>Mostrar en Atracción</MenuItem>
            )}
            {location.atraccion === id && (
              <MenuItem onClick={() => setCTAShow('atraccion', null)}>Quitar de Atraccion</MenuItem>
            )}
            {location.interaccion !== id && (
              <MenuItem onClick={() => setCTAShow('interaccion', id)}>Mostrar en Interacción</MenuItem>
            )}
            {location.interaccion === id && (
              <MenuItem onClick={() => setCTAShow('interaccion', null)}>Quitar de Interacción</MenuItem>
            )}
            {location.deleite !== id && (
              <MenuItem onClick={() => setCTAShow('deleite', id)}>Mostrar en Deleite</MenuItem>
            )}
            {location.deleite === id && (
              <MenuItem onClick={() => setCTAShow('deleite', null)}>Quitar de Deleite</MenuItem>
            )}
          </FloatMenu>
        }
      />
      <CardContent>
        <CTASub id={id} />
      </CardContent>
    </Card>
  );
}
