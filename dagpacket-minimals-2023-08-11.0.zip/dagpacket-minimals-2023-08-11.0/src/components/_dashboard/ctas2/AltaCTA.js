import React, { useState, useCallback, useEffect } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Grid,
  Box,
  LinearProgress,
  Typography,
  FormControlLabel,
  RadioGroup,
  Radio,
  Switch,
  MenuItem,
  ListItemButton,
  ListItemText
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import { Form, useFormik, FormikProvider } from 'formik';
import * as yup from 'yup';
// firebase
import { storage as st, firestore } from '../../../contexts/FirebaseContext';

import { UploadSingleFile } from '../../upload';

import { fData, fPercent } from '../../../utils/formatNumber';
import { getURLFile } from '../../../utils/storagef';
import { v1 as uuidv1 } from 'uuid';
// icons
import { Icon } from '@iconify/react';
import editIcon from '@iconify/icons-eva/edit-outline';

import PropTypes from 'prop-types';

// options

const locationOptions = [{ value: '', label: 'Seleccione una opción' }];

// component

AltaCTA.propTypes = {
  edit: PropTypes.bool,
  iddoc: PropTypes.string,
  menuItem: PropTypes.bool,
  listItem: PropTypes.bool
};

export default function AltaCTA({ edit = false, iddoc, menuItem = false, listItem = false }) {
  const [open, setOpen] = useState(false);
  const [uuidS, setUUIDS] = useState('');
  const [file, setFile] = useState({ preview: '', file: null });
  const [pF, setPF] = useState(0);
  const [pData, setPData] = useState('');

  useEffect(() => {
    setUUIDS(uuidv1());
  }, []);

  const formik = useFormik({
    initialValues: {
      title: '',
      description: '',
      Urlmedia: '',
      etapa: 'atraccion',
      show: false,
      location: '',
      ubicacion: '',
      buttonText: ''
    },
    validationSchema: yup.object({
      title: yup.string().required('El título es obligatorio'),
      description: yup.string().required('La descripción es obligatoria'),
      urlMedia: yup.string()
    }),
    onSubmit: async (values, { setSubmitting, resetForm }) => {
      try {
        const data = values;
        setSubmitting(true);
        if (edit) {
          if (file.file !== null) {
            await uploadMedia();
            data.urlMedia = await getURLFile(`ctas/${iddoc}`);
          }
          if (data.urlMedia) {
            data.urlMedia = await getURLFile(`ctas/${iddoc}`);
          }
          await firestore
            .collection('ctas')
            .doc(iddoc)
            .update({ ...data });
        } else {
          if (file.file !== null) {
            await uploadMedia();
            data.urlMedia = await getURLFile(`ctas/${uuidS}`);
          }
          await firestore
            .collection('ctas')
            .doc(uuidS)
            .set({ ...data })
            .then(() => {
              setFile({ preview: '', file: null });
              setUUIDS(uuidv1());
              resetForm();
            });
        }
        setSubmitting(false);
      } catch (error) {
        console.error(error);
        setSubmitting(false);
      }
    }
  });

  const { errors, touched, handleSubmit, isSubmitting, getFieldProps, setFieldValue } = formik;

  const updateValues = useCallback(async () => {
    if (edit) {
      await firestore
        .collection('ctas')
        .doc(iddoc)
        .get()
        .then((doc) => {
          if (doc.exists) {
            const data = doc.data();
            Object.keys(data).forEach((key) => {
              setFieldValue(key, data[key]);
            });
          }
        })
        .catch((error) => {
          console.error(error);
        });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [edit, iddoc]);

  useEffect(() => {
    updateValues();
  }, [updateValues]);

  const clickClose = () => {
    setOpen(false);
  };

  const clickOpen = () => {
    setOpen(true);
  };

  const uploadMedia = useCallback(async () => {
    const refF = st.ref().child(`ctas/${iddoc || uuidS}`);
    await refF
      .delete()
      .then(() => {
        console.log('borrado');
      })
      .catch((err) => {
        console.error(err);
      });
    return new Promise((resolve) => {
      if (file.file !== null) {
        refF.put(file.file).on('next', (snapshot) => {
          const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setPF(percent);
          setPData(`${fData(snapshot.bytesTransferred)} / ${fData(snapshot.totalBytes)}  (${fPercent(percent)})`);
          if (percent === 100) {
            setTimeout(() => resolve(), 1500);
          }
        });
      } else {
        resolve();
      }
    });
  }, [uuidS, file, iddoc]);

  return (
    <>
      {listItem && (
        <ListItemButton onClick={clickOpen}>
          <ListItemText primary={edit ? 'Editar' : 'Alta de CTA'} />
        </ListItemButton>
      )}
      {menuItem && (
        <MenuItem onClick={clickOpen}>
          <Icon icon={editIcon} width={25} height={25} /> {edit ? 'Editar' : 'Nuevo'}
        </MenuItem>
      )}
      {!menuItem && !listItem && (
        <Button variant="contained" color="primary" onClick={clickOpen}>
          {edit ? 'Editar' : 'Agregar'}
        </Button>
      )}

      <Dialog open={open} onClose={clickClose} maxWidth="lg ">
        <Box sx={{ margin: '5px' }}>
          <DialogTitle>{edit ? 'Editar' : 'Agregar'} CTA</DialogTitle>
        </Box>
        <DialogContent>
          <FormikProvider value={formik}>
            <Form autoComplete="off" onSubmit={handleSubmit}>
              <Grid container spacing={2}>
                <Grid item xs={9}>
                  <Grid container spacing={1}>
                    <Grid item xs={12}>
                      <TextField
                        label="Título"
                        name="title"
                        {...getFieldProps('title')}
                        error={Boolean(errors.title) && Boolean(touched.title)}
                        helperText={errors.title && touched.title}
                        fullWidth
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        label="Descripción"
                        name="description"
                        multiline
                        rows={4}
                        {...getFieldProps('description')}
                        error={Boolean(errors.description) && Boolean(touched.description)}
                        helperText={errors.description && touched.description}
                        fullWidth
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <Typography>Multimedia</Typography>
                      <UploadSingleFile
                        file={file}
                        accept={'image/*'}
                        onDrop={(filec) => {
                          setPData(`${fData(filec[0].size)}`);
                          setFile({
                            file: filec[0],
                            preview: URL.createObjectURL(filec[0])
                          });
                        }}
                      />
                      <Box>
                        <LinearProgress variant="determinate" value={pF} />
                        {pData}
                      </Box>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={3}>
                  <Typography variant="h4">Mas opciones</Typography>
                  <Grid container spacing={1}>
                    <Grid item xs={6}>
                      <FormControlLabel control={<Switch />} {...getFieldProps('show')} label="Mostrar CTA" />
                    </Grid>
                    <Grid item xs={6}>
                      <Typography variant="h5">Etapa</Typography>
                      <RadioGroup {...getFieldProps('etapa')}>
                        <FormControlLabel control={<Radio />} value="atraccion" label="atraccion" />
                        <FormControlLabel control={<Radio />} value="interactuar" label="interactuar" />
                        <FormControlLabel control={<Radio />} value="deleite" label="deleite" />
                      </RadioGroup>
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        label="Texto del Boton"
                        {...getFieldProps('buttonText')}
                        error={Boolean(errors.buttonText) && Boolean(touched.buttonText)}
                        helperText={errors.buttonText && touched.buttonText}
                        fullWidth
                      />
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={12}>
                  <LoadingButton variant="contained" color="primary" loading={isSubmitting} type="submit" fullWidth>
                    {edit ? 'Guardar Cambios' : 'Agregar'}
                  </LoadingButton>
                </Grid>
              </Grid>
            </Form>
          </FormikProvider>
        </DialogContent>
      </Dialog>
    </>
  );
}
