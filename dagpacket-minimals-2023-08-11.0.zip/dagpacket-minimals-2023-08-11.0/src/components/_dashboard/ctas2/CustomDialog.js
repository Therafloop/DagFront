import React, { useState } from 'react';
import { MenuItem, Dialog, DialogContent, Button } from '@mui/material';
import PropTypes from 'prop-types';

CustomDialog.propTypes = {
  buttonChildren: PropTypes.node.isRequired,
  children: PropTypes.node.isRequired,
  size: PropTypes.oneOf(['sm', 'md', 'lg', 'xl', 'xs']),
  button: PropTypes.bool
};

export default function CustomDialog({ buttonChildren, children, size, button }) {
  const [open, setOpen] = useState(false);

  const clickOpen = () => {
    setOpen(true);
  };

  const clickClose = () => {
    setOpen(false);
  };

  return (
    <>
      {button && (
        <Button variant="contained" color="primary" onClick={clickOpen}>
          {buttonChildren}
        </Button>
      )}
      {!button && <MenuItem onClick={clickOpen}>{buttonChildren}</MenuItem>}
      <Dialog open={open} onClose={clickClose} maxWidth={size}>
        <DialogContent>{children}</DialogContent>
      </Dialog>
    </>
  );
}
