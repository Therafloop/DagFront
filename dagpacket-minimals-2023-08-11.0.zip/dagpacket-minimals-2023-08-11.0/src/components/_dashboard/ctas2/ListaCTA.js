import React, { useState, useEffect } from 'react';
import { TableContainer, TableBody, TableHead, TableCell, TableRow } from '@mui/material';
import CTAElement from './CTARow';
import { firestore } from '../../../contexts/FirebaseContext';

export default function ListaCTA() {
  const [ctas, setCTAs] = useState([]);

  useEffect(() => {
    async function getCTAs() {
      await firestore.collection('ctas').onSnapshot((queryS) => {
        const ctasS = queryS.docs.map((doc) => ({ ...doc.data(), id: doc.id }));
        setCTAs(ctasS);
      });
    }
    getCTAs();
  }, []);

  return (
    <TableContainer>
      <TableHead>
        <TableRow>
          <TableCell />
          <TableCell>Título</TableCell>
          <TableCell>Descripción</TableCell>
          <TableCell>Imagen</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {ctas.map((cta) => (
          <CTAElement key={cta.id} info={cta} />
        ))}
      </TableBody>
    </TableContainer>
  );
}
