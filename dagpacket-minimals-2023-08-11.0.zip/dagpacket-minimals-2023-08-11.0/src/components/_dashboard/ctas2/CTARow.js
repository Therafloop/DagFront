import React from 'react';
import { TableRow, TableCell } from '@mui/material';
import AltaCTA from './AltaCTA';
import FloatMenu from './FloatMenu';
import CustomDialog from './CustomDialog';
import CTA from './ctalist/CtaWithCoverImage';
// icons
import { Icon } from '@iconify/react';
import eyeIcon from '@iconify/icons-eva/eye-fill';

import PropTypes from 'prop-types';

CTARow.propTypes = {
  info: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    urlMedia: PropTypes.string.isRequired
  })
};

export default function CTARow({ info }) {
  const { id, title, description, urlMedia } = info;

  return (
    <TableRow>
      <TableCell>
        <FloatMenu
          options={[
            <AltaCTA key={id} edit iddoc={id} menuItem />,
            <CustomDialog
              key={`${id}-preview`}
              size="md"
              buttonChildren={
                <>
                  <Icon icon={eyeIcon} width={25} height={25} /> Vista previa
                </>
              }
            >
              <CTA info={info} />
            </CustomDialog>
          ]}
        />
      </TableCell>
      <TableCell>{title}</TableCell>
      <TableCell>{description}</TableCell>
      <TableCell>
        <img src={urlMedia} alt={title} />
      </TableCell>
    </TableRow>
  );
}
