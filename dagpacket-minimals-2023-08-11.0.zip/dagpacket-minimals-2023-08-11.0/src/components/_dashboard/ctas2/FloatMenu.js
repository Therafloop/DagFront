import React, { useRef, useState } from 'react';
import { IconButton, Menu } from '@mui/material';
// icons
import { Icon } from '@iconify/react';
import moreVerticalIcon from '@iconify/icons-eva/more-vertical-fill';

import PropTypes from 'prop-types';

FloatMenu.propTypes = {
  options: PropTypes.arrayOf(PropTypes.node.isRequired),
  children: PropTypes.node
};

export default function FloatMenu({ options = [], children }) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef(null);

  const clickOpen = () => {
    setOpen(true);
  };

  const clickClose = () => {
    setOpen(false);
  };

  return (
    <>
      <IconButton ref={anchorRef} onClick={clickOpen}>
        <Icon icon={moreVerticalIcon} width={25} height={25} />
      </IconButton>
      <Menu id="simple-menu" anchorEl={anchorRef.current} open={open} onClose={clickClose}>
        {options}
        {children}
      </Menu>
    </>
  );
}
