import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { Icon } from '@iconify/react';
import { firestore } from '../../../../contexts/FirebaseContext';
import { LoadingButton } from '@mui/lab';
import { useSelector } from 'react-redux';
import CardUbicacion from './CardUbicacion';
import { cotizarEnvioVencedor } from '../../../../_apis_/dagpacket-oneRequest';

export default function DialogVencedor({ openDialog, setOpenDialog, cotizarEnvioFunction }) {
  return (
    <>
      {/* <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Abrir dialogo
      </Button> */}
      {/* <IconButton size="small" color="info" onClick={() => setOpenDialog(true)}>
        <Icon icon="eva:more-vertical-fill" />
      </IconButton> */}
      {/* {vencedorValue && ( */}
      <DialogBody open={openDialog} onClose={setOpenDialog} cotizarEnvioFunction={cotizarEnvioFunction} />
      {/* )} */}
    </>
  );
}

function DialogBody({ open, onClose, cotizarEnvioFunction }) {
  const [loading, setLoading] = useState();
  const { coloniasVnecedor } = useSelector((state) => state.dagpacketVencedor);
  console.log(coloniasVnecedor);

  const handleClose = async () => {
    setLoading(true);
    try {
      await cotizarEnvioFunction();
      setLoading(false);
    } catch (error) {
      setLoading(false);
    }
    onClose(false);
  };

  // const handleCotizar = async () => {
  //   setLoading(true);
  //   const obj = {};

  //   try {
  //     await cotizarEnvioVencedor();
  //     setLoading(false);
  //   } catch (error) {
  //     setLoading(false);
  //   }
  // };

  return (
    <Dialog
      open={open}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Typography textAlign="center" variant="h5">
          ¿Quieres cotizar con Vencedor? Elije la colonia de origen y destino
        </Typography>

        <Grid marginTop="15px" container spacing={2}>
          <Grid item xs={6}>
            <Typography gutterBottom textAlign="center" variant="subtitle1">
              Origen
            </Typography>
            {coloniasVnecedor?.resFrom?.map((item, i) => (
              <CardUbicacion key={i} dataItem={item} ubicacion="origen" />
            ))}
          </Grid>
          <Grid item xs={6}>
            <Typography gutterBottom textAlign="center" variant="subtitle1">
              Destino
            </Typography>
            {coloniasVnecedor?.resTo?.map((item, i) => (
              <CardUbicacion key={i} dataItem={item} ubicacion="destino" />
            ))}
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        {/* <LoadingButton fullWidth variant="contained" loading={loading} onClick={handleCotizar}>
          Cotizar vencedor
        </LoadingButton> */}
        <LoadingButton
          fullWidth
          loading={loading}
          onClick={handleClose}
          color="primary"
          variant="contained"
          size="large"
        >
          Continuar
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}
