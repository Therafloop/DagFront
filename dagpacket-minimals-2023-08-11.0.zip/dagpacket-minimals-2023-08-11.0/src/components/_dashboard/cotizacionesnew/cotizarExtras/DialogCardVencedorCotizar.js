import React, { useState } from 'react';
import {
  Button,
  Card,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  Typography,
  styled
} from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { Icon } from '@iconify/react';
import PaqueteriaAvatar from '../../paquetes/general/PaqueteriaAvatar';
import { useDispatch, useSelector } from 'react-redux';
import CardUbicacion from './CardUbicacion';
import { LoadingButton } from '@mui/lab';
import { cotizarEnvioVencedor } from '../../../../_apis_/dagpacket-oneRequest';
import { useLocation } from 'react-router';
import { TarifaCard } from '../ListaTarifas';
import useTarifasEnvios from '../../../../hooks/envios/useTarifasEnvios';
import { setResultTarifaVencedor } from '../../../../redux/slices/dagpacketVencedor';
import { rolesConfPermissions } from '../../../../constants/rolesConfPermissions';

const CuztomCard = styled(Card)(({ pointer }) => ({
  padding: '10px',
  display: 'flex',
  justifyContent: 'space-evenly',
  gap: '15px',
  alignItems: 'center',
  cursor: 'pointer',
  height: '100%'
}));

export default function DialogCardVencedorCotizar() {
  const [openDialog, setOpenDialog] = useState(false);
  const { resultTarifaVencedor } = useSelector((state) => state.dagpacketVencedor);
  const settingId = rolesConfPermissions.cotizacionConfSetting;

  console.log(resultTarifaVencedor);

  return (
    <>
      {resultTarifaVencedor && <TarifaCard tarifa={resultTarifaVencedor} settingId={settingId} active />}

      {!resultTarifaVencedor && (
        <CuztomCard onClick={() => setOpenDialog(true)}>
          <PaqueteriaAvatar rate_provider="vencedor" />
          <Box>
            <Typography variant="subtitle1">Cotizar con Vencedor</Typography>
          </Box>
        </CuztomCard>
      )}
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </>
  );
}

function DialogBody({ open, onClose }) {
  const [loading, setLoading] = useState();
  const { coloniasVnecedor, coloniaOrigenVencedor, coloniaDestinoVencedor, shipping_type } = useSelector(
    (state) => state.dagpacketVencedor
  );
  const { tarifasTotal } = useSelector((state) => state.dagpacket);
  const { formatEnvioTarifas } = useTarifasEnvios();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);

  const dispatch = useDispatch();

  const handleClose = () => {
    onClose(false);
  };

  const handleCotizar = async () => {
    setLoading(true);
    const obj = {
      object_type: 'QUOTE',
      zipcode_from: queryParams.get('zipcode_from'),
      zipcode_to: queryParams.get('zipcode_to'),
      declared_value: Number(queryParams.get('declared_value')),
      weight: Number(queryParams.get('weight')),
      length: Number(queryParams.get('length')),
      height: Number(queryParams.get('height')),
      width: Number(queryParams.get('width')),
      qty: 1,
      description: queryParams.get('description'),
      country_code_from: 'MX',
      country_code_to: 'MX',
      shipping_type,
      colonia_from: coloniaOrigenVencedor ? coloniaOrigenVencedor?.D_Colonia : '',
      colonia_to: coloniaDestinoVencedor ? coloniaDestinoVencedor?.D_Colonia : ''
    };

    try {
      const res = await cotizarEnvioVencedor(obj);

      // aqui agregamos las ciudades de origen y destino
      const newRes = {
        ...res,
        city_from: tarifasTotal[0].city_from,
        city_to: tarifasTotal[0].city_to
      };

      console.log(res);
      const tarifaVencedor = formatEnvioTarifas(newRes)[0];

      console.log(tarifaVencedor, '===================');
      dispatch(setResultTarifaVencedor(tarifaVencedor));

      setLoading(false);
      handleClose();
    } catch (error) {
      setLoading(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title">Cotizar con Vencedor</DialogTitle>
      <DialogContent>
        <Grid marginTop="15px" container spacing={2}>
          <Grid item xs={6}>
            <Typography gutterBottom textAlign="center" variant="subtitle1">
              Origen
            </Typography>
            {coloniasVnecedor?.resFrom?.map((item, i) => (
              <CardUbicacion key={i} dataItem={item} ubicacion="origen" />
            ))}
          </Grid>
          <Grid item xs={6}>
            <Typography gutterBottom textAlign="center" variant="subtitle1">
              Destino
            </Typography>
            {coloniasVnecedor?.resTo?.map((item, i) => (
              <CardUbicacion key={i} dataItem={item} ubicacion="destino" />
            ))}
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <LoadingButton fullWidth variant="contained" loading={loading} onClick={handleCotizar}>
          Cotizar vencedor
        </LoadingButton>
        {/* <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button> */}
      </DialogActions>
    </Dialog>
  );
}
