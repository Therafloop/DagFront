import React from 'react';
import { Box, Card, IconButton, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { Icon } from '@iconify/react';
import { setColiniaDestinoVencedor, setColiniaOrigenVencedor } from '../../../../redux/slices/dagpacketVencedor';

function CardUbicacion({ dataItem, ubicacion = 'origen' }) {
  const { coloniaOrigenVencedor, coloniaDestinoVencedor } = useSelector((state) => state.dagpacketVencedor);
  const dispatch = useDispatch();
  const { Codigo_Postal, D_Ciudad, D_Colonia, D_Estado, D_Pais } = dataItem;

  const handleUbication = () => {
    if (ubicacion === 'origen') {
      dispatch(setColiniaOrigenVencedor(dataItem));
    }
    if (ubicacion === 'destino') {
      dispatch(setColiniaDestinoVencedor(dataItem));
    }
  };

  //   const verifyNoSelected = () => {
  //     if (ubicacion === 'origen' && coloniaOrigenVencedor?.ID === dataItem?.ID) {
  //       dispatch(setColiniaOrigenVencedor(dataItem));
  //     }
  //   };

  return (
    <Card sx={{ padding: '15px', marginBottom: '10px', display: 'flex', gap: '15px', justifyContent: 'space-between' }}>
      <Box>
        <Typography>
          {D_Estado} - {D_Ciudad} - {D_Colonia}
        </Typography>
        <Typography>Codigo postal: {Codigo_Postal}</Typography>
      </Box>
      <Box>
        {ubicacion === 'origen' && (
          <>
            {coloniaOrigenVencedor?.ID !== dataItem?.ID && (
              <IconButton onClick={handleUbication}>
                <Icon icon="material-symbols:circle-outline" />
              </IconButton>
            )}

            {coloniaOrigenVencedor?.ID === dataItem?.ID && (
              <IconButton onClick={handleUbication}>
                <Icon icon="material-symbols:check-circle" />
              </IconButton>
            )}
          </>
        )}
        {ubicacion === 'destino' && (
          <>
            {coloniaDestinoVencedor?.ID !== dataItem?.ID && (
              <IconButton onClick={handleUbication}>
                <Icon icon="material-symbols:circle-outline" />
              </IconButton>
            )}

            {coloniaDestinoVencedor?.ID === dataItem?.ID && (
              <IconButton onClick={handleUbication}>
                <Icon icon="material-symbols:check-circle" />
              </IconButton>
            )}
          </>
        )}
      </Box>
    </Card>
  );
}

export default CardUbicacion;
