import { Autocomplete, TextField } from '@mui/material';
import React from 'react';
import { countriesUPS } from '../../../constants/upsAcceptedjson';

// const countriesUPS = [
//   {
//     label: 'Myanmar',
//     value: 'MM',
//     Supported_Forward_Origin: false,
//     Supported_Return_Origin: false
//   },
//   {
//     label: 'Namibia',
//     value: 'NA',
//     Supported_Forward_Origin: false,
//     Supported_Return_Origin: false
//   },
//   {
//     label: 'Nauru',
//     value: 'NR',
//     Supported_Forward_Origin: false,
//     Supported_Return_Origin: false
//   }
// ];

function SelectPais({ setCountryCodeTo }) {
  const [value, setValue] = React.useState({});
  // console.log('nuevo valorrrrrrrrrrr', value);
  //   const [inputValue, setInputValue] = React.useState('');
  const getValuePais = (obj) => {
    setCountryCodeTo(obj?.value);
  };

  return (
    <Autocomplete
      disablePortal
      id="combo-box-demo"
      options={countriesUPS}
      onChange={(event, newValue) => {
        setValue(newValue);
        getValuePais(newValue);
      }}
      //   sx={{ width: 300 }}
      renderInput={(params) => <TextField {...params} label="Pais destino" />}
    />
  );
}

export default SelectPais;
