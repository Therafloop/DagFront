import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
// mui
// import { styled } from '@mui/material/styles';
import { TableRow, TableCell, Button } from '@mui/material';
import { fCurrency } from '../../../utils/formatNumber';
import { analytics } from '../../../contexts/FirebaseContext';
import PropTypes from 'prop-types';
import { analyticsEvents } from '../../../constants/analyticsEvents';

// const ThumbImgStyle = styled('img')(({ theme }) => ({
//   width: 64,
//   height: 64,
//   objectFit: 'cover',
//   margin: theme.spacing(0, 2),
//   borderRadius: theme.shape.borderRadiusSm
// }));

function convertHourToDay(hour) {
  const number = Number(hour);
  return Math.ceil(number / 24);
}

TarifaItem.propTypes = {
  tarifa: PropTypes.object,
  tarifaRed: PropTypes.object,
  showSelect: PropTypes.bool,
  redpack: PropTypes.bool
};

export default function TarifaItem({ tarifa, tarifaRed, showSelect = false, redpack = false }) {
  const navigate = useNavigate();
  const { search } = useLocation();
  // const { amount, days, servicelevel, provider, object_id } = tarifa;
  return (
    <>
      {redpack === false ? (
        <TableRow>
          <TableCell>{tarifa.provider}</TableCell>
          <TableCell>{fCurrency(tarifa.amount)}</TableCell>
          <TableCell>{tarifa.days} Días</TableCell>
          <TableCell>{tarifa.servicelevel}</TableCell>
          <TableCell>
            {showSelect && (
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  analytics.logEvent(analyticsEvents.checkout_progress, {
                    object_id: tarifa.object_id,
                    provider: tarifa.provider,
                    value: tarifa.amount,
                    days: tarifa.days,
                    servicelevel: tarifa.servicelevel,
                    currency: 'MXN',
                    checkout_step: 'quote_choosen'
                  });
                  const params = `${search}&cot_id=${tarifa.object_id}&shippingValue=${tarifa.amount}`;
                  navigate(`/dashboard/cotizaciones/nuevoenvio${params}`);
                }}
              >
                Seleccionar
              </Button>
            )}
          </TableCell>
        </TableRow>
      ) : (
        <TableRow>
          <TableCell>Redpack</TableCell>
          <TableCell>{fCurrency(tarifaRed.rate)}</TableCell>
          <TableCell>{convertHourToDay(tarifaRed.deliveryTime)} Días</TableCell>
          <TableCell>{tarifaRed.serviceType.serviceType}</TableCell>
          <TableCell>
            {showSelect && (
              <Button
                variant="contained"
                color="primary"
                onClick={() => {
                  const params = `${search}&cot_id=${new Date().getTime()}&shippingValue=${tarifaRed.rate}`;
                  navigate(`/dashboard/cotizaciones/nuevoenvio${params}`);
                }}
              >
                Seleccionar
              </Button>
            )}
          </TableCell>
        </TableRow>
      )}
    </>
  );
}
