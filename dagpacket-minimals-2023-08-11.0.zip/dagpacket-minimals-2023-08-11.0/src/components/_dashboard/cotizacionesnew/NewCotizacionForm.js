import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
// mui
import {
  Card,
  CardContent,
  TextField,
  Grid,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Alert,
  Box,
  Button,
  Select,
  MenuItem,
  Autocomplete,
  Chip,
  InputAdornment,
  Typography
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import { Form, FormikProvider, useFormik } from 'formik';
import * as yup from 'yup';
// redux
import { useDispatch } from '../../../redux/store';
import {
  getTarifasTotalAction,
  resetTarifasTotalAction,
  setCotTarifasError,
  setErrorCotizacion,
  setShowTarifa,
  setTarifas,
  setTarifasRedpack
} from '../../../redux/slices/dagpacket';
// eslint-disable-next-line no-unused-vars
import {
  hacerCotizacion,
  hacerCotizacionRed,
  getTarifas,
  cotizacionUPS,
  cotizacionSuperEnvio
} from '../../../_apis_/dagpacket';
// firebase
// import useAuth from '../../../hooks/useAuth';
import { analytics } from '../../../contexts/FirebaseContext';
// hooks
import { orderBy } from 'lodash';
import { fCapitalize } from '../../../utils/formatText';
import { getPaqueteriaImg } from '../../../utils/getPaquteriaImg';
import DialogAsegurarEnvio from './DialogAsegurarEnvio';

import DialogEnvInternacional from './DialogEnvInternacional';

import useAuth from '../../../hooks/useAuth';
import { generateSingleUseToken } from '../../../_apis_/tokengen';
import { cotizarEnvio } from '../../../_apis_/dagpacket-oneRequest';
import { fProvider } from '../../../utils/formatPaqueteria';
import SelectPais from './SelectPais';
import { countriesUPS } from '../../../constants/upsAcceptedjson';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../constants/ticketsErrors';
import useReportError from '../../../hooks/errorsHooks/useReportError';
import DialogEmpaquetado from './empaquetado/DialogEmpaquetado';
import { useSelector } from 'react-redux';
import useTarifasEnvios from '../../../hooks/envios/useTarifasEnvios';
import useCotizarEnvio from '../../../hooks/envios/useCotizarEnvio';
import DialogVencedor from './cotizarExtras/DialogVencedor';
import {
  resetColoniasVencedor,
  resetColoniasVencedorOrigeDestino,
  resetFlujoVencedor,
  setColoniasVencedor,
  setShippingType
} from '../../../redux/slices/dagpacketVencedor';
import { analyticsEvents } from '../../../constants/analyticsEvents';

export default function NewCotizacionForm() {
  const [actionValue, setActionValue] = useState('vencedor');
  const dispatch = useDispatch();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { search } = useLocation();
  const queryParams = new URLSearchParams(search);
  const { reportError } = useReportError();

  const [tipoP, setTipoP] = useState('sobre');
  const [tipoDestino, setTipoDestino] = useState('nacional');
  const [seguro, setSeguro] = useState('no_asegurado');
  // eslint-disable-next-line
  const [submited, setSubmited] = useState(false);

  const [openDialogVencedor, setOpenDialogVencedor] = useState(false);

  const [newValuesState, setNewValuesState] = useState(null);

  const [countryCodeFrom, setCountryCodeFrom] = useState('MX');
  const { empaqTipoEnvio, useEmpaquetado, empaqResume, total } = useSelector((state) => state.dagpacketEmpaquetado);
  const { coloniaOrigenVencedor, coloniaDestinoVencedor } = useSelector((state) => state.dagpacketVencedor);
  // const [countryCodeTo, setCountryCodeTo] = useState(null);

  const { formatEnvioTarifas } = useTarifasEnvios();
  const { getColsVencedor } = useCotizarEnvio();

  const { proveedoresPublico } = useSelector((state) => state.dagpacketControlPaq);

  console.log(proveedoresPublico);

  const vencedor = proveedoresPublico?.find((item) => item.id === 'VENCEDOR');
  const vencedorValue = vencedor?.rate_providers[0].active;

  console.log(vencedor);

  // console.log('codigo de pais destino', countryCodeTo);

  // // ========================
  // const [city_from, setCity_from] = useState('');
  // const [city_to, setCity_to] = useState('');

  // // ====================================

  const codPaisOrig = queryParams.get('origCountry');
  const codPaisDesti = queryParams.get('destiCountry');

  const cotizacionSchema = yup.object().shape({
    zipcode_from: yup.string().min(5).max(5).required('Requerido'),
    zipcode_to: yup
      .string()
      .min(tipoDestino === 'nacional' ? 5 : 4)
      .max(tipoDestino === 'nacional' ? 5 : 7)
      .required('Requerido'),
    weight: yup
      .number()
      .integer('El peso debe ser entero')
      .min(1, 'El peso debe ser mayor a 1kg')
      .required('Requerido'),
    // weight:
    //   tipoP === 'sobre'
    //     ? yup.number().min(0.1).required('Requerido')
    //     : yup.number().integer('El peso debe ser entero').min(1).required('Requerido'),
    length: yup
      .number()
      .min(10, 'El largo mínimo debe ser mayor a 10 cm')
      .integer('El largo debe ser un entero')
      .required('Requerido'),
    height: yup.number().min(1, 'Ingrese la altura').integer('La altura debe ser un entero').required('Requerido'),
    width: yup.number().min(1, 'Ingrese el ancho').integer('El ancho debe ser entero').required('Requerido'),
    // country_code_from: yup.string().required('Requerido'),
    // country_code_to: yup.string().required('Requerido'),
    declared_value: yup.string().required('Requerido'),
    description: yup.string().max(30, '30 caracteres como maximo').required('Este campo es requerido')
  });

  // =====================================funcion que cotizara sin vencedor (se copio de lo que esta comentado en el else) ======================
  const cotizarSinVencedor = async (newValues) => {
    try {
      const res = await cotizarEnvio(newValues);
      console.log(res);

      // funcion para formatear las tarifas del hook useTarifasEnvios
      const tarifasResult = formatEnvioTarifas(res);

      dispatch(getTarifasTotalAction(tarifasResult));
    } catch (error) {
      const errorData = {
        error: JSON.stringify(error),
        errorAction: actionSectionIdentifier.hacerCotizacion,
        section: sectionIdentifier.cotizacionSection,
        statusError: statusAction.pending,
        created_at: new Date(),
        updated_at: new Date(),
        description: 'Error al hacer la cotizacion',
        versionApp: localStorage.getItem('versionApp'),
        user_id: user.id
      };
      console.log(errorData);

      await reportError(errorData);
      console.error(error);
      dispatch(setCotTarifasError(true));
    }

    const {
      zipcode_from,
      zipcode_to,
      weight,
      height,
      width,
      length,
      declared_value,
      country_code_from,
      country_code_to,
      description
    } = values;

    // const dec_val = seguro === 'no_asegurado' ? 0 : declared_value;

    navigate(
      `/dashboard/cotizaciones/new?zipcode_from=${zipcode_from}&zipcode_to=${zipcode_to}&weight=${weight}&height=${height}&width=${width}&length=${length}&tipoP=${tipoP}&tipoDestino=${tipoDestino}&country_code_from=${country_code_from}&country_code_to=${newValues.country_code_to}&declared_value=${declared_value}&seguro=${seguro}&description=${description}`
    );
    dispatch(setShowTarifa(true));
  };

  // ==================================================================================

  // ============================= la funcion que se encarga de cotizar vencedor ===============================
  const cotizarEnvioFunction = async (newValues) => {
    const valuesToCotizar = newValues
      ? {
          ...newValues
        }
      : {
          ...newValuesState,
          colonia_from: coloniaOrigenVencedor ? coloniaOrigenVencedor?.D_Colonia : '',
          colonia_to: coloniaDestinoVencedor ? coloniaDestinoVencedor?.D_Colonia : ''
        };
    console.log('----------------------------', valuesToCotizar);
    try {
      const res = await cotizarEnvio(valuesToCotizar);
      console.log(res);

      // funcion para formatear las tarifas del hook useTarifasEnvios
      const tarifasResult = formatEnvioTarifas(res);

      dispatch(getTarifasTotalAction(tarifasResult));
    } catch (error) {
      const errorData = {
        error: JSON.stringify(error),
        errorAction: actionSectionIdentifier.hacerCotizacion,
        section: sectionIdentifier.cotizacionSection,
        statusError: statusAction.pending,
        created_at: new Date(),
        updated_at: new Date(),
        description: 'Error al hacer la cotizacion',
        versionApp: localStorage.getItem('versionApp'),
        user_id: user.id
      };
      console.log(errorData);

      await reportError(errorData);
      const timestamp = new Date();
      dispatch(setErrorCotizacion({ timestamp, errorResponse: error.response.data }));
      console.error(error);
      console.error(error.response);
      dispatch(setCotTarifasError(true));
    }
    // =======================================

    const {
      zipcode_from,
      zipcode_to,
      weight,
      height,
      width,
      length,
      declared_value,
      country_code_from,
      country_code_to,
      description
    } = values;

    // const dec_val = seguro === 'no_asegurado' ? 0 : declared_value;

    navigate(
      `/dashboard/cotizaciones/new?zipcode_from=${zipcode_from}&zipcode_to=${zipcode_to}&weight=${weight}&height=${height}&width=${width}&length=${length}&tipoP=${tipoP}&tipoDestino=${tipoDestino}&country_code_from=${country_code_from}&country_code_to=${valuesToCotizar.country_code_to}&declared_value=${declared_value}&seguro=${seguro}&description=${description}`
    );
    dispatch(setShowTarifa(true));
  };

  // ============================ aqui termina la funcion ========================

  const formik = useFormik({
    initialValues: {
      object_type: 'QUOTE',
      zipcode_from: '',
      zipcode_to: '',
      declared_value: 0,
      weight: 1,
      length: 20,
      height: 1,
      width: 10,
      qty: 1,
      description: '',
      country_code_from: 'MX',
      country_code_to: ''
    },
    validationSchema: cotizacionSchema,
    onSubmit: async (values, { setSubmitting }) => {
      // const tipoEnvio = values.weight === 1 && values.length === 20 && values.height === 1 && values.width === 10;
      const tipoEnvio = tipoP === 'sobre' ? 1 : 2;
      // if (values.zipcode_from === values.zipcode_to) {
      //   alert('los codigos zip son iguales');
      // }
      analytics.logEvent(analyticsEvents.begin_checkout);

      // este dispatch se encarga de enviar el shipping_type al slice de vencedor y saber que tipo de envio es
      dispatch(setShippingType(tipoEnvio));

      dispatch(setShowTarifa(false));
      dispatch(resetTarifasTotalAction());
      dispatch(setCotTarifasError(false));

      // dispatch(resetColoniasVencedor());
      // dispatch(resetColoniasVencedorOrigeDestino());
      dispatch(resetFlujoVencedor());

      // console.log('values-----', values);
      if (!values.country_code_to) {
        alert('Ingrese el pais de destino');
        throw new Error('El pais de destino esta vacio');
      }

      const newValues = {
        ...values,
        shipping_type: tipoEnvio,
        country_code_to: tipoDestino === 'nacional' ? 'MX' : values.country_code_to.value
      };

      console.log('values-----', newValues);

      // ============== la nueva forma de hacer la cotizacion ===========
      try {
        const response = await getColsVencedor(newValues.zipcode_from, newValues.zipcode_to);
        dispatch(setColoniasVencedor(response));
        // setOpenDialogVencedor(true);

        // ====seguir cotizando
        // await cotizarEnvioFunction(newValues);
        // ===
        console.log(response);
      } catch (error) {
        console.log(error);
        // si falla la peticion a las colonias de vencedor hace la cotizacion sin vencedor

        // await cotizarEnvioFunction(newValues);
      }
      await cotizarEnvioFunction(newValues);

      // =========================================

      // // funcion para enviar los newValue A un usestate ========================
      // // con esto podemos ver si vencedor esta disponible en estos lugares =========================
      // setNewValuesState(newValues);

      // if (actionValue === 'vencedor') {
      //   console.log('cotizacion vencedor ========================');
      //   if (vencedorValue) {
      //     try {
      //       const response = await getColsVencedor(newValues.zipcode_from, newValues.zipcode_to);
      //       dispatch(setColoniasVencedor(response));
      //       setOpenDialogVencedor(true);

      //       // // ====seguir cotizando
      //       // await cotizarEnvioFunction(newValues);
      //       // // ===
      //       console.log(response);
      //     } catch (error) {
      //       console.log(error);
      //       // si falla la peticion a las colonias de vencedor hace la cotizacion sin vencedor

      //       await cotizarEnvioFunction(newValues);
      //     }
      //   } else {
      //     // await cotizarSinVencedor();
      //     // ========================================================
      //     try {
      //       const res = await cotizarEnvio(newValues);
      //       console.log(res);
      //       // funcion para formatear las tarifas del hook useTarifasEnvios
      //       const tarifasResult = formatEnvioTarifas(res);
      //       dispatch(getTarifasTotalAction(tarifasResult));
      //     } catch (error) {
      //       const errorData = {
      //         error: JSON.stringify(error),
      //         errorAction: actionSectionIdentifier.hacerCotizacion,
      //         section: sectionIdentifier.cotizacionSection,
      //         statusError: statusAction.pending,
      //         created_at: new Date(),
      //         updated_at: new Date(),
      //         description: 'Error al hacer la cotizacion',
      //         versionApp: localStorage.getItem('versionApp'),
      //         user_id: user.id
      //       };
      //       console.log(errorData);
      //       await reportError(errorData);
      //       console.error(error);
      //       dispatch(setCotTarifasError(true));
      //     }
      //     const {
      //       zipcode_from,
      //       zipcode_to,
      //       weight,
      //       height,
      //       width,
      //       length,
      //       declared_value,
      //       country_code_from,
      //       country_code_to,
      //       description
      //     } = values;
      //     // const dec_val = seguro === 'no_asegurado' ? 0 : declared_value;
      //     navigate(
      //       `/dashboard/cotizaciones/new?zipcode_from=${zipcode_from}&zipcode_to=${zipcode_to}&weight=${weight}&height=${height}&width=${width}&length=${length}&tipoP=${tipoP}&tipoDestino=${tipoDestino}&country_code_from=${country_code_from}&country_code_to=${newValues.country_code_to}&declared_value=${declared_value}&seguro=${seguro}&description=${description}`
      //     );
      //     dispatch(setShowTarifa(true));
      //   }
      // }

      // if (actionValue === 'no_vencedor') {
      //   console.log('cotizacion normal ========================');
      //   try {
      //     const res = await cotizarEnvio(newValues);
      //     console.log(res);
      //     // funcion para formatear las tarifas del hook useTarifasEnvios
      //     const tarifasResult = formatEnvioTarifas(res);
      //     dispatch(getTarifasTotalAction(tarifasResult));
      //   } catch (error) {
      //     const errorData = {
      //       error: JSON.stringify(error),
      //       errorAction: actionSectionIdentifier.hacerCotizacion,
      //       section: sectionIdentifier.cotizacionSection,
      //       statusError: statusAction.pending,
      //       created_at: new Date(),
      //       updated_at: new Date(),
      //       description: 'Error al hacer la cotizacion',
      //       versionApp: localStorage.getItem('versionApp'),
      //       user_id: user.id
      //     };
      //     console.log(errorData);
      //     await reportError(errorData);
      //     console.error(error);
      //     dispatch(setCotTarifasError(true));
      //   }
      //   const {
      //     zipcode_from,
      //     zipcode_to,
      //     weight,
      //     height,
      //     width,
      //     length,
      //     declared_value,
      //     country_code_from,
      //     country_code_to,
      //     description
      //   } = values;
      //   // const dec_val = seguro === 'no_asegurado' ? 0 : declared_value;
      //   navigate(
      //     `/dashboard/cotizaciones/new?zipcode_from=${zipcode_from}&zipcode_to=${zipcode_to}&weight=${weight}&height=${height}&width=${width}&length=${length}&tipoP=${tipoP}&tipoDestino=${tipoDestino}&country_code_from=${country_code_from}&country_code_to=${newValues.country_code_to}&declared_value=${declared_value}&seguro=${seguro}&description=${description}`
      //   );
      //   dispatch(setShowTarifa(true));
      // }
    }
  });

  const { errors, touched, isSubmitting, getFieldProps, handleSubmit, setFieldValue, values } = formik;
  useEffect(() => {
    if (tipoDestino === 'nacional') {
      setFieldValue('country_code_to', 'MX');
    } else {
      setFieldValue('country_code_to', '');
    }
  }, [setFieldValue, tipoDestino]);

  const cotNationalEnv = () => {
    navigate('/dashboard/cotizaciones/new');
  };

  const resetTarifasHandle = useCallback(() => {
    dispatch(resetTarifasTotalAction());
  }, [dispatch]);

  useEffect(() => {
    const queryParams = new URLSearchParams(search);
    // zipcode_from
    if (queryParams.get('zipcode_from')) {
      setFieldValue('zipcode_from', queryParams.get('zipcode_from'));
    }
    // zipcode_to
    if (queryParams.get('zipcode_to')) {
      setFieldValue('zipcode_to', queryParams.get('zipcode_to'));
    }
  }, [search, setFieldValue]);

  useEffect(() => {
    resetTarifasHandle();
  }, [resetTarifasHandle]);

  useEffect(() => {
    if (tipoP === 'sobre') {
      setFieldValue('height', 1);
      setFieldValue('width', 10);
      setFieldValue('length', 20);
      setFieldValue('weight', 1);
    } else {
      setFieldValue('height', '');
      setFieldValue('width', '');
      setFieldValue('length', '');
      setFieldValue('weight', '');
    }
  }, [setFieldValue, tipoP]);

  useEffect(() => {
    if (empaqTipoEnvio && useEmpaquetado) {
      setTipoP(empaqTipoEnvio);
    }
  }, [empaqTipoEnvio, useEmpaquetado]);

  return (
    <Card>
      <DialogVencedor
        openDialog={openDialogVencedor}
        setOpenDialog={setOpenDialogVencedor}
        cotizarEnvioFunction={cotizarEnvioFunction}
      />
      <CardContent>
        <FormikProvider value={formik}>
          <Form noValidate autoComplete="on" onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              {/* ========================== */}

              <Grid item xs={12}>
                <FormControl
                  value={tipoDestino}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value === 'nacional') {
                      setFieldValue('country_code_from', 'MX');
                      setFieldValue('country_code_to', 'MX');
                    } else {
                      setFieldValue('country_code_from', 'MX');
                      setFieldValue('country_code_to', '');
                    }
                    setTipoDestino(value);
                  }}
                >
                  <FormLabel>Destino</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="nacional"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel value="nacional" control={<Radio />} label="Nacional" />
                    <FormControlLabel value="internacional" control={<Radio />} label="Internacional" />
                  </RadioGroup>
                </FormControl>
              </Grid>

              {/* ======================== */}

              {/* {tipoDestino === 'internacional' && (
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <TextField
                        label="Codigo pais de origen"
                        fullWidth
                        {...getFieldProps('country_code_from')}
                        error={Boolean(touched.country_code_from && errors.country_code_from)}
                        helperText={touched.country_code_from && errors.country_code_from}
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <TextField
                        label="Codigo pais de destino"
                        fullWidth
                        {...getFieldProps('country_code_to')}
                        error={Boolean(touched.country_code_to && errors.country_code_to)}
                        helperText={touched.country_code_to && errors.country_code_to}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              )} */}
              <Grid item container xs={tipoDestino === 'nacional' ? 12 : 9} spacing={2}>
                <Grid item xs={6}>
                  <TextField
                    label="C.P. origen"
                    fullWidth
                    {...getFieldProps('zipcode_from')}
                    error={Boolean(touched.zipcode_from && errors.zipcode_from)}
                    helperText={touched.zipcode_from && errors.zipcode_from}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="C.P. destino"
                    fullWidth
                    {...getFieldProps('zipcode_to')}
                    error={Boolean(touched.zipcode_to && errors.zipcode_to)}
                    helperText={touched.zipcode_to && errors.zipcode_to}
                  />
                </Grid>
              </Grid>
              {tipoDestino !== 'nacional' && (
                <Grid item xs={3}>
                  {/* <SelectPais setCountryCodeTo={setCountryCodeTo} /> */}
                  <Autocomplete
                    // multiple
                    // freeSolo
                    value={values.country_code_to}
                    onChange={(event, newValue) => {
                      setFieldValue('country_code_to', newValue);
                    }}
                    options={countriesUPS.map((option) => option)}
                    renderTags={(value, getTagProps) =>
                      value.map((option, index) => (
                        <Chip {...getTagProps({ index })} key={option} size="small" label={option} />
                      ))
                    }
                    renderInput={(params) => <TextField {...params} label="Pais destino" />}
                  />
                  {/* <TextField label="paises" fullWidth select>
                    {countriesUPS.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField> */}
                </Grid>
              )}

              <Grid item xs={12}>
                <FormControl
                  value={seguro}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value === 'no_asegurado') {
                      setFieldValue('declared_value', 0);
                    } else {
                      setFieldValue('declared_value', '');
                    }
                    setSeguro(value);
                  }}
                >
                  <FormLabel>Seguro</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="no_asegurado"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel value="no_asegurado" control={<Radio />} label="No asegurado" />
                    <FormControlLabel value="asegurado" control={<Radio />} label="Asegurar" />
                  </RadioGroup>
                </FormControl>
              </Grid>

              {seguro === 'asegurado' && (
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={6} md={6}>
                      <TextField
                        label="Valor declarado"
                        type="number"
                        fullWidth
                        InputProps={{
                          startAdornment: <InputAdornment position="start">$</InputAdornment>
                        }}
                        {...getFieldProps('declared_value')}
                        error={Boolean(touched.declared_value && errors.declared_value)}
                        helperText={touched.declared_value && errors.declared_value}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              )}
              {/* <Grid item xs={12}>
                <DialogAsegurarEnvio />
              </Grid> */}
              {!useEmpaquetado && (
                <Grid item xs={12}>
                  <FormControl>
                    <FormLabel>Tipo de envio</FormLabel>
                    <RadioGroup
                      row
                      aria-labelledby="demo-radio-buttons-group-label"
                      value={tipoP}
                      onChange={(e) => {
                        const { value } = e.target;

                        setTipoP(value);
                      }}
                      defaultValue={tipoP}
                      name="radio-buttons-group"
                    >
                      <FormControlLabel
                        disabled={empaqTipoEnvio && useEmpaquetado && true}
                        value="sobre"
                        control={<Radio />}
                        label="Sobre"
                      />
                      <FormControlLabel
                        disabled={empaqTipoEnvio && useEmpaquetado && true}
                        value="paquete"
                        control={<Radio />}
                        label="Paquete"
                      />
                    </RadioGroup>
                  </FormControl>
                </Grid>
              )}
              {tipoP === 'sobre' && (
                <Box padding="10px 15px">
                  <Alert severity="warning">
                    El sobre debe tener una medida maxima de un documento tamaño oficio y un peso maximo de 1kg.
                  </Alert>
                </Box>
              )}
              {tipoP === 'paquete' && (
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6} lg={3}>
                      <TextField
                        label="Peso (KG)"
                        type="number"
                        fullWidth
                        {...getFieldProps('weight')}
                        error={Boolean(touched.weight && errors.weight)}
                        helperText={touched.weight && errors.weight}
                      />
                    </Grid>
                    <Grid item xs={12} md={6} lg={3}>
                      <TextField
                        label="Largo (cm)"
                        type="number"
                        fullWidth
                        {...getFieldProps('length')}
                        error={Boolean(touched.length && errors.length)}
                        helperText={touched.length && errors.length}
                      />
                    </Grid>
                    <Grid item xs={12} md={6} lg={3}>
                      <TextField
                        label="Ancho (cm)"
                        type="number"
                        fullWidth
                        {...getFieldProps('width')}
                        error={Boolean(touched.width && errors.width)}
                        helperText={touched.width && errors.width}
                      />
                    </Grid>
                    <Grid item xs={12} md={6} lg={3}>
                      <TextField
                        label="Alto (cm)"
                        type="number"
                        fullWidth
                        {...getFieldProps('height')}
                        error={Boolean(touched.height && errors.height)}
                        helperText={touched.height && errors.height}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              )}
              <Grid item xs={12}>
                <TextField
                  label="Descripcion del contenido"
                  fullWidth
                  {...getFieldProps('description')}
                  error={Boolean(touched.description && errors.description)}
                  helperText={touched.description && errors.description}
                />
              </Grid>
              {/* <Grid item sx={12}>
                <DialogEmpaquetado />
              </Grid> */}

              {/* <Grid item xs={12}>
                <FormControl
                  value={tipoDestino}
                  onChange={(e) => {
                    const { value } = e.target;
                    if (value === 'nacional') {
                      setFieldValue('country_code_from', 'MX');
                      setFieldValue('country_code_to', 'MX');
                    } else {
                      setFieldValue('country_code_from', '');
                      setFieldValue('country_code_to', '');
                    }
                    setTipoDestino(value);
                  }}
                >
                  <FormLabel>Destino</FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="nacional"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel value="nacional" control={<Radio />} label="Nacional" />
                    <FormControlLabel value="internacional" control={<Radio />} label="Internacional" />
                  </RadioGroup>
                </FormControl>
              </Grid>
              {tipoDestino === 'internacional' && (
                <Grid item xs={12}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <TextField
                        label="Codigo pais de origen"
                        fullWidth
                        {...getFieldProps('country_code_from')}
                        error={Boolean(touched.country_code_from && errors.country_code_from)}
                        helperText={touched.country_code_from && errors.country_code_from}
                      />
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <TextField
                        label="Codigo pais de destino"
                        fullWidth
                        {...getFieldProps('country_code_to')}
                        error={Boolean(touched.country_code_to && errors.country_code_to)}
                        helperText={touched.country_code_to && errors.country_code_to}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              )} */}
              <Grid item container spacing={1} xs={12}>
                <Grid item xs={12}>
                  <LoadingButton
                    type="submit"
                    // color="secondary"
                    loading={isSubmitting}
                    // onClick={() => {
                    //   setActionValue('no_vencedor');
                    //   handleSubmit();
                    // }}
                    variant="contained"
                    fullWidth
                  >
                    Cotizar
                  </LoadingButton>
                </Grid>
                {/* <Grid item xs={6}>
                  <LoadingButton
                    type="submit"
                    loading={isSubmitting}
                    onClick={() => {
                      setActionValue('vencedor');
                      handleSubmit();
                    }}
                    variant="contained"
                    fullWidth
                  >
                    Cotizar con vencedor
                  </LoadingButton>
                </Grid> */}
              </Grid>
            </Grid>
          </Form>
        </FormikProvider>
      </CardContent>
    </Card>
  );
}
