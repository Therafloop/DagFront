import React from 'react';
import { Box, Button, Card, Grid, Typography } from '@mui/material';

function CardTipo({ tipo = 'sobre' }) {
  return (
    <Card sx={{ padding: '10px', height: '100%' }}>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <Box>
            {tipo === 'sobre' && <img width="80%" src="/static/illustrations/letter.svg" alt="" />}
            {tipo === 'paquete' && <img width="80%" src="/static/illustrations/package.svg" alt="" />}
          </Box>
        </Grid>
        <Grid item xs={6}>
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: '15px',
              justifyContent: 'space-between'
            }}
          >
            <Box>
              <Typography variant="h5" color="text.secondary">
                {tipo === 'sobre' && 'Sobre'}
                {tipo === 'paquete' && 'Paquete'}
              </Typography>

              {tipo === 'sobre' && (
                <Typography variant="subtitle1" color="text.secondary">
                  Envia tus sobres a donde tu quieras.
                </Typography>
              )}
              {tipo === 'paquete' && (
                <Typography variant="subtitle1" color="text.secondary">
                  Envia paquetes de forma segura con nosotros a donde tu quieras.
                </Typography>
              )}
            </Box>

            <Box>
              {tipo === 'sobre' && (
                <Button sx={{ height: '100%' }} size="large" fullWidth variant="contained">
                  Enviar Sobre
                </Button>
              )}
              {tipo === 'paquete' && (
                <Button sx={{ height: '100%' }} color="error" size="large" fullWidth variant="contained">
                  Enviar paquete
                </Button>
              )}
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Card>
  );
}

export default CardTipo;
