import { Grid } from '@mui/material';
import React from 'react';
import CardTipo from './CardTipo';

function TipoEnvio() {
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} md={6}>
        <CardTipo tipo="sobre" />
      </Grid>
      <Grid item xs={12} md={6}>
        <CardTipo tipo="paquete" />
      </Grid>
    </Grid>
  );
}

export default TipoEnvio;
