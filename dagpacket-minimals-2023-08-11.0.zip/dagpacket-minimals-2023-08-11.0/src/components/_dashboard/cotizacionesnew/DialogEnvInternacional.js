import React, { useState } from 'react';
import { Button, Card, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Typography } from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router';

export default function DialogEnvInternacional({ handleSubmit }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <Box>
      <Button variant="contained" fullWidth color="info" onClick={() => setOpenDialog(true)}>
        Cotizar envio internacional
      </Button>
      <InternationalDialog open={openDialog} onClose={setOpenDialog} handleSubmitMain={handleSubmit} />
    </Box>
  );
}

function InternationalDialog({ open, onClose, handleSubmitMain }) {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm();
  const navigate = useNavigate();

  const handleClose = () => {
    onClose(false);
  };

  const onSubmit = (dataForm) => {
    console.log(dataForm);
    const paisOrigen = dataForm.country_code_from.toUpperCase();
    const paisDestino = dataForm.country_code_to.toUpperCase();
    navigate(`/dashboard/cotizaciones/new?origCountry=${paisOrigen}&destiCountry=${paisDestino}&international=true`);
    handleSubmitMain();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Card component="form" sx={{ padding: '15px', marginTop: '15px' }}>
          {/* <Typography variant="subtitle1">Ingrese el valor declarado</Typography> */}
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              {...register('country_code_from', { required: true })}
              error={!!errors.country_code_from}
              label="Codigo pais origen"
            />
            {errors.country_code_from && (
              <Typography color="error" fontSize="12px">
                Ingrese el codigo del pais de origen
              </Typography>
            )}
          </Box>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              {...register('country_code_to', { required: true })}
              error={!!errors.country_code_to}
              label="Codigo pais destino"
            />
            {errors.country_code_to && (
              <Typography color="error" fontSize="12px">
                Ingrese el codigo del pais de destino
              </Typography>
            )}
          </Box>
          <Button onClick={handleSubmit(onSubmit)} fullWidth variant="contained">
            Cotizar
          </Button>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<KeyboardBackspaceIcon />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
