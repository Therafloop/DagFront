import React from 'react';
import { Box, styled, TextField, Typography } from '@mui/material';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { LoadingButton } from '@mui/lab';
import { useSelector } from 'react-redux';

const CuztomBox = styled(Box)(() => ({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  gap: '15px'
}));

function Cotizar() {
  // const { tipoEnvio, medidas } = useSelector((state) => state.dagpacketFlujo);
  const tipo = 'sobre';

  const schema = yup.object().shape({
    zipcode_from: yup.string().min(5, 'El codigo zip debe contener 5 numeros').required('Requerido'),
    zipcode_to: yup.string().min(5, 'El codigo zip debe contener 5 numeros').required('Requerido'),
    weight: yup
      .number()
      .integer('El peso debe ser entero')
      .min(1, 'El peso debe ser mayor a 1kg')
      .required('Requerido')
      .typeError('Ingrese un numero'),
    length: yup
      .number()
      .min(10, 'El largo mínimo debe ser mayor a 10 cm')
      .integer('El largo debe ser un entero')
      .required('Requerido'),
    height: yup.number().min(1, 'Ingrese la altura').integer('La altura debe ser un entero').required('Requerido'),
    width: yup.number().min(1, 'Ingrese el ancho').integer('El ancho debe ser entero').required('Requerido')
  });

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(schema)
  });

  const onSubmit = (dataForm) => {
    console.log(dataForm);
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      <CuztomBox>
        <Box width="100%">
          <TextField
            error={!!errors.zipcode_from}
            {...register('zipcode_from')}
            fullWidth
            label="C.P. origen"
            variant="outlined"
          />
          <Typography color="error" fontSize="12px">
            {errors.zipcode_from?.message}
          </Typography>
        </Box>
        <Box width="100%">
          <TextField
            error={!!errors.zipcode_from}
            {...register('zipcode_to')}
            fullWidth
            label="C.P. destino"
            variant="outlined"
          />
          <Typography color="error" fontSize="12px">
            {errors.zipcode_to?.message}
          </Typography>
        </Box>
      </CuztomBox>

      <Box>
        <Typography marginTop="10px" marginBottom="5px" textAlign="center" variant="subtitle1">
          Dimensiones
        </Typography>
        <CuztomBox>
          <Box width="100%">
            <TextField error={!!errors.weight} {...register('weight')} fullWidth label="Peso KG" variant="outlined" />
            <Typography color="error" fontSize="12px">
              {errors.weight?.message}
            </Typography>
          </Box>
          <Box width="100%">
            <TextField error={!!errors.length} {...register('length')} fullWidth label="Largo Cm" variant="outlined" />
            <Typography color="error" fontSize="12px">
              {errors.length?.message}
            </Typography>
          </Box>
          <Box width="100%">
            <TextField error={!!errors.width} {...register('width')} fullWidth label="Ancho Cm" variant="outlined" />
            <Typography color="error" fontSize="12px">
              {errors.width?.message}
            </Typography>
          </Box>
          <Box width="100%">
            <TextField error={!!errors.height} {...register('height')} fullWidth label="Alto Cm" variant="outlined" />
            <Typography color="error" fontSize="12px">
              {errors.height?.message}
            </Typography>
          </Box>
        </CuztomBox>
      </Box>

      <Box marginTop="15px">
        <LoadingButton fullWidth variant="contained" type="submit">
          Cotizar
        </LoadingButton>
      </Box>
    </Box>
  );
}

export default Cotizar;
