import React, { useState, useEffect } from 'react';
// mui
import {
  Box,
  Card,
  CardContent,
  // TableContainer,
  // Table,
  // TableBody,
  Grid,
  Paper,
  styled,
  Typography,
  Divider,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Tooltip,
  Alert
} from '@mui/material';
// import TarifaItem from './TarifaItem';
// import { ProductListHead } from '../cotizaciones/product-list';
// redux
import { useSelector } from '../../../redux/store';
import { useLocation, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import { fCurrency } from '../../../utils/formatNumber';
import { convertHourToDay } from '../../../utils/formatTime';
import { analytics } from '../../../contexts/FirebaseContext';
import PaqueteriaCard from '../paquetes/general/PaqueteriaCard';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useSnackbar } from 'notistack';
import { useForm } from 'react-hook-form';
import DialogSeetingsConfComponent from '../settingsConf/settingsConfComponent/DialogSeetingsConfComponent';
import { rolesConfPermissions } from '../../../constants/rolesConfPermissions';
import useSettingsConf from '../../../hooks/settingsConfHooks/useSettingsConf';
import SettingsFunctionsGuard from '../../../guards/SettingsFunctionsGuard';
import DialogCotConf from './conf-cotizar/DialogCotConf';
import ConfRenderComponent from '../olimpo/roles/section-2/conf-permissions/components/ConfRenderComponent';
import useGetSettingConf from '../../../hooks/settingsConfHooks/useGetSettingConf';
import useAuthUsers from '../../../hooks/useAuthUsers';
import { Icon } from '@iconify/react';
import DialogReportTicket from '../olimpo/tickets/components/DialogReportTicket';
import { actionSectionIdentifier, sectionIdentifier } from '../../../constants/ticketsErrors';
import DialogCardVencedorCotizar from './cotizarExtras/DialogCardVencedorCotizar';

// ----------------------------------------------------------------------

export default function ListaTarifas() {
  const { tarifasTotal, cotTarifasError, errorResponseCotizacion } = useSelector((state) => state.dagpacket);

  console.log(tarifasTotal, 'dddddddddddddddddddd');

  let alert = null;
  if (cotTarifasError) {
    if (
      errorResponseCotizacion.errorResponse.message === 'No se encontraron datos de la ciudad con el codigo postal: '
    ) {
      alert = (
        <Alert severity="error">
          El codigo postal{' '}
          <Typography variant="subtitle1" display="inline">
            {errorResponseCotizacion.errorResponse.error ?? ''}
          </Typography>{' '}
          que está intentando ingresar no es valido. Verifique e intente nuevamente. Si el problema persiste, favor
          reportarlo a los administradores del sitio. <DialogReportTicket buttonType="icon" ticketObj={ticketObj} />
        </Alert>
      );
    } else {
      alert = (
        <Alert severity="error">
          Ha ocurrido un error, vuelva a intentarlo o reporte el problema a los desarrolladores.
          <DialogReportTicket buttonType="icon" ticketObj={ticketObj} />
        </Alert>
      );
    }
  }

  const ticketObj = { action: actionSectionIdentifier.hacerCotizacion, section: sectionIdentifier.cotizacionSection };
  return (
    <Box>
      <Card>
        <CardContent>
          {tarifasTotal.length > 0 && <TarifaList />}
          {alert}
        </CardContent>
      </Card>
    </Box>
  );
}

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(2),
  textAlign: 'center',
  color: theme.palette.text.secondary,
  display: 'flex',
  flexDirection: 'column'
}));

const DataSec = styled(Box)(() => ({
  // display: 'flex',
  // justifyContent: 'space-between',
  width: '190px',
  margin: 'auto',
  // gap: '10px'
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  // border: 'solid 1px #000',
  // padding: '0 20px',
  textAlign: 'initial',
  marginTop: 1
}));

function TarifaList() {
  const settingId = rolesConfPermissions.cotizacionConfSetting;
  const [allowedPaq, setAllowedPaq] = useState([]);
  const [inactivePaqs, setInactivePaqs] = useState([]);
  const [serviceProveedores, setServiceProveedores] = useState([]);
  const [serviceProveedoresWithoutServ, setServiceProveedoresWithoutServ] = useState([]);
  const [ascend, setAscend] = useState(false);

  const { tarifasTotal, showTarifas } = useSelector((state) => state.dagpacket);
  const { proveedoresPublico } = useSelector((state) => state.dagpacketControlPaq);
  const { coloniasVnecedor } = useSelector((state) => state.dagpacketVencedor);
  const { settingsList } = useSelector((state) => state.settingsFunc);
  const { currentUser } = useAuthUsers();
  const { methodSelected } = useGetSettingConf(settingId, 'INACTIVE_COTIZACION_LIST');

  console.log(serviceProveedores, serviceProveedoresWithoutServ);

  useEffect(() => {
    const newArr = [];
    const newArrWhitoutServ = [];
    // eslint-disable-next-line array-callback-return
    proveedoresPublico.map((it) => {
      // eslint-disable-next-line array-callback-return
      it.rate_providers.map((prov) => {
        if (prov?.services) {
          // eslint-disable-next-line array-callback-return
          prov?.services.map((serv) => {
            newArr.push(serv);
          });
        } else {
          newArrWhitoutServ.push({ ...prov, idProv: it.name });
        }
      });
    });

    setServiceProveedores(newArr);
    setServiceProveedoresWithoutServ(newArrWhitoutServ);
  }, [proveedoresPublico]);

  useEffect(() => {
    if (showTarifas) {
      const paqs = [];
      proveedoresPublico.map((provider) => {
        // const provider = queryParams.get('provider')?.split('/');
        const filteredTarifas = tarifasTotal.filter(
          (tar) => tar.provider.split('/')[0].toLowerCase() === provider.id.toLowerCase()
        );

        const filteredPaq = provider.rate_providers.filter((paq) => paq.active === true);

        filteredTarifas.map((tar) => {
          // console.log(tar);
          const finded = filteredPaq.find(
            (paq) => paq.id.toLowerCase().trim() === tar.provider.split('/')[1].toLowerCase().replace(' ', '_')
          );

          if (finded) {
            paqs.push(tar);
          }
          return false;
        });

        return false;
      });

      console.log(paqs);
      const newPaqs = [];

      // const filterNewPaqs = (paqsTarifa, servicesProv) => {
      //   if( paqsTarifa.empProveedor){

      //   }
      // }

      // eslint-disable-next-line array-callback-return
      paqs.map((itPaq) => {
        const findedProvService = serviceProveedores.find(
          (it) =>
            it.proveedor.toLowerCase() === itPaq.empProveedor.toLowerCase() &&
            it.rate_provider.toLowerCase() === itPaq.rate_provider.toLowerCase() &&
            it.serviceCode === itPaq.serviceCode
          // it.service === itPaq.service
        );

        if (findedProvService && findedProvService?.status === 'active') {
          newPaqs.push(itPaq);
        }
        if (!findedProvService) {
          newPaqs.push(itPaq);
        }

        // console.log(newPaqs);
      });

      console.log(newPaqs, '==================');

      setAllowedPaq(newPaqs.sort((a, b) => parseFloat(b.price) - parseFloat(a.price)));
      // setAllowedPaq(paqs);
    }
  }, [proveedoresPublico, tarifasTotal, showTarifas, serviceProveedores]);

  useEffect(() => {
    if (showTarifas) {
      const paqs = [];
      proveedoresPublico.map((provider) => {
        // const provider = queryParams.get('provider')?.split('/');
        const filteredTarifas = tarifasTotal.filter(
          (tar) => tar.provider.split('/')[0].toLowerCase() === provider.id.toLowerCase()
        );

        const filteredPaq = provider.rate_providers.filter((paq) => paq.active === false);

        filteredTarifas.map((tar) => {
          // console.log(tar);
          const finded = filteredPaq.find(
            (paq) => paq.id.toLowerCase().trim() === tar.provider.split('/')[1].toLowerCase().replace(' ', '_')
          );
          if (finded) {
            paqs.push(tar);
          }
          return false;
        });
        // console.log('tar filtradas', filteredTarifas, filteredPaq);
        return false;
      });
      setInactivePaqs(paqs.sort((a, b) => parseFloat(b.price) - parseFloat(a.price)));
      // setInactivePaqs(paqs);
    }
  }, [proveedoresPublico, tarifasTotal, showTarifas]);

  const sortItems = () => {
    const allowPaq = [...allowedPaq].reverse();
    setAllowedPaq(allowPaq);
    const inactivePaq = [...inactivePaqs].reverse();
    setInactivePaqs(inactivePaq);
  };

  return (
    <>
      <Box sx={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
        <DialogSeetingsConfComponent settingID={settingId} settingsList={settingsList} title="Vista cotizacion" />

        <Tooltip title="Ordenar">
          <IconButton color="info" onClick={sortItems}>
            <Icon icon="eva:flip-outline" />
          </IconButton>
        </Tooltip>
      </Box>
      <Grid container spacing={{ xs: 1, md: 1 }} columns={{ xs: 4, sm: 8, md: 12 }}>
        {coloniasVnecedor && (
          <Grid item xs={6} sm={4} md={3}>
            <DialogCardVencedorCotizar />
          </Grid>
        )}

        {allowedPaq.map((tar, i) => (
          // <Grid key={i} item xs={6} sm={4} md={3}>
          //   {showTarifas && <PaqueteriaCard item={tar} />}
          // </Grid>
          <Grid key={i} item xs={6} sm={4} md={3}>
            {showTarifas && <TarifaCard tarifa={tar} settingId={settingId} active />}
          </Grid>
        ))}
      </Grid>

      {/* {inactivePaqs.length > 0 && renderComponents} */}
      {/* tarifas que estan inactivas */}
      {methodSelected?.allowedUserRole?.includes(currentUser.role) && (
        <Box sx={{ marginTop: '30px' }}>
          <Typography variant="subtitle1" textAlign="center">
            Inactivos
          </Typography>
          <Grid container spacing={{ xs: 1, md: 1 }} columns={{ xs: 4, sm: 8, md: 12 }}>
            {inactivePaqs.map((tar, i) => (
              // <Grid key={i} item xs={6} sm={4} md={3}>
              //   {showTarifas && <PaqueteriaCard item={tar} />}
              // </Grid>
              <Grid key={i} item xs={6} sm={4} md={3}>
                {showTarifas && <TarifaCard tarifa={tar} settingId={settingId} active={false} />}
              </Grid>
            ))}
          </Grid>
        </Box>
      )}

      {/* <ConfRenderComponent arrData={COTIZACION_ARR_HOOK} settingsList={settingsList} idConf={settingId} /> */}
    </>
  );
}

TarifaCard.propTypes = {
  tarifa: PropTypes.object,
  tarifaRed: PropTypes.object,
  redpack: PropTypes.bool
};

export function TarifaCard({ tarifa, tarifaRed, redpack = false, settingId = '', active = true }) {
  // const { empaqueCart } = useSelector((state) => state.dagpacketEmpaquetado);
  const navigate = useNavigate();
  const { search } = useLocation();
  // const queryParams = new URLSearchParams(search);
  const { empaqTipoEnvio, useEmpaquetado, empaqResume, total } = useSelector((state) => state.dagpacketEmpaquetado);
  const { coloniaOrigenVencedor, coloniaDestinoVencedor } = useSelector((state) => state.dagpacketVencedor);

  // console.log(queryParams.get('empaquetado'));

  const isSuperEnvios = tarifa?.provider?.split('/')[0] === 'SuperEnvios';
  // console.log(tarifa);

  const serviceLength = tarifa.service.length > 10;
  // console.log(serviceLength);

  // const analyticsEvent = () => {
  //   analytics.logEvent('click_tarifa', {
  //     tarifa: tarifa.name || '',
  //     tarifaprovider: tarifa.provider || '',
  //     servicio: tarifa.servicelevel || '',
  //     redpack,
  //     tarifared: tarifaRed?.name || '',
  //     tarifaredprovider: tarifaRed?.provider || '',
  //     tarifaredservicio: tarifaRed?.servicelevel || ''
  //   });
  // };

  const selecttarifa = () => {
    // analyticsEvent();
    const params = useEmpaquetado
      ? `${search}&shippingValue=${tarifa.price}&providerValue=${tarifa.providerValue}&tipoDesc=${tarifa.tipoDesc}&descuentoValue=${tarifa.descuentoValue}&costo=${tarifa.costo}&utilidad=${tarifa.utilidad}&dagUtility=${tarifa.dagUtility}&licenUtility=${tarifa.licenUtility}&origEnvioVal=${tarifa.originalPrice}&origUtilidad=${tarifa.originalUtilidad}&origDagUtility=${tarifa.originalDagUtility}&origLiceUtility=${tarifa.originalLicenUtility}&iva=${tarifa.iva}&assurancePrice=${tarifa.assurancePrice}&currency=${tarifa.currency}&serviceCode=${tarifa?.serviceCode}&service=${tarifa.service}&provider=${tarifa.provider}&rate_provider=${tarifa.rate_provider}&empProveedor=${tarifa.empProveedor}&zonaExtend=${tarifa.zonaExtendida}&city_from=${tarifa.city_from}&city_to=${tarifa.city_to}&${empaqResume}&colFromVen=${coloniaOrigenVencedor?.D_Colonia}&colToVen=${coloniaDestinoVencedor?.D_Colonia}`
      : `${search}&shippingValue=${tarifa.price}&providerValue=${tarifa.providerValue}&tipoDesc=${tarifa.tipoDesc}&descuentoValue=${tarifa.descuentoValue}&costo=${tarifa.costo}&utilidad=${tarifa.utilidad}&dagUtility=${tarifa.dagUtility}&licenUtility=${tarifa.licenUtility}&origEnvioVal=${tarifa.originalPrice}&origUtilidad=${tarifa.originalUtilidad}&origDagUtility=${tarifa.originalDagUtility}&origLiceUtility=${tarifa.originalLicenUtility}&iva=${tarifa.iva}&assurancePrice=${tarifa.assurancePrice}&currency=${tarifa.currency}&serviceCode=${tarifa?.serviceCode}&service=${tarifa.service}&provider=${tarifa.provider}&rate_provider=${tarifa.rate_provider}&empProveedor=${tarifa.empProveedor}&zonaExtend=${tarifa.zonaExtendida}&city_from=${tarifa.city_from}&city_to=${tarifa.city_to}&colFromVen=${coloniaOrigenVencedor?.D_Colonia}&colToVen=${coloniaDestinoVencedor?.D_Colonia}`;

    navigate(`/dashboard/cotizaciones/nuevoenvio${params}`);
  };

  return (
    <Box sx={{ height: '100%', position: 'relative' }}>
      <Box sx={{ position: 'absolute', top: '5px', left: '5px', zIndex: 100 }}>
        <SettingsFunctionsGuard settingId={settingId}>
          <DialogCotConf tarifa={tarifa} active={active} />
        </SettingsFunctionsGuard>
      </Box>
      <Box onClick={selecttarifa} sx={{ height: '100%' }}>
        <PaqueteriaCard
          item={tarifa}
          empaquetado={useEmpaquetado || false}
          empaqTotal={total || null}
          origin="dagApp"
        />
      </Box>
    </Box>
  );
}

function DialogSupeEnvProps({ open, onClose }) {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm();
  // console.log(open, onClose);
  const handleClose = () => {
    onClose(false);
  };

  const onSubmit = (dataForm) => {
    console.log(dataForm);
    enqueueSnackbar('Item asegurado', { variant: 'success' });
    navigate(`/dashboard/cotizaciones/new?declared_value=${dataForm.declared_value}`);
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Card component="form" sx={{ padding: '15px', marginTop: '15px' }}>
          {/* <Typography variant="subtitle1">Ingrese el valor declarado</Typography> */}
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              {...register('clave_producto', { required: true })}
              error={!!errors.clave_producto}
              label="Clave producto"
            />
            {errors.clave_producto && (
              <Typography color="error" fontSize="12px">
                Ingrese la clave del producto
              </Typography>
            )}
          </Box>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              {...register('clave_unidad', { required: true })}
              error={!!errors.clave_unidad}
              label="Clave unidad"
            />
            {errors.clave_unidad && (
              <Typography color="error" fontSize="12px">
                Ingrese la clave de unidad
              </Typography>
            )}
          </Box>
          <Button onClick={handleSubmit(onSubmit)} fullWidth variant="contained">
            Guardar
          </Button>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<KeyboardBackspaceIcon />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
