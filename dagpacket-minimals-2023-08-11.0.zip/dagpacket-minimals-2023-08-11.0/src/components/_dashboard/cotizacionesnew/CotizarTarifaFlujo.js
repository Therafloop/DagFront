import React, { useState } from 'react';
import { Box, Button, Card, Container, Step, StepLabel, Stepper, Typography } from '@mui/material';
import TipoEnvio from './1-tipoEnvio/TipoEnvio';
import ListaTarifas from './3-tarifas/ListaTarifas';
import Cotizar from './2-cotizar/Cotizar';

export default function CotizarTarifaFlujo() {
  const [activeStep, setActiveStep] = useState(0);
  const [skipped, setSkipped] = useState(new Set());

  const handleJumpSteps = (step = 1) => {
    setActiveStep(step);
  };

  const handleNext = () => {
    const newSkipped = skipped;

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped(newSkipped);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };

  const steps = [
    {
      label: 'Tipo envio',
      component: <TipoEnvio />
    },
    {
      label: 'Nueva cotización',
      component: <Cotizar />
    },
    {
      label: 'Tarifas',
      component: <ListaTarifas />
    }
  ];

  return (
    <Container>
      <Box sx={{ width: '100%' }}>
        <Stepper activeStep={activeStep}>
          {steps.map((step, index) => {
            const stepProps = {};
            const labelProps = {};

            return (
              <Step key={step.label} {...stepProps}>
                <StepLabel {...labelProps}>{step.label}</StepLabel>
              </Step>
            );
          })}
        </Stepper>
        {activeStep === steps.length ? (
          <>
            <Typography sx={{ mt: 2, mb: 1 }}>All steps completed - you&apos;re finished</Typography>
            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
              <Box sx={{ flex: '1 1 auto' }} />
              <Button onClick={handleReset}>Reset</Button>
            </Box>
          </>
        ) : (
          <>
            {/* ---------------cuerpo del steper------------------- */}
            <Card sx={{ padding: '20px', mt: 2, mb: 1, width: '100%' }}>{steps[activeStep].component}</Card>

            {/* -------------- seccion de botones de control ----------------- */}
            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
              <Button color="inherit" disabled={activeStep === 0} onClick={handleBack} sx={{ mr: 1 }}>
                Back
              </Button>
              <Box sx={{ flex: '1 1 auto' }} />

              <Button onClick={handleNext}>{activeStep === steps.length - 1 ? 'Finish' : 'Next'}</Button>
            </Box>
          </>
        )}
      </Box>
    </Container>
  );
}
