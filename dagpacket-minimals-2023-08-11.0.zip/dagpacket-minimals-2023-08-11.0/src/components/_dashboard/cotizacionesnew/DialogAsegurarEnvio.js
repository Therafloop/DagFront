import React, { useState } from 'react';
import { Button, Card, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Typography } from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router';
import { useSnackbar } from 'notistack';

export default function DialogAsegurarEnvio() {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <Box>
      <Button
        size="small"
        sx={{ textTransform: 'initial', textDecoration: 'underline' }}
        onClick={() => setOpenDialog(true)}
      >
        Asegurar envio
      </Button>
      <AsegurarEnv open={openDialog} onClose={setOpenDialog} />
    </Box>
  );
}

function AsegurarEnv({ open, onClose }) {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm();

  const handleClose = () => {
    onClose(false);
  };

  const onSubmit = (dataForm) => {
    console.log(dataForm);
    enqueueSnackbar('Item asegurado', { variant: 'success' });
    navigate(`/dashboard/cotizaciones/new?declared_value=${dataForm.declared_value}`);
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title" textAlign="center">
        Asegura tu envio
      </DialogTitle>
      <DialogContent>
        <Card component="form" sx={{ padding: '15px', marginTop: '15px' }}>
          {/* <Typography variant="subtitle1">Ingrese el valor declarado</Typography> */}
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              {...register('declared_value', { required: true })}
              type="number"
              error={!!errors.declared_value}
              label="Valor declarado"
            />
            {errors.declared_value && (
              <Typography color="error" fontSize="12px">
                Ingrese el valor declarado
              </Typography>
            )}
          </Box>
          <Button onClick={handleSubmit(onSubmit)} fullWidth variant="contained">
            Guardar
          </Button>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<KeyboardBackspaceIcon />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
