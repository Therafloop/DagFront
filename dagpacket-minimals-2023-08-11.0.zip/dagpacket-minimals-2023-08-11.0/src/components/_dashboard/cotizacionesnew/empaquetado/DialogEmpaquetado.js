import React, { useEffect, useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import OpcionesEmpaquetado from './OpcionesEmpaquetado';
import ResumeEmpaquetado from './ResumeEmpaquetado';
import { useDispatch } from 'react-redux';
import { getAlmacenId, resetInitialState } from '../../../../redux/slices/dagpacketEmpaquetado';

// ya no se usa el boton de dialogo porque se abre automaticamente
export default function DialogEmpaquetado() {
  const [openDialog, setOpenDialog] = useState(true);

  return (
    <>
      <Button
        sx={{ textDecoration: 'underline' }}
        size="small"
        // variant="contained"
        color="inherit"
        onClick={() => setOpenDialog(true)}
      >
        Empaquetado
      </Button>
      {/* <DialogBodyEmpaquetado open={openDialog} onClose={setOpenDialog} /> */}
    </>
  );
}

export function DialogBodyEmpaquetado({ dataUser }) {
  const [openDialog, setOpenDialog] = useState(true);
  const dispatch = useDispatch();
  const handleClose = () => {
    setOpenDialog(false);
  };

  useEffect(() => {
    if (dataUser.almacenId) {
      dispatch(getAlmacenId(dataUser.almacenId));
    }
  }, [dataUser.almacenId, dispatch]);

  return (
    <Dialog
      open={openDialog}
      // onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      <DialogContent>
        <Grid container spacing={2}>
          <Grid item xs={8}>
            <OpcionesEmpaquetado dataUser={dataUser} />
          </Grid>
          <Grid item xs={4}>
            <ResumeEmpaquetado onClose={handleClose} />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleClose}
          variant="outlined"
          color="inherit"
          startIcon={<Icon icon="eva:arrow-back-fill" />}
        >
          Cotizar sin empaque
        </Button>
      </DialogActions>
    </Dialog>
  );
}
