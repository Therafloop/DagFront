import { Icon } from '@iconify/react';
import { Box, Divider, IconButton, Typography } from '@mui/material';
import React from 'react';
import { useDispatch } from 'react-redux';
import { removeEmpaque, removeEmpaqueAction } from '../../../../redux/slices/dagpacketEmpaquetado';
import { fCurrency } from '../../../../utils/formatNumber';

function CardItemResume({ item }) {
  const { img, price, price_meter, selected_price, cantidad, stock, type, name, description } = item;
  const dispatch = useDispatch();

  const removeItemEmpaque = () => {
    dispatch(removeEmpaqueAction(item));
  };
  return (
    <>
      <Box sx={{ display: 'flex', gap: '10px', justifyContent: 'space-between', alignItems: 'center' }}>
        <img width="40%" src={img} alt="" />
        <Box>
          <Typography variant="subtitle1">
            {name} x {cantidad}
          </Typography>
          <Typography variant="subtitle1" fontSize="20px">
            {fCurrency(selected_price)}
          </Typography>
          <IconButton onClick={removeItemEmpaque} color="error" size="small">
            <Icon icon="eva:trash-2-fill" />
          </IconButton>
        </Box>
      </Box>
      <Divider />
    </>
  );
}

export default CardItemResume;
