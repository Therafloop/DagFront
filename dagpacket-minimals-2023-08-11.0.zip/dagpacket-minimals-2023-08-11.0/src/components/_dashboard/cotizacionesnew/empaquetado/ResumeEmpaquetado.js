import { Box, Button, Card, Divider, Typography } from '@mui/material';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router';
import { setEmpaqResume } from '../../../../redux/slices/dagpacketEmpaquetado';
import { fCurrency } from '../../../../utils/formatNumber';
import CardItemResume from './CardItemResume';

function ResumeEmpaquetado({ onClose }) {
  const { empaqueCart, total, utility, totalCompra, empaqTipoEnvio, almacenId } = useSelector(
    (state) => state.dagpacketEmpaquetado
  );
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // const location = useLocation();

  // console.log(location);
  const confirmCart = () => {
    const dataArr = [];

    empaqueCart.map((item) => {
      const obj = {
        id: item.id,
        priceUnitCompra: item.price_compra,
        priceUnitVenta: item.price_venta,
        priceCompra: item.price_compra * Number(item.cantidad),
        utility: item.selected_price - item.price_compra * Number(item.cantidad),

        precio: item.selected_price,
        name: item.name,
        cantidad: item.cantidad,
        // unidMed: item.type === 'caja' ? 'unidad' : 'metros',
        type: item.type
      };
      dataArr.push(obj);

      return false;
    });

    const dataParam = {
      total,
      totalCompra,
      utility,
      items: dataArr
    };

    dispatch(
      setEmpaqResume(
        `empaquetado=true&empaqTipoEnvio=${empaqTipoEnvio}&empaqAlmacenId=${almacenId}&empaquetadoTotal=${total}&detalleEmpaq=${JSON.stringify(
          dataParam
        )}`
      )
    );
    // navigate(
    //   `/dashboard/cotizaciones/new?empaquetado=true&empaqTipoEnvio=${empaqTipoEnvio}&empaquetadoTotal=${total}&detalleEmpaq=${JSON.stringify(
    //     dataParam
    //   )}`
    // );
    // console.log(JSON.stringify(dataParam));
    onClose();
  };

  return (
    <Card sx={{ padding: '15px' }}>
      <Typography textAlign="center" variant="subtitle1">
        Resumen empaque
      </Typography>
      <Divider />
      <Box>
        {empaqueCart.map((item) => (
          <CardItemResume key={item.id} item={item} />
        ))}
      </Box>
      <Divider />
      <Box sx={{ display: 'flex', gap: '10px', justifyContent: 'space-between', marginTop: '10px' }}>
        <Typography variant="subtitle1">Total:</Typography>
        <Typography variant="subtitle1" fontSize="20px">
          {fCurrency(total)}
        </Typography>
      </Box>

      <Button disabled={!empaqueCart.length} onClick={confirmCart} variant="contained" fullWidth>
        Confirmar
      </Button>
    </Card>
  );
}

export default ResumeEmpaquetado;
