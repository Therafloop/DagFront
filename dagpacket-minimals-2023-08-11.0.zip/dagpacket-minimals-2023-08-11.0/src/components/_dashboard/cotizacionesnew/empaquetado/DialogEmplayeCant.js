import React, { useState } from 'react';
import { Button, Card, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { useForm } from 'react-hook-form';
import { useSnackbar } from 'notistack';

export default function DialogEmplayeCant({ setCatidad, price, addEmpaquetadoItem, empaqTipoEnvio, dataItem }) {
  const [openDialog, setOpenDialog] = useState(false);
  const { enqueueSnackbar } = useSnackbar();
  const handleEmpaqTipoEnv = () => {
    // if (empaqTipoEnvio !== 'sobre') {
    //   setOpenDialog(true);
    // }
    if (empaqTipoEnvio === 'sobre' && dataItem.name === 'Emplaye') {
      enqueueSnackbar('No se puede agregar emplaye a un sobre', { variant: 'error' });
    } else {
      setOpenDialog(true);
    }
  };

  return (
    <>
      <Button fullWidth variant="contained" onClick={handleEmpaqTipoEnv}>
        Elegir
      </Button>
      <DialogBody
        open={openDialog}
        onClose={setOpenDialog}
        setCatidad={setCatidad}
        price={price}
        addEmpaquetadoItem={addEmpaquetadoItem}
        dataItem={dataItem}
      />
    </>
  );
}

function DialogBody({ open, onClose, price, addEmpaquetadoItem, dataItem }) {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm({
    defaultValues: { cantidad: 1 }
  });

  const handleClose = () => {
    onClose(false);
  };

  const onSubmit = (data) => {
    console.log(data);
    const obj = {
      cantidad: data.cantidad,
      selected_price: data.cantidad * Number(price)
    };
    addEmpaquetadoItem(obj);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Box sx={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
          <Typography>Precio:</Typography>
          <Typography variant="subtitle1">{watch('cantidad') * price}</Typography>
        </Box>
        <Card component="form" sx={{ padding: '15px' }} onSubmit={handleSubmit(onSubmit)}>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField label="cantidad" {...register('cantidad', { required: true })} />
            {errors.cantidad && (
              <Typography fontSize="13px" color="error">
                This field is required
              </Typography>
            )}
          </Box>

          <Button type="submit" variant="contained" fullWidth disabled={dataItem?.existencia < watch('cantidad')}>
            Aceptar
          </Button>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
