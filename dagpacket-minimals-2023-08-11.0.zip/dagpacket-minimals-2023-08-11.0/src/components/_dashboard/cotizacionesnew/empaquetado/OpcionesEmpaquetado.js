import { TabPanel } from '@mui/lab';
import { Box, Card, Grid, Tab, Tabs, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useAuthUsers from '../../../../hooks/useAuthUsers';
import { firestore } from '../../../../contexts/FirebaseContext';
import CardItem from './CardItem';

function OpcionesEmpaquetado({ dataUser }) {
  const [empaquetadoGeneral, setEmpaquetadoGeneral] = useState([]);
  const [empaquetadoUser, setEmpaquetadoUser] = useState({});
  const [empaque, setEmpaque] = useState([]);
  const [recubrimientos, setRecubrimientos] = useState([]);
  const [arrSelectedItems, setArrSelectedItems] = useState([]);
  const { empaqueCart, empaqTipoEnvio } = useSelector((state) => state.dagpacketEmpaquetado);
  console.log(arrSelectedItems);
  const [value, setValue] = useState(0);
  // const { currentUser } = useAuthUsers();

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  useEffect(() => {
    function getEmpaquetado() {
      firestore
        .collection('emp_almacenes')
        .doc(dataUser.almacenId)
        .onSnapshot((query) => {
          console.log('-----------', query.data());
          if (query.exists) {
            // setEmpaquetadoUser({ id: query.id, ...query.data() });
            setEmpaque(query?.data()?.productoItems.filter((item) => item.type === 'empaque'));
            setRecubrimientos(query?.data()?.productoItems.filter((item) => item.type === 'recubrimiento'));
          }
        });
    }

    getEmpaquetado();
  }, [dataUser.almacenId]);

  // useEffect(() => {
  //   function getEmpaquetado() {
  //     firestore.collection('emp_catalogo').onSnapshot((query) => {
  //       const dataArr = query.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  //       setEmpaquetadoGeneral(dataArr);
  //     });
  //   }

  //   getEmpaquetado();
  // }, []);

  // useEffect(() => {
  //   if (empaquetadoGeneral?.length > 0 && empaquetadoUser?.productoItems?.length > 0) {
  //     const arr = [];
  //     empaquetadoUser?.productoItems.map((item) => {
  //       const finded = empaquetadoGeneral.find((it) => it.id === item.id);

  //       if (finded) {
  //         const obj = {
  //           ...finded,
  //           img: finded.img || item.img,
  //           existencia: item.existencia
  //         };

  //         arr.push(obj);
  //       }

  //       return false;
  //     });
  //     setEmpaque(arr.filter((item) => item.type === 'empaque'));
  //     setRecubrimientos(arr.filter((item) => item.type === 'recubrimiento'));
  //   }
  // }, [empaquetadoGeneral, empaquetadoUser?.productoItems]);

  useEffect(() => {
    const arr = empaqueCart.map((item) => item.id);
    setArrSelectedItems(arr);
  }, [empaqueCart]);

  return (
    <Card sx={{ padding: '15px' }}>
      <Box sx={{ width: '100%', bgcolor: 'background.paper' }}>
        {/* <Box>
          <Typography variant="subtitle1" textAlign="center">
            Empaque
          </Typography>
          <Grid container spacing={1}>
            {empaque.map((caja) => (
              <Grid key={caja.id} item xs={12} sm={6} md={4} lg={3}>
                <Card sx={{ padding: '10px' }}>
                  <CardItem dataItem={caja} arrSelectedItems={arrSelectedItems} empaqTipoEnvio={empaqTipoEnvio} />
                </Card>
              </Grid>
            ))}
          </Grid>

          <Typography variant="subtitle1" textAlign="center">
            Recubrimiento
          </Typography>
          <Grid container spacing={1}>
            {recubrimientos.map((caja) => (
              <Grid key={caja.id} item xs={12} sm={6} md={4}>
                <CardItem dataItem={caja} arrSelectedItems={arrSelectedItems} empaqTipoEnvio={empaqTipoEnvio} />
              </Grid>
            ))}
          </Grid>
        </Box> */}

        <Tabs value={value} onChange={handleChange} centered>
          <Tab label="Empaque" />
          <Tab label="Recubrimiento" />
        </Tabs>

        <Box sx={{ marginTop: '10px' }}>
          {value === 0 && (
            <Grid container spacing={1}>
              {empaque.map((caja) => (
                <Grid key={caja.id} item xs={12} sm={6} md={4}>
                  <Card sx={{ padding: '10px' }}>
                    <CardItem dataItem={caja} arrSelectedItems={arrSelectedItems} empaqTipoEnvio={empaqTipoEnvio} />
                  </Card>
                </Grid>
              ))}
            </Grid>
          )}
          {value === 1 && (
            <Grid container spacing={1}>
              {recubrimientos.map((caja) => (
                <Grid key={caja.id} item xs={12} sm={6} md={4}>
                  <CardItem dataItem={caja} arrSelectedItems={arrSelectedItems} empaqTipoEnvio={empaqTipoEnvio} />
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Box>
    </Card>
  );
}

export default OpcionesEmpaquetado;
