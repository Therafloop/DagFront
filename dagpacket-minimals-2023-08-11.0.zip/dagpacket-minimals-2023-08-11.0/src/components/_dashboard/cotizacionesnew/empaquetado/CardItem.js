import React, { useState } from 'react';
import { Box, Button, Card, Divider, IconButton, Typography } from '@mui/material';
import { fCurrency } from '../../../../utils/formatNumber';
import { useDispatch } from 'react-redux';
import { addEmpaqueCart, addEmpaqueCartAction } from '../../../../redux/slices/dagpacketEmpaquetado';
import { Icon } from '@iconify/react';
import DialogEmplayeCant from './DialogEmplayeCant';
import { useSnackbar } from 'notistack';

function CardItem({ dataItem, arrSelectedItems, empaqTipoEnvio }) {
  // const [cantidad, setCatidad] = useState(1);
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();
  const { img, price_venta, price_meter, stock, type, name, description, existencia } = dataItem;

  // console.log(cantidad);

  const addEmpaquetadoItem = (item) => {
    const obj = {
      ...dataItem,
      ...item
    };
    dispatch(addEmpaqueCartAction(obj));
  };

  return (
    <Card
      sx={{
        padding: '10px',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        justifyContent: 'space-between',
        height: '100%'
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', height: '100%' }}>
        <img style={{ objectFit: 'cover' }} src={img} alt="" />
      </Box>
      <Box>
        <Box sx={{ marginTop: '10px', marginBottom: '10px' }}>
          <Box sx={{ display: 'flex', gap: '10px', justifyContent: 'space-between' }}>
            <Typography fontSize="15px">{name}</Typography>
            <Typography variant="subtitle1">{fCurrency(price_venta)}</Typography>
          </Box>
          <Divider />
          <Typography fontSize="13px">{description}</Typography>
          <Typography fontSize="13px" variant="subtitle2">
            Existencia: {existencia}
          </Typography>
        </Box>
        {!arrSelectedItems.includes(dataItem.id) && (
          <>
            {type === 'empaque' ? (
              <Button
                onClick={() =>
                  addEmpaquetadoItem({
                    cantidad: 1,
                    selected_price: 1 * Number(price_venta)
                  })
                }
                variant="contained"
                fullWidth
                disabled={existencia <= 0}
              >
                Elegir
              </Button>
            ) : (
              <DialogEmplayeCant
                price={price_venta}
                addEmpaquetadoItem={addEmpaquetadoItem}
                empaqTipoEnvio={empaqTipoEnvio}
                dataItem={dataItem}
              />
            )}
          </>
        )}

        {arrSelectedItems.includes(dataItem.id) && (
          <Box width="100%" textAlign="center">
            <IconButton color="info">
              <Icon icon="eva:checkmark-circle-2-fill" />
            </IconButton>
          </Box>
        )}
      </Box>
    </Card>
  );
}

export default CardItem;
