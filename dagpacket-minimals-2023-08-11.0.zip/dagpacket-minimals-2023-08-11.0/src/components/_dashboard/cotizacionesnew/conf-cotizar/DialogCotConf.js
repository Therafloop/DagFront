import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { Icon } from '@iconify/react';
import { firestore } from '../../../../contexts/FirebaseContext';
import { LoadingButton } from '@mui/lab';

export default function DialogCotConf({ tarifa, active = true }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      {/* <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Abrir dialogo
      </Button> */}
      <IconButton size="small" color="info" onClick={() => setOpenDialog(true)}>
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>
      <DialogConf open={openDialog} onClose={setOpenDialog} tarifa={tarifa} active={active} />
    </>
  );
}

function DialogConf({ open, onClose, tarifa, active = true }) {
  const [loading, setLoading] = useState(false);

  const handleClose = () => {
    onClose(false);
  };

  const getProv = async () => {
    const idProvider = tarifa.empProveedor.toUpperCase();
    const provSelected = await (await firestore.collection('proveedores_paq').doc(idProvider).get()).data();
    // console.log('la respuesta', provSelected);
    return provSelected;
  };

  const saveHandle = async (active) => {
    const idProvider = tarifa.empProveedor;

    const provSelected = await getProv();

    console.log('en la card', provSelected.rate_providers);
    const rate_prov_filter = provSelected.rate_providers.filter(
      (item) => item.id.replace('_', '') !== tarifa.rate_provider.replace(' ', '').toUpperCase()
    );
    const findedRateProv = provSelected.rate_providers.find(
      (item) => item.id.replace('_', '') === tarifa.rate_provider.replace(' ', '').toUpperCase()
    );

    findedRateProv.active = active;
    rate_prov_filter.push(findedRateProv);

    setLoading(true);
    try {
      await firestore.collection('proveedores_paq').doc(idProvider).update({ rate_providers: rate_prov_filter });
      setLoading(false);
      handleClose();
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        {active ? (
          <LoadingButton loading={loading} variant="contained" color="error" onClick={() => saveHandle(false)}>
            Desactivar
          </LoadingButton>
        ) : (
          <LoadingButton loading={loading} variant="contained" color="info" onClick={() => saveHandle(true)}>
            Activar
          </LoadingButton>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<KeyboardBackspaceIcon />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
