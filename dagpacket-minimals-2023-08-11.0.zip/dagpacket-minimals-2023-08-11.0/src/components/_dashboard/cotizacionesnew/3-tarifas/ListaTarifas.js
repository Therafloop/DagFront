import { Grid } from '@mui/material';
import React from 'react';
import TarifaCardGeneral from './TarifaCardGeneral';

function ListaTarifas() {
  return (
    <Grid container spacing={2}>
      <TarifaCardGeneral />
    </Grid>
  );
}

export default ListaTarifas;
