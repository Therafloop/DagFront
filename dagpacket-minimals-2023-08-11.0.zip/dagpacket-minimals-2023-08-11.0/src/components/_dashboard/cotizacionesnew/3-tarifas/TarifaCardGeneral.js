import { Card } from '@mui/material';
import React from 'react';
import PaqueteriaAvatar from '../../paquetes/general/PaqueteriaAvatar';

function TarifaCardGeneral() {
  return (
    <Card>
      <PaqueteriaAvatar rate_provider="fedex" />
    </Card>
  );
}

export default TarifaCardGeneral;
