import React from 'react';
import { alpha, useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Container } from '@mui/material';

// import Container from 'components/Container';

const HeroInicio = ({ text1, text2, contentText, btnText, btnAction }) => {
  const theme = useTheme();
  const isMd = useMediaQuery(theme.breakpoints.up('md'), {
    defaultMatches: true
  });

  return (
    <Box position="relative">
      <Container>
        <Grid container spacing={4}>
          <Grid item container alignItems="center" xs={12} md={6}>
            <Box>
              <Box marginBottom={2}>
                <Typography
                  variant="h2"
                  color="text.primary"
                  sx={{
                    fontWeight: 700
                  }}
                >
                  {text1 || 'Develop anything your '}{' '}
                  <Typography
                    component="span"
                    variant="inherit"
                    color="primary"
                    // sx={{
                    //   background: `linear-gradient(180deg, transparent 82%, ${alpha(
                    //     theme.palette.secondary.main,
                    //     0.3
                    //   )} 0%)`
                    // }}
                  >
                    {text2 || 'business needs.'}
                  </Typography>
                </Typography>
              </Box>
              <Box marginBottom={3}>
                <Typography variant="h6" component="p" color="text.secondary" sx={{ fontWeight: 400 }}>
                  {contentText ||
                    'theFront will make your product look modern and professional while saving you precious time.'}
                </Typography>
              </Box>
              <Box
                display="flex"
                flexDirection={{ xs: 'column', sm: 'row' }}
                alignItems={{ xs: 'stretched', sm: 'flex-start' }}
              >
                <Button
                  sx={{ textTransform: 'initial' }}
                  onClick={btnAction || null}
                  variant="contained"
                  color="primary"
                  size="large"
                  fullWidth={!isMd}
                  target="_blank"
                >
                  {btnText || 'Purchase now'}
                </Button>
                {/* <Box marginTop={{ xs: 2, sm: 0 }} marginLeft={{ sm: 2 }} width={{ xs: '100%', md: 'auto' }}>
                  <Button variant="outlined" color="primary" size="large" fullWidth={!isMd}>
                    View documentation
                  </Button>
                </Box> */}
              </Box>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Box height={1} width={1} display="flex" justifyContent="center" alignItems="center">
              <Box height={1} width={1} maxWidth={500}>
                <Box
                  component="img"
                  src="https://assets.maccarianagency.com/svg/illustrations/drawkit-illustration4.svg"
                  width={1}
                  height={1}
                  sx={{
                    filter: theme.palette.mode === 'dark' ? 'brightness(0.8)' : 'none'
                  }}
                />
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>
      <Box
        component="svg"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
        x="0px"
        y="0px"
        viewBox="0 0 1920 100.1"
        sx={{
          width: '100%',
          marginBottom: theme.spacing(-1)
        }}
      >
        <path fill={theme.palette.background.paper} d="M0,0c0,0,934.4,93.4,1920,0v100.1H0L0,0z" />
      </Box>
    </Box>
  );
};

export default HeroInicio;
