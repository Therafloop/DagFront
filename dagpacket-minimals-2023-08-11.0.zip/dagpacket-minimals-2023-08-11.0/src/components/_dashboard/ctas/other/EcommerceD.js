import React, { useState } from 'react';
import { ListItem, ListItemText, ListItemIcon, Dialog, DialogContent } from '@mui/material';
import Ecommerce from 'src/pages/dashboard/GeneralEcommerce';
// icon
import { Icon } from '@iconify/react';
import moneyI from '@iconify/icons-carbon/money';
//

export default function EcommerceD() {
  const [open, setOpen] = useState(false);

  const clickOpen = () => {
    setOpen(true);
  };

  const clickClose = () => {
    setOpen(false);
  };

  return (
    <>
      <ListItem button onClick={clickOpen} sx={{ color: '#506070' }}>
        <ListItemIcon>
          <Icon icon={moneyI} width={23} height={23} />
        </ListItemIcon>
        <ListItemText>E-commerce</ListItemText>
      </ListItem>
      <Dialog open={open} onClose={clickClose} maxWidth="lg">
        <DialogContent>
          <Ecommerce />
        </DialogContent>
      </Dialog>
    </>
  );
}
