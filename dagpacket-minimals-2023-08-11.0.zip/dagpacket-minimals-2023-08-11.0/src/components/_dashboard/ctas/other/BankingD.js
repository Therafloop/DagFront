import React, { useState } from 'react';
import { ListItem, ListItemText, ListItemIcon, Dialog, DialogContent } from '@mui/material';
import Banking from 'src/pages/dashboard/GeneralBanking';
// icon
import { Icon } from '@iconify/react';
import bankI from '@iconify/icons-ant-design/bank-filled';
//

export default function BankingD() {
  const [open, setOpen] = useState(false);

  const clickOpen = () => {
    setOpen(true);
  };

  const clickClose = () => {
    setOpen(false);
  };

  return (
    <>
      <ListItem button onClick={clickOpen} sx={{ color: '#506070' }}>
        <ListItemIcon>
          <Icon icon={bankI} width={23} height={23} />
        </ListItemIcon>
        <ListItemText>Banking</ListItemText>
      </ListItem>
      <Dialog open={open} onClose={clickClose} maxWidth="lg">
        <DialogContent>
          <Banking />
        </DialogContent>
      </Dialog>
    </>
  );
}
