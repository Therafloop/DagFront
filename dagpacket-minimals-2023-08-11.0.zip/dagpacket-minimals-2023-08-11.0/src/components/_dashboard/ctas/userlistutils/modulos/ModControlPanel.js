import React, { useState, useEffect } from 'react';
import { Card, CardContent, Box, Typography, Table, TableRow, TableHead, TableBody, TableCell } from '@mui/material';
import ModControl from './ModControl';
// firebase
import { firestore } from 'src/contexts/FirebaseContext';
import PropTypes from 'prop-types';

ModsControlPanelD.propTypes = {
  userid: PropTypes.string
};

export default function ModsControlPanelD({ userid }) {
  const [plan, setPlan] = useState(undefined);

  useEffect(() => {
    async function getPlan() {
      await firestore
        .collection('plans')
        .doc(userid)
        .onSnapshot((doc) => {
          if (doc.exists) {
            setPlan({ ...doc.data() });
          }
        });
    }
    getPlan();
  }, [userid]);

  return (
    <Card sx={{ margin: '2%' }}>
      <CardContent>
        <Typography variant="h4">Contrataciones</Typography>
        <Box>
          {plan && (
            <>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Modulo</TableCell>
                    <TableCell>Fecha de Expiracion</TableCell>
                    <TableCell>Contratado</TableCell>
                    <TableCell />
                  </TableRow>
                </TableHead>
                <TableBody>
                  <ModControl userid={userid} plan={plan} modulo="empresa" altName="Empresa" limitM />
                  <ModControl userid={userid} plan={plan} modulo="organizacion" altName="Organizacion" limitM />
                  <ModControl userid={userid} plan={plan} modulo="finanzasP" altName="Finanzas Personales" dateApply />
                  <ModControl
                    userid={userid}
                    plan={plan}
                    modulo="desarrolloP"
                    altName="Desarrollo Profesional"
                    dateApply
                  />
                  <ModControl userid={userid} plan={plan} modulo="ML" altName="Machine Learning" dateApply />
                </TableBody>
              </Table>
            </>
          )}
          {!plan && <Typography variant="h4">Datos No Disponibles</Typography>}
        </Box>
      </CardContent>
    </Card>
  );
}
