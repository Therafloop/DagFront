import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import ListaEnvioGeneral from '../usuarios/envios/ListaEnviosGeneral';
import { useDispatch, useSelector } from 'react-redux';
import { setEnviosList } from '../../../redux/slices/dagpacket';
import { groupDataPorMes } from '../../../utils/groupDataByPeriod';
import useAuthUsers from '../../../hooks/useAuthUsers';
import ListaEnvioLicenciatario from '../licenciatarios/dashboard/ListaEnvioLicenciatario/ListaEnviosTotales';

const CardEnviosCorporativo = ({ isAdmin = false, envios, title = '' }) => {
  const { userList } = useSelector((state) => state.dagpacket);
  const { currentUser } = useAuthUsers();
  const [cantEnviosPorMes, setCantEnviosPorMes] = useState([]);

  useEffect(() => {
    const enviosPorMes = groupDataPorMes(envios);
    const arrayOfLengths = Object.values(enviosPorMes).map((arr) => arr.length);
    setCantEnviosPorMes(arrayOfLengths);
  }, [envios]);

  return (
    <>
      <CardDashboard
        data={envios}
        title={title}
        dataGraficas={cantEnviosPorMes}
        children={<ListaEnvioLicenciatario listaEnvios={envios} />}
      />
    </>
  );
};

export default CardEnviosCorporativo;
