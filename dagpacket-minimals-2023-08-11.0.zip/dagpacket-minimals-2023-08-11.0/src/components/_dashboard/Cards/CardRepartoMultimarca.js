import React, { useEffect, useState } from 'react';
import CardDashboard from '../../atomos/CardDashboard';
import { firestore } from '../../../contexts/FirebaseContext';
import ListaRepartosMultimarca from '../licenciatarios/dashboard/repartosMultimarca/ListaRepartoMultimarca';
import { useSelector } from 'react-redux';
import { useUtilidades } from '../../../contexts/UtilidadesContext';
import { calculaUtilidadesRepartos, groupDataByQuincenaOtros } from '../../../utils/groupDataByPeriod';

const CardRepartoMultimarca = ({ isAdmin = false, userIds }) => {
  const [dataTable, setDataTable] = useState([]);
  const { dateFilterAdministracion } = useSelector((state) => state.dagpacketFiltros);
  const [repartoFiltered, setRepartoFiltered] = useState([]);
  const [repartosPorQuincena, setRepartosPorQuincena] = useState([]);
  const { updateUtilidades } = useUtilidades();

  useEffect(() => {
    if (dataTable && !isAdmin) {
      setRepartoFiltered(dataTable.filter((reparto) => userIds.includes(reparto.userId)));
    }
  }, [dataTable, isAdmin, userIds]);

  useEffect(() => {
    if (dataTable && !isAdmin) {
      const filtered = dataTable.filter((reparto) => userIds.includes(reparto.userId));
      setRepartoFiltered(filtered);
    }
  }, [dataTable, isAdmin, userIds]);

  useEffect(() => {
    const groupedRepartosPorQuincena = groupDataByQuincenaOtros(repartoFiltered);
    setRepartosPorQuincena(groupedRepartosPorQuincena);
  }, [repartoFiltered]);

  useEffect(() => {
    function getData() {
      let query = firestore.collection('paquetes_recepcionados_multimarcas').orderBy('created_at', 'desc');

      if (dateFilterAdministracion) {
        query = query.where('created_at', '>', new Date(dateFilterAdministracion));
      }
      const unsubscribe = query.onSnapshot((snapshot) => {
        const dataArr = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setDataTable(dataArr);
      });
      return unsubscribe;
    }

    if (dateFilterAdministracion || !isAdmin) {
      getData();
    }
  }, [dateFilterAdministracion, isAdmin]);

  return (
    <>
      <CardDashboard
        title="Reparto multimarca"
        data={isAdmin ? dataTable : repartoFiltered}
        children={<ListaRepartosMultimarca userIds={userIds} paquetes={isAdmin ? dataTable : repartoFiltered} />}
      />
    </>
  );
};

export default CardRepartoMultimarca;
