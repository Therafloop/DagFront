import React, { useEffect, useState } from 'react';
import CardDashboard from '../../atomos/CardDashboard';
import ListaRegistroRecargas from '../usuarios/registroServRec/ListaRegistroRecargas';
import { groupDataByQuincenaByUpdate } from '../../../utils/groupDataByPeriod';
import CardDashboardDialog from '../../atomos/CardDashboardDialog';
import { useUtilidades } from '../../../contexts/UtilidadesContext';

const CardListaRegistroRecargas = ({ isAdmin = false, dataRecargasParent = [] }) => {
  const [utilidadesPorQuincena, setUtilidadesPorQuincena] = useState([]);
  const { isShowingNewDashboard } = useUtilidades();

  const pagoRecargasPorQuincena = groupDataByQuincenaByUpdate(dataRecargasParent);

  useEffect(() => {
    const utilidadesPorQuincena = Object.values(pagoRecargasPorQuincena).map((quincenaData) => {
      const totalAmount = quincenaData.reduce((total, recarga) => {
        if (recarga.status === 'FAIL' || recarga.status === 'QUOTE') {
          return total;
        }
        return total + recarga.totalAmount;
      }, 0);
      return totalAmount * 0.05; // 5% utilidad del servicio de recarga
    });

    setUtilidadesPorQuincena(utilidadesPorQuincena);
  }, [dataRecargasParent, isAdmin]);

  return (
    <>
      <CardDashboard
        data={dataRecargasParent}
        utilidad={isAdmin ? utilidadesPorQuincena[0] * 0.3 : utilidadesPorQuincena[0] * 0.7}
        title="Pago recarga"
        subTitle="Utilidad esta quincena"
        isCurrency
        children={
          isShowingNewDashboard ? (
            <CardDashboardDialog
              productosPorQuincena={pagoRecargasPorQuincena}
              data={dataRecargasParent}
              title="pago de recargas"
              children={<ListaRegistroRecargas dataTable={dataRecargasParent} isAdmin={isAdmin} />}
              dataGraficas={Object.values(utilidadesPorQuincena).slice(0, 6)}
              utilidades={Object.values(utilidadesPorQuincena)}
            />
          ) : (
            <ListaRegistroRecargas dataTable={dataRecargasParent} isAdmin={isAdmin} />
          )
        }
      />
    </>
  );
};

export default CardListaRegistroRecargas;
