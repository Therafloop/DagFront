import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';

import CardDashboard from '../../atomos/CardDashboard';
import ListaPedidoFactura from '../usuarios/facturacion/ListaPedidoFactura';
import { useSelector } from 'react-redux';

const CardListaPedidoFactura = () => {
  const [solFacts, setSolFacts] = useState([]);
  const [pendientes, setPendientes] = useState([]);
  const { dateFilterAdministracion } = useSelector((state) => state.dagpacketFiltros);

  useEffect(() => {
    if (solFacts.length > 0) {
      setPendientes(solFacts.filter((el) => el.status === 'PENDIENTE'));
    }
  }, [solFacts]);

  useEffect(() => {
    async function getSolFact() {
      let query = firestore.collection('solicitar_facturas');

      if (dateFilterAdministracion) {
        query = query.where('updatedAt', '>', new Date(dateFilterAdministracion));
      }
      const unsubscribe = query.orderBy('updatedAt', 'desc').onSnapshot((snapshot) => {
        const solFactList = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setSolFacts(solFactList);
      });
      return unsubscribe;
    }
    getSolFact();
  }, [dateFilterAdministracion]);

  return (
    <>
      <CardDashboard
        data={solFacts}
        mainData={pendientes}
        mainDataIsPendientes
        subTitle="Pendientes"
        title="Pedidos de Factura"
        children={<ListaPedidoFactura solFacts={solFacts} />}
      />
    </>
  );
};

export default CardListaPedidoFactura;
