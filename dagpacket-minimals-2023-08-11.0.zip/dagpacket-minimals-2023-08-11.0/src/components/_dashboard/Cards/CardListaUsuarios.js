import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import { setUserList } from '../../../redux/slices/dagpacket';
import { useDispatch, useSelector } from 'react-redux';
import ListaUsuarios from '../usuarios/usuarios/ListaUsuarios';
import useAuthUsers from '../../../hooks/useAuthUsers';
import ListaAssignedUser from '../licenciatarios/dashboard/assignedUsers/ListaAssignedUser';

const CardListaUsuarios = ({ isAdmin = false, userId, userList: userListProp }) => {
  const dispatch = useDispatch();
  const { userList: userListRedux } = useSelector((state) => state.dagpacket);
  const userList = isAdmin ? userListRedux : userListProp;
  const { currentUser } = useAuthUsers();

  let usersLicenciatario = [];
  usersLicenciatario = userList.filter((user) => user.hostUser === user.id);

  useEffect(() => {
    async function getUsers() {
      const query = firestore.collection('users');
      const unsubscribe = query.onSnapshot((snapshot) => {
        const userList = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        // console.log({ userListNames: userList.map((user) => user.displayName) });
        const filteredList = userList.filter((user) => user.displayName.includes('JOHANA'));
        // console.log({ userListNamesFiltered: filteredList.map((user) => user.displayName) });

        dispatch(setUserList(userList));
      });

      return () => unsubscribe();
    }

    getUsers();
  }, [dispatch, isAdmin, currentUser.id]);

  return (
    <>
      <CardDashboard
        data={userList}
        // mainData={pendientes}
        title="Usuarios"
        children={isAdmin ? <ListaUsuarios userList={userList} /> : <ListaAssignedUser userList={userList} />}
        // children={<ListaAssignedUser userList={userList} />}
      />
    </>
  );
};

export default CardListaUsuarios;
