import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import { groupDataByQuincenaOtros, sumUtilitiesByPeriodEmpaques } from '../../../utils/groupDataByPeriod';
import RegistroVentaEmpaques from '../usuarios/empaquesGeneral/RegistroVentaEmpaques';
import useAuthUsers from '../../../hooks/useAuthUsers';
import CardDashboardDialog from '../../atomos/CardDashboardDialog';
import { useUtilidades } from '../../../contexts/UtilidadesContext';
import { useSelector } from 'react-redux';

const rolesNotAllowed = ['cliente-corporativo', 'cajero'];

const CardRegistroVentaEmpaques = ({ isAdmin = false, userIds = [], userId }) => {
  const [dataEmpaques, setDataEmpaques] = useState([]);
  const { currentUser } = useAuthUsers();
  const [empaquesPorQuincena, setEmpaquesPorQuincena] = useState([]);
  const [utilidadesPorQuincena, setUtilidadesPorQuincena] = useState([]);
  const { isShowingNewDashboard } = useUtilidades();
  const [valoresUtilidadesQuincenaLic, setValoresUtilidadesQuincenaLic] = useState([]);
  const [valoresUtilidadesQuincenaDag, setValoresUtilidadesQuincenaDag] = useState([]);

  const { dateFilterAdministracion } = useSelector((state) => state.dagpacketFiltros);

  useEffect(() => {
    const utilidadesPorQuincena = sumUtilitiesByPeriodEmpaques(empaquesPorQuincena);
    setUtilidadesPorQuincena(utilidadesPorQuincena);
  }, [empaquesPorQuincena, userId]);

  useEffect(() => {
    const valores = Object.values(utilidadesPorQuincena);
    setValoresUtilidadesQuincenaLic(valores.map((val) => val * 0.7));
    setValoresUtilidadesQuincenaDag(valores.map((val) => val * 0.3));
  }, [utilidadesPorQuincena]);

  useEffect(() => {
    if (dataEmpaques.length > 0) {
      setEmpaquesPorQuincena(groupDataByQuincenaOtros(dataEmpaques));
    }
  }, [dataEmpaques]);

  useEffect(() => {
    async function getData() {
      let query = firestore.collection('emp_ventasEmpaque').orderBy('created_at', 'desc');

      if (dateFilterAdministracion) {
        query = query.where('created_at', '>', new Date(dateFilterAdministracion));
      }

      query.onSnapshot((snapshot) => {
        const dataArr = snapshot.docs
          .map((doc) => ({ id: doc.id, ...doc.data() }))
          .filter((data) => isAdmin || data.hostUserId === userId);
        setDataEmpaques(dataArr);

        // Set utilidadesPorQuincena to an empty object if there's no data for the current user
        if (dataArr.length === 0) {
          setUtilidadesPorQuincena([0]);
        }
      });
    }

    if (dateFilterAdministracion || !isAdmin) {
      getData();
    }
  }, [userId, isAdmin, dateFilterAdministracion]);

  const isRoleNotAllowed = rolesNotAllowed.includes(currentUser.role);

  return (
    <>
      <CardDashboard
        data={dataEmpaques}
        title="Empaques"
        dataGraficas={isAdmin ? valoresUtilidadesQuincenaDag : valoresUtilidadesQuincenaLic}
        utilidad={isAdmin ? valoresUtilidadesQuincenaDag[0] : valoresUtilidadesQuincenaLic[0]}
        subTitle="Utilidad esta quincena"
        isCurrency
        children={
          isShowingNewDashboard && !isRoleNotAllowed ? (
            <CardDashboardDialog
              productosPorQuincena={empaquesPorQuincena}
              data={dataEmpaques}
              title="Venta empaques"
              children={<RegistroVentaEmpaques dataTable={dataEmpaques} userIds={userIds} />}
              dataGraficas={
                isAdmin ? valoresUtilidadesQuincenaDag.slice(0, 6) : valoresUtilidadesQuincenaLic.slice(0, 6)
              }
              utilidades={isAdmin ? valoresUtilidadesQuincenaDag : valoresUtilidadesQuincenaLic}
              parent="empaques"
            />
          ) : (
            <RegistroVentaEmpaques dataTable={dataEmpaques} userIds={userIds} />
          )
        }
      />
    </>
  );
};

export default CardRegistroVentaEmpaques;
