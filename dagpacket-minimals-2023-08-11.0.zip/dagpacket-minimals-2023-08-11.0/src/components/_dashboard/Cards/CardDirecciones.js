import { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import { DialogContent, DialogTitle } from '@mui/material';
import FuncionesUsuario from '../../../pages/dashboard/FuncionesUsuario';

function CardDirecciones() {
  const [direcciones, setDirecciones] = useState([]);

  const getUsers = async () => {
    const docs = await firestore.collection('users').get();
    return docs.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  };

  useEffect(() => {
    const unsubscribe = firestore.collection('direcciones').onSnapshot((snapshot) => {
      getUsers().then((users) => {
        const docs = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data()
        }));
        const directions = [];
        for (let i = 0; i < docs.length; i++) {
          const licensee = users.find((user) => user.id === docs[i].hostUser);
          const user = users.find((user) => user.id === docs[i].user);
          const doc = docs[i];
          directions.push({ ...doc, user, licensee });
        }

        setDirecciones(directions);
      });
    });
    return unsubscribe;
  }, []);
  return (
    <CardDashboard
      title="Direcciones"
      data={direcciones}
      children={
        <>
          <DialogTitle id="alert-dialog-title">Lista de Direcciones</DialogTitle>
          <DialogContent sx={{ marginTop: '15px' }}>
            <FuncionesUsuario direcciones={direcciones} />
          </DialogContent>
        </>
      }
    />
  );
}

export default CardDirecciones;
