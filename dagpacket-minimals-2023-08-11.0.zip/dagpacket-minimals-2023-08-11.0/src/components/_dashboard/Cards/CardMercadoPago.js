import { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import { DialogContent } from '@mui/material';
import TableMercadoPago from '../olimpo/mercadopago/TableMercadoPago/TableMercadoPago';
import { useSelector } from 'react-redux';

function CardMercadoPago() {
  const [pagosOnline, setPagosOnline] = useState([]);
  const { dateFilterAdministracion } = useSelector((state) => state.dagpacketFiltros);

  useEffect(() => {
    if (dateFilterAdministracion) {
      const unsubscribe = firestore
        .collection('pagos_online')
        .where('createdAt', '>', new Date(dateFilterAdministracion))
        .onSnapshot((snapshot) => {
          const docs = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data()
          }));
          console.log({ docs111: docs });
          setPagosOnline(docs);
        });
      return unsubscribe;
    }
  }, [dateFilterAdministracion]);

  return (
    <CardDashboard
      title="Pagos realizados en Mercado pago"
      data={pagosOnline}
      children={
        <>
          <DialogContent sx={{ marginTop: '15px' }}>
            <TableMercadoPago pagosOnline={pagosOnline} />
          </DialogContent>
        </>
      }
    />
  );
}

export default CardMercadoPago;
