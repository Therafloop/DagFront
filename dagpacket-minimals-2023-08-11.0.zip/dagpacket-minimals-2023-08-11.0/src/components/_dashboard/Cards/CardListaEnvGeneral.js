import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import ListaEnvioGeneral from '../usuarios/envios/ListaEnviosGeneral';
import { useDispatch, useSelector } from 'react-redux';
import { setEnviosList } from '../../../redux/slices/dagpacket';
import { calcularUtilidadesPorQuincenaDagPacket, groupDataByQuincena } from '../../../utils/groupDataByPeriod';
import useAuthUsers from '../../../hooks/useAuthUsers';
import { useUtilidades } from '../../../contexts/UtilidadesContext';
import CardDashboardDialog from '../../atomos/CardDashboardDialog';

const CardListaEnvGeneral = ({ isAdmin = false }) => {
  const { envios, userList } = useSelector((state) => state.dagpacket);
  const { currentUser } = useAuthUsers();
  const [enviosPorQuincena, setEnviosPorQuincena] = useState(undefined);
  const { updateUtilidades, isShowingNewDashboard } = useUtilidades();
  const [utilidadesPorQuincenaDagPacket, setUtilidadesPorQuincenaDagPacket] = useState([]);
  const { dateFilterAdministracion } = useSelector((state) => state.dagpacketFiltros);

  useEffect(() => {
    if (enviosPorQuincena) {
      setUtilidadesPorQuincenaDagPacket(calcularUtilidadesPorQuincenaDagPacket(enviosPorQuincena));
    }
  }, [enviosPorQuincena]);

  useEffect(() => {
    setEnviosPorQuincena(groupDataByQuincena(envios.slice(0, 1200)));
  }, [envios]);

  useEffect(() => {
    updateUtilidades('envios', utilidadesPorQuincenaDagPacket.slice(0, 2), isAdmin);
  }, [utilidadesPorQuincenaDagPacket, updateUtilidades, isAdmin]);

  const dispatch = useDispatch();

  useEffect(() => {
    async function getPaqueterias() {
      let query = firestore.collection('cotizaciones');

      if (!isAdmin) {
        query = query.where('user_id', '==', currentUser.id);
      }
      if (dateFilterAdministracion) {
        query = query.where('created_at', '>', new Date(dateFilterAdministracion));
      }
      // if (!dateFilterAdministracion) {
      //   query = query.limit(500);
      // }
      query = query
        .orderBy('created_at', 'desc')
        // .limit(1000)
        .onSnapshot((snapshot) => {
          const envios = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
            licenciatarioName: doc.data()?.hostUser_id
              ? userList?.find((item) => item.id === doc.data()?.hostUser_id)?.displayName
              : '',
            refenceValue:
              doc.data().status === 'CREATED'
                ? `${doc.data()?.object_id} - ${doc.data()?.tracking_code} - ${doc.data()?.trackingNumber} - ${
                    doc.data().label_code
                  } - ${doc.data()?.purchase_id} - ${
                    doc.data()?.hostUser_id
                      ? userList?.find((item) => item.id === doc.data()?.hostUser_id)?.displayName
                      : ''
                  }`
                : doc.data()?.object_id
          }));

          dispatch(setEnviosList(envios));
        });

      return () => query();
    }

    if (dateFilterAdministracion) {
      getPaqueterias();
    }
  }, [dispatch, isAdmin, currentUser.id, dateFilterAdministracion, userList]);

  return (
    <>
      <CardDashboard
        data={envios}
        title="Envíos"
        dataGraficas={utilidadesPorQuincenaDagPacket.slice(0, 6)}
        utilidad={utilidadesPorQuincenaDagPacket[0]}
        isCurrency
        subTitle="Utilidad esta quincena"
        // children={<ListaEnvioGeneral envios={envios} userList={userList} />}
        children={
          isShowingNewDashboard ? (
            <CardDashboardDialog
              productosPorQuincena={enviosPorQuincena}
              data={envios}
              title="Envios"
              children={<ListaEnvioGeneral envios={envios} userList={userList} />}
              dataGraficas={utilidadesPorQuincenaDagPacket.slice(0, 6)}
              utilidades={utilidadesPorQuincenaDagPacket}
            />
          ) : (
            <ListaEnvioGeneral envios={envios} userList={userList} />
          )
        }
      />
    </>
  );
};

export default CardListaEnvGeneral;
