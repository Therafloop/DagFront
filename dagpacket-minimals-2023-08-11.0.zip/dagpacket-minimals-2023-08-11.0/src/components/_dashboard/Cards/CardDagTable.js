import { Card, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import DagTable from '../../tables/DagTable';
import { useSelector } from 'react-redux';
import { fDate } from '../../../utils/formatTime';

// check this component for improved performance

const CardDagTable = () => {
  const { envios, userList } = useSelector((state) => state.dagpacket);

  const groupedData = envios.reduce((result, item) => {
    const {
      costo,
      utilidad,
      hostUser_id,
      shippingValue,
      rate_provider,
      user_rol,
      originAplication,
      user_id,
      created_at
    } = item;

    // Check conditions for hostUser_id
    let ifHostUserIdNull;
    if (hostUser_id === null || hostUser_id === undefined) {
      if (originAplication === 'locker' || user_rol === 'locker') {
        ifHostUserIdNull = 'locker';
      } else {
        ifHostUserIdNull = user_id;
      }
    } else {
      ifHostUserIdNull = hostUser_id;
    }

    if (!result[ifHostUserIdNull]) {
      result[ifHostUserIdNull] = [];
    }
    result[ifHostUserIdNull].push({
      costo,
      utilidad,
      hostUser_id: ifHostUserIdNull,
      shippingValue,
      rate_provider,
      user_rol,
      originAplication,
      user_id,
      created_at: created_at.value ? fDate(new Date(created_at.value)) : fDate(created_at.toDate())
    });
    return result;
  }, {});

  // console.log({ groupedData });

  const groupedDataWithDisplayName = Object.keys(groupedData).map((hostUser_id) => {
    let user;

    if (hostUser_id === null || hostUser_id === undefined) {
      user = userList.find((user) => user.id === groupedData[hostUser_id][0].user_id);
    } else {
      user = userList.find((user) => user.id === hostUser_id);
    }
    // const user = userList.find((user) => user.id === hostUser_id);
    const displayName = user ? user.displayName : hostUser_id;
    const user_id = user ? user.id : null;

    const { costoTotal, utilidadTotal, shippingValueTotal } = groupedData[hostUser_id].reduce(
      (totals, item) => {
        const costo = typeof item.costo === 'number' ? item.costo : 0;
        const utilidad = typeof item.utilidad === 'number' ? item.utilidad : 0;
        const shippingValue = typeof item.shippingValue === 'number' ? item.shippingValue : 0;

        return {
          costoTotal: totals.costoTotal + costo,
          utilidadTotal: totals.utilidadTotal + utilidad,
          shippingValueTotal: totals.shippingValueTotal + shippingValue
        };
      },
      { costoTotal: 0, utilidadTotal: 0, shippingValueTotal: 0 }
    );

    return { hostUser_id, displayName, costoTotal, utilidadTotal, shippingValueTotal, user_id };
  });

  return (
    <Card sx={{ p: 1 }}>
      <Typography variant="h4" textAlign="center">
        Utilidad envíos por licenciatario
      </Typography>
      <DagTable dataPaquetes={groupedDataWithDisplayName} envios={envios} userList={userList} />
    </Card>
  );
};

export default CardDagTable;
