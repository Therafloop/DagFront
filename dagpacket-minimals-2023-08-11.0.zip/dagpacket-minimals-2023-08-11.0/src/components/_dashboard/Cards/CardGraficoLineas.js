import { merge } from 'lodash';
import { useState, useEffect } from 'react';
import ReactApexChart from 'react-apexcharts';
import { Card, CardHeader, Box, TextField, Typography } from '@mui/material';
import { BaseOptionChart } from '../../charts';
import { useSelector } from 'react-redux';
import { groupDataByQuincenaEnvios } from '../../../utils/groupDataByPeriod';

export default function CardGraficoLineas({ enviosLicenciatario = [], isAdmin }) {
  const [seriesData, setSeriesData] = useState(new Date().getFullYear());
  const [chartData, setChartData] = useState([]);
  const { envios: enviosFromState } = useSelector((state) => state.dagpacket);

  const envios = isAdmin ? enviosFromState : enviosLicenciatario;
  const processData = (enviosPorQuincena, isAdmin) => {
    const accumulator = [];

    const sortedEntries = Object.entries(enviosPorQuincena).sort((a, b) => {
      const [yearA, monthA, halfMonthA] = a[0].split('-').map(Number);
      const [yearB, monthB, halfMonthB] = b[0].split('-').map(Number);

      if (yearA !== yearB) {
        return yearA - yearB;
      }

      if (monthA !== monthB) {
        return monthA - monthB;
      }

      return halfMonthA - halfMonthB;
    });

    sortedEntries.forEach(([key, value]) => {
      const [yearString, monthString, halfMonthString] = key.split('-');
      const year = parseInt(yearString, 10);
      const month = parseInt(monthString, 10);

      if (year === 2019) {
        return;
      }
      const halfMonthData = {
        x: `${month}-${halfMonthString}`,
        y: value.reduce((acc, item) => {
          let utilidad;

          if (isAdmin) {
            // If isAdmin, use utilidadEnvioDagpacket if it exists, otherwise use item.utilidad * 0.3
            utilidad = item.utilidadEnvioDagpacket !== undefined ? item.utilidadEnvioDagpacket : item.utilidad * 0.3;
          } else {
            // If not isAdmin, use utilidadEnvioLicen if it exists, otherwise use item.utilidad * 0.7
            utilidad = item.utilidadEnvioLicen !== undefined ? item.utilidadEnvioLicen : item.utilidad * 0.7;
          }

          return acc + utilidad;
        }, 0)
      };

      const existingYearData = accumulator.find((item) => item.year === year);
      if (existingYearData) {
        existingYearData.data[0].data.push(halfMonthData);
      } else {
        accumulator.push({ year, data: [{ name: 'Utilidad', data: [halfMonthData] }] });
      }
    });

    return accumulator;
  };
  useEffect(() => {
    const enviosPorQuincena = groupDataByQuincenaEnvios(envios);
    const data = processData(enviosPorQuincena, isAdmin);
    setChartData(data);
  }, [envios, isAdmin]);

  const handleChangeSeriesData = (event) => {
    setSeriesData(Number(event.target.value));
  };

  const chartOptions = merge(BaseOptionChart(), {
    xaxis: {
      labels: {
        formatter: (value) => {
          const valueStr = String(value);
          const [month, halfMonth] = valueStr.split('-');
          const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
          return `${monthNames[parseInt(month, 10)]} ${halfMonth === '1' ? '/ 1' : '/ 2'}`;
        }
      }
    },
    yaxis: {
      min: 0,
      labels: {
        formatter: (value) => value.toFixed(2)
      }
    }
  });

  const years = chartData.map((item) => item.year);

  return (
    <Card>
      <CardHeader
        title="Utilidad envíos por quincena"
        action={
          <TextField
            select
            fullWidth
            value={seriesData}
            SelectProps={{ native: true }}
            onChange={handleChangeSeriesData}
            sx={{
              '& fieldset': { border: '0 !important' },
              '& select': { pl: 1, py: 0.5, pr: '24px !important', typography: 'subtitle2' },
              '& .MuiOutlinedInput-root': { borderRadius: 0.75, bgcolor: 'background.neutral' },
              '& .MuiNativeSelect-icon': { top: 4, right: 0, width: 20, height: 20 }
            }}
          >
            {years.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </TextField>
        }
      />
      {envios.length > 0 ? (
        <>
          {chartData.map((item) => (
            <Box key={item.year} sx={{ mt: 3, mx: 3 }} dir="ltr">
              {item.year === seriesData && (
                <ReactApexChart type="line" series={item.data} options={chartOptions} height={364} />
              )}
            </Box>
          ))}
        </>
      ) : (
        <Typography variant="h6" align="center" sx={{ mt: 5 }}>
          No hay datos por el momento
        </Typography>
      )}
    </Card>
  );
}
