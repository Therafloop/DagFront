import React, { useEffect, useState } from 'react';
import CardDashboard from '../../atomos/CardDashboard';
import ListaRegistroServicios from '../usuarios/registroServRec/ListaRegistroServicios';
import { groupDataByQuincenaByUpdate } from '../../../utils/groupDataByPeriod';
import CardDashboardDialog from '../../atomos/CardDashboardDialog';
import { useUtilidades } from '../../../contexts/UtilidadesContext';

const utilidadAcordada = 6;

const CardListaRegistroServicios = ({ isAdmin = false, dataServiciosParent = [], comisionesEmida = [] }) => {
  const [utilidadesPorQuincena, setUtilidadesPorQuincena] = useState([]);
  const { isShowingNewDashboard } = useUtilidades();

  const pagoServiciosPorQuincena = groupDataByQuincenaByUpdate(dataServiciosParent);

  useEffect(() => {
    const utilidadesPorQuincena = Object.values(pagoServiciosPorQuincena).map((quincenaData) =>
      quincenaData.reduce((acc, serv) => {
        if (serv.status === 'FAIL') {
          return acc;
        }
        // Find the corresponding comision object
        const comisionObj = comisionesEmida.find((item) => item.id === serv.productId);
        const utilidad = comisionObj
          ? serv.totalAmount * comisionObj.comission
          : serv.totalAmount - (serv.Amount ? Number(serv.Amount) : 0);
        // Add utilidadAcordada if comisionObj does not exist
        return comisionObj ? acc + utilidad : acc + utilidad + utilidadAcordada;
      }, 0)
    );

    setUtilidadesPorQuincena(utilidadesPorQuincena);
  }, [dataServiciosParent, isAdmin]);

  return (
    <>
      <CardDashboard
        data={dataServiciosParent}
        title="Pago servicios"
        subTitle="Utilidad esta quincena"
        utilidad={isAdmin ? utilidadesPorQuincena[0] * 0.3 : utilidadesPorQuincena[0] * 0.7}
        isCurrency
        children={
          isShowingNewDashboard ? (
            <CardDashboardDialog
              productosPorQuincena={pagoServiciosPorQuincena}
              data={dataServiciosParent}
              title="pago de servicios"
              children={<ListaRegistroServicios dataTable={dataServiciosParent} isAdmin={isAdmin} />}
              dataGraficas={utilidadesPorQuincena.slice(0, 6)}
              utilidades={utilidadesPorQuincena}
            />
          ) : (
            <ListaRegistroServicios dataTable={dataServiciosParent} isAdmin={isAdmin} />
          )
        }
      />
    </>
  );
};

export default CardListaRegistroServicios;
