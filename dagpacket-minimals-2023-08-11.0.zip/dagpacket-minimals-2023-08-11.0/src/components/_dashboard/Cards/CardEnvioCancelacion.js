import React, { useEffect, useState } from 'react';
import ListaEnviosParaCancelacion from '../usuarios/envios/ListaEnviosParaCancelacion';
import { firestore } from '../../../contexts/FirebaseContext';
import useAuth from '../../../hooks/useAuth';
import CardDashboard from '../../atomos/CardDashboard';
import useAuthUsers from '../../../hooks/useAuthUsers';

const CardEnvioCancelacion = ({ isAdmin = false }) => {
  const [envios, setEnvios] = useState([]);
  const [usersList, setUsersList] = useState([]);

  const { currentUser } = useAuthUsers();

  useEffect(() => {
    async function getPaqueterias() {
      let query = firestore.collection('cotizaciones');
      if (!isAdmin) {
        query = query.where('hostUser_id', '==', currentUser.id);
      }

      const unsubscribe = query
        .where('state', '==', 'PENDIENTE-CANCELACION')
        .orderBy('created_at', 'desc')
        .onSnapshot((snapshot) => {
          const envios = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

          setEnvios(envios);
        });

      return () => unsubscribe();
    }
    getPaqueterias();
  }, [currentUser, usersList, isAdmin]);

  useEffect(() => {
    async function getUsersList() {
      const usersDataRef = firestore.collection('users');
      const usersData = await usersDataRef.get();
      const usersDataList = usersData.docs.map((user) => ({ id: user.id, ...user.data() }));
      setUsersList(usersDataList);
    }

    getUsersList();
  }, []);
  return (
    <>
      <CardDashboard
        title="Envios para cancelación"
        children={<ListaEnviosParaCancelacion envios={envios} usersList={usersList} />}
        data={envios}
      />
    </>
  );
};

export default CardEnvioCancelacion;
