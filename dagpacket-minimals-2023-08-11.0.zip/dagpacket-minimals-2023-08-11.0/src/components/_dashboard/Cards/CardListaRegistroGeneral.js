import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import { useSelector } from 'react-redux';
import ListaRegistroGeneral from '../usuarios/registroServRec/ListaRegistroGeneral';
import useAuthUsers from '../../../hooks/useAuthUsers';

const CardListaRegistroGeneral = ({ isAdmin = false }) => {
  const { userList } = useSelector((state) => state.dagpacket);
  const [dataServicios, setDataServicios] = useState([]);
  const [dataRecargas, setDataRecargas] = useState();
  const [dataTable, setDataTable] = useState([]);
  // console.log({ dataServRec: dataTable });

  const { currentUser } = useAuthUsers();

  // useEffect(() => {
  //   async function getData() {
  //     await firestore
  //       .collection('servicioRecarga')
  //       // .where('userId', '==', user.id)
  //       // .where('created_at', '>', startDate)
  //       .orderBy('updated_at', 'desc')
  //       // .limit(200)
  //       .onSnapshot((snapshot) => {
  //         const data = snapshot.docs.map((doc) => {
  //           const finded = userList.find((us) => us.id === doc.data().userId);
  //           return { ...doc.data(), id: doc.id, user_name: finded ? finded?.displayName : '' };
  //         });
  //         setDataTable(data);
  //       });
  //   }
  //   getData();
  // }, [userList]);

  useEffect(() => {
    async function getData() {
      const query = firestore.collection('servicioRecarga').orderBy('updated_at', 'desc');

      const unsubscribe = query.onSnapshot((snapshot) => {
        const data = snapshot.docs
          .map((doc) => {
            const finded = userList.find((us) => us.id === doc.data().userId);
            return { ...doc.data(), id: doc.id, user_name: finded ? finded?.displayName : '' };
          })
          // todo! ccambiar por curremtuser.id
          .filter((data) => isAdmin || data.hostUser_id === currentUser.id);
        // .filter((data) => isAdmin || data.hostUser_id === '63hUV4X1zcNb7jboNgwIAYJi7sD2');
        const dataServ = data.filter((item) => item.type === 'servicio');
        const dataRec = data.filter((item) => item.type === 'recarga');

        setDataServicios(dataServ);
        setDataRecargas(dataRec);
        setDataTable(data);
      });

      return () => {
        unsubscribe();
      };
    }

    getData();
  }, [isAdmin, userList, currentUser.id]);

  return (
    <>
      <CardDashboard
        data={dataTable}
        // mainData={pendientes}
        title="Pago servicios y recarga"
        children={<ListaRegistroGeneral dataTable={dataTable} isAdmin={isAdmin} />}
      />
    </>
  );
};

export default CardListaRegistroGeneral;
