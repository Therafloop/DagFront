import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import CardDashboard from '../../atomos/CardDashboard';
import { setUserList } from '../../../redux/slices/dagpacket';
import { useDispatch, useSelector } from 'react-redux';
import ListaUsuarios from '../usuarios/usuarios/ListaUsuarios';
import useAuthUsers from '../../../hooks/useAuthUsers';

const CardListaUsuariosCorporativo = ({ isAdmin = false, currentUser }) => {
  const dispatch = useDispatch();
  const { userList } = useSelector((state) => state.dagpacket);
  const [usersWithDate, setUsersWithDate] = useState([]);

  useEffect(() => {
    setUsersWithDate(userList.filter((user) => user.updated_at));
  }, [userList]);

  let usersLicenciatario = [];
  usersLicenciatario = userList.filter((user) => user.hostUser === user.id);

  useEffect(() => {
    async function getUsers() {
      let query = firestore.collection('users');

      if (!isAdmin) {
        // todo! Cambiar por user.id
        query = query.where('hostUser', '==', currentUser);
      }

      const unsubscribe = query.onSnapshot((snapshot) => {
        const userList = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        dispatch(setUserList(userList));
      });

      return () => unsubscribe();
    }

    getUsers();
  }, [dispatch, isAdmin, currentUser]);

  return (
    <>
      <CardDashboard
        data={userList}
        // mainData={pendientes}
        title="Usuarios"
        children={<ListaUsuarios userList={userList} />}
      />
    </>
  );
};

export default CardListaUsuariosCorporativo;
