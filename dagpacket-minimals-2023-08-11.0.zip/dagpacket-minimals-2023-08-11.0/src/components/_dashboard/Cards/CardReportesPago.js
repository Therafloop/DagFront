import React, { useEffect, useState } from 'react';
import { firestore } from '../../../contexts/FirebaseContext';
import UsersPaymentReports from '../usuarios/UsersPaymentReports';
import CardDashboard from '../../atomos/CardDashboard';
import { useSelector } from 'react-redux';

const CardReportesPago = () => {
  const [reports, setReports] = useState([]);
  const [pendientes, setPendientes] = useState([]);
  const { dateFilterAdministracion } = useSelector((state) => state.dagpacketFiltros);

  // console.log({ reports });

  useEffect(() => {
    if (reports.length > 0) {
      setPendientes(reports.filter((el) => el.status === 'PENDIENTE'));
    }
  }, [reports]);

  useEffect(() => {
    async function getPaymentReports() {
      firestore
        .collection('payment_reports')
        .where('created_at', '>', new Date(dateFilterAdministracion))
        .orderBy('created_at', 'desc')
        .onSnapshot((queryS) => {
          const dat = [];
          queryS.forEach((doc) => {
            dat.push({
              id: doc.id,
              ...doc.data()
            });
          });
          setReports(dat);
        });
    }

    if (dateFilterAdministracion) {
      getPaymentReports();
    }
  }, [dateFilterAdministracion]);
  return (
    <>
      <CardDashboard
        data={reports}
        mainData={pendientes}
        mainDataIsPendientes
        subTitle="Pendientes"
        title="Reportes de pago"
        children={<UsersPaymentReports reports={reports} />}
      />
    </>
  );
};

export default CardReportesPago;
