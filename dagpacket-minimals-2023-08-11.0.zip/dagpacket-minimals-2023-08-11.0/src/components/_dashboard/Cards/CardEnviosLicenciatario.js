import React, { useEffect, useRef, useState } from 'react';
import CardDashboard from '../../atomos/CardDashboard';
import { calcularUtilidadesPorQuincenaLicenciatario, groupDataByQuincena } from '../../../utils/groupDataByPeriod';
import CardDashboardDialog from '../../atomos/CardDashboardDialog';
import { useUtilidades } from '../../../contexts/UtilidadesContext';
import ListaEnviosCorporativo from '../licenciatarios/dashboard/ListaEnvioLicenciatario/ListaEnviosCorporativo';
import useAuthUsers from '../../../hooks/useAuthUsers';

const rolesNotAllowed = ['cliente-corporativo', 'cajero'];

const CardEnviosLicenciatario = ({ isAdmin = false, envios, userIds = [] }) => {
  const { currentUser } = useAuthUsers();
  const [enviosPorQuincena, setEnviosPorQuincena] = useState([]);
  const utilidadPorQuincena = calcularUtilidadesPorQuincenaLicenciatario(enviosPorQuincena);
  const { isShowingNewDashboard } = useUtilidades();

  const prevUtilidadPorQuincenaRef = useRef();

  useEffect(() => {
    prevUtilidadPorQuincenaRef.current = utilidadPorQuincena;
  });

  useEffect(() => {
    setEnviosPorQuincena(groupDataByQuincena(envios));
  }, [envios]);

  const isRoleNotAllowed = rolesNotAllowed.includes(currentUser.role);

  return (
    <>
      <CardDashboard
        data={envios}
        title="Envíos"
        dataGraficas={utilidadPorQuincena.slice(0, 6)}
        utilidad={utilidadPorQuincena.length > 0 ? utilidadPorQuincena[0] : 0}
        subTitle={currentUser.role !== 'cliente-corporativo' ? 'Utilidad esta quincena' : 'Esta quincena'}
        isCurrency={currentUser.role !== 'cliente-corporativo'}
        children={
          isShowingNewDashboard && !isRoleNotAllowed ? (
            <CardDashboardDialog
              productosPorQuincena={enviosPorQuincena}
              data={envios}
              title="Envios"
              children={<ListaEnviosCorporativo envios={envios} userIds={userIds} />}
              dataGraficas={utilidadPorQuincena.slice(0, 6)}
              utilidades={utilidadPorQuincena}
            />
          ) : (
            <ListaEnviosCorporativo envios={envios} userIds={userIds} />
          )
        }
      />
    </>
  );
};

export default CardEnviosLicenciatario;
