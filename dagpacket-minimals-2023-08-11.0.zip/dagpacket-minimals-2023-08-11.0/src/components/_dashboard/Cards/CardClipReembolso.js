import { Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import CardDashboard from '../../atomos/CardDashboard';
import { firestore } from '../../../contexts/FirebaseContext';
import ClipReembolsosList from '../usuarios/clipReembolsos/ClipReembolsosList';

function CardClipReembolso({ licenciatarioId = null, isAdmin = true }) {
  const [listaReembolso, setListaReembolso] = useState([]);
  const [pendientes, setPendientes] = useState([]);

  useEffect(() => {
    if (listaReembolso.length > 0) {
      setPendientes(listaReembolso.filter((el) => el.status === 'PENDIENTE'));
    }
  }, [listaReembolso]);

  useEffect(() => {
    async function getReembolsoClip() {
      let query;

      if (licenciatarioId) {
        query = firestore
          .collection('clip_reembolso')
          .where('userToPay', '==', licenciatarioId)
          .orderBy('created_at', 'desc');
      } else {
        query = firestore
          .collection('clip_reembolso')
          // .where('created_at', '>', startDate)
          .orderBy('created_at', 'desc');
      }

      query.onSnapshot((queryS) => {
        const dat = [];
        queryS.forEach((doc) => {
          dat.push({
            id: doc.id,
            ...doc.data()
          });
        });

        console.log(dat);
        setListaReembolso(dat);
      });
    }
    getReembolsoClip();
  }, [licenciatarioId]);

  return (
    <>
      <CardDashboard
        data={listaReembolso}
        mainData={pendientes}
        mainDataIsPendientes
        subTitle="Pendientes"
        title="Reembolsos por CLIP"
        children={<ClipReembolsosList dataList={listaReembolso} isAdmin={isAdmin} />}
      />
    </>
  );
}

export default CardClipReembolso;
