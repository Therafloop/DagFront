import React from 'react';
// mui
import {} from '@mui/material';

export default function CotizacionesList() {
  return <></>;
}
