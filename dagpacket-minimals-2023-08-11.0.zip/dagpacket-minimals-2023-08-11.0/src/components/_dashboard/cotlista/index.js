export { default as CotizacionesList } from './CotizacionesList';
