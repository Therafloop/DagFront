// material
import { styled, alpha } from '@mui/material/styles';
import { Box, Card, Stack, Typography, Button, OutlinedInput } from '@mui/material';
import DialogReportError from '../Dialogs/DialogReportError';

// ----------------------------------------------------------------------

const ContentStyle = styled(Card)(({ theme }) => ({
  marginTop: -120,
  boxShadow: 'none',
  padding: theme.spacing(5),
  paddingTop: theme.spacing(16),
  color: theme.palette.common.white,
  backgroundImage: `linear-gradient(135deg,
    ${theme.palette.primary.main} 0%,
    ${theme.palette.primary.dark} 100%)`
}));

// ----------------------------------------------------------------------

export default function CardReportErrorCartPurchase() {
  return (
    <div>
      <Box
        component="img"
        src="/static/illustrations/illustration_invite.png"
        sx={{
          zIndex: 9,
          position: 'relative',
          left: 40,
          width: 140,
          filter: 'drop-shadow(0 12px 24px rgba(0,0,0,0.24))'
        }}
      />
      <ContentStyle>
        <Stack direction="row" alignItems="center" justifyContent="space-between">
          <Typography variant="h5">Ha ocurrido un error al tratar de registrar el envio</Typography>
        </Stack>

        <Stack marginTop="10px" direction="row" spacing={1} alignItems="center" justifyContent="space-between">
          <DialogReportError />
        </Stack>
      </ContentStyle>
    </div>
  );
}
