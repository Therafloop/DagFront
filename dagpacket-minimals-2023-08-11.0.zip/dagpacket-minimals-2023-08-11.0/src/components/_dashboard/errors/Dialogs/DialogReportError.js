import React, { useEffect, useState } from 'react';
import {
  Button,
  Card,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  TextField,
  Tooltip,
  Typography
} from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import ReportIcon from '@mui/icons-material/Report';
import { useForm } from 'react-hook-form';
import { LoadingButton } from '@mui/lab';
import useReportError from '../../../../hooks/errorsHooks/useReportError';
import { useSelector } from 'react-redux';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../../../../constants/ticketsErrors';
import { useSnackbar } from 'notistack';
import useAuthUsers from '../../../../hooks/useAuthUsers';
import useTickets from '../../../../hooks/ticketsHook/useTickets';

export default function DialogReportError({ itemId }) {
  const [openDialog, setOpenDialog] = useState(false);
  const [dataError, setDataError] = useState({});
  const { paymentCheckout } = useSelector((state) => state.dagpacket);
  const { listErrors } = paymentCheckout;

  // useEffect(() => {
  //   const findedErrorObj = listErrors.find((err) => err.id === itemId);
  //   console.log('el error', findedErrorObj);
  //   if (findedErrorObj) {
  //     setDataError(findedErrorObj);
  //   }
  // }, [itemId, listErrors]);

  return (
    <Box>
      <Button sx={{ textTransform: 'initial' }} color="warning" variant="contained" onClick={() => setOpenDialog(true)}>
        Reportar error
      </Button>
      {/* <Tooltip title="Reportar error">
        <IconButton color="error" size="small" onClick={() => setOpenDialog(true)}>
          <ReportIcon />
        </IconButton>
      </Tooltip> */}

      <ReportErrorForm open={openDialog} onClose={setOpenDialog} />
    </Box>
  );
}

function ReportErrorForm({ open, onClose, dataError }) {
  const [loading, setLoading] = useState(false);
  const { errorResponseCotizacion } = useSelector((state) => state.dagpacket);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm();
  const { reportTicket } = useTickets();
  // const{} = useTickets()
  const { enqueueSnackbar } = useSnackbar();
  const { currentUser } = useAuthUsers();

  const handleClose = () => {
    onClose(false);
  };

  const onSubmit = async (dataForm) => {
    setLoading(true);
    const errorData = {
      action: actionSectionIdentifier.comprarGuia,
      timeStampError: errorResponseCotizacion.timestamp,
      section: sectionIdentifier.cartSection,
      status: statusAction.pending,
      created_at: new Date(),
      updated_at: new Date(),
      asunto: dataForm.asunto,
      description: dataForm.message,
      user_id: currentUser.id
    };
    await reportTicket(errorData);
    setLoading(false);
    enqueueSnackbar('El error se ha reportado exitosamente, pronto le enviaremos respuestas.', { variant: 'success' });
    reset();
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="md"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Card sx={{ padding: '15px' }} component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField fullWidth label="Asunto" {...register('asunto', { required: true })} />
            {errors.asunto && (
              <Typography marginTop="5px" fontSize="13px" color="error">
                Este campo es requerido
              </Typography>
            )}
          </Box>
          <Box>
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Descripcion del error"
              {...register('message', { required: true })}
            />
            {errors.message && (
              <Typography marginTop="5px" fontSize="13px" color="error">
                Este campo es requerido
              </Typography>
            )}
          </Box>
          <LoadingButton type="submit" sx={{ marginTop: '10px' }} loading={loading} fullWidth variant="contained">
            Reportar error
          </LoadingButton>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<KeyboardBackspaceIcon />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
