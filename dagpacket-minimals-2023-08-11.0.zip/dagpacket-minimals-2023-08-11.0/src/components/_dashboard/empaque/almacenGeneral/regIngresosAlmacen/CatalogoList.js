import { Card, Grid } from '@mui/material';
import React, { useState, useEffect } from 'react';
import { firestore } from '../../../../../contexts/FirebaseContext';
import CardItem from './CardItem';

function CatalogoList() {
  const [catalogoList, setCatalogoList] = useState([]);
  console.log('los empaquesassdf', catalogoList);

  useEffect(() => {
    function getData() {
      firestore.collection('emp_catalogo').onSnapshot((query) => {
        const dataArr = [];
        query.forEach((item) => {
          dataArr.push({ id: item.id, ...item.data() });
        });
        setCatalogoList(dataArr);
      });
    }

    getData();
  }, []);
  return (
    <Card sx={{ padding: '15px' }}>
      <Grid container spacing={1}>
        {catalogoList.map((item) => (
          <Grid item key={item.id} xs={12} sm={4} md={3} lg={2}>
            <CardItem dataItem={item} />
          </Grid>
        ))}
      </Grid>
    </Card>
  );
}

export default CatalogoList;
