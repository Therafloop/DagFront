import React, { useEffect, useState } from 'react';
import { Button, Card, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import useEmpaquetado from '../../../../../hooks/useEmpaquetado';
import useAuthUsers from '../../../../../hooks/useAuthUsers';
import useEmpaque from '../../../../../hooks/useEmpaque';
import { firestore } from '../../../../../contexts/FirebaseContext';
import CatalogoList from './CatalogoList';

export default function DialogRegIngreso() {
  const [almacenGeneral, setAlmacenGeneral] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const { inicializarAlmacenGeneral } = useEmpaque();

  const initializeEmpaqueUser = async () => {
    await inicializarAlmacenGeneral();
  };

  useEffect(() => {
    function getData() {
      firestore
        .collection('emp_almacenes')
        .doc('CEDIS')
        .onSnapshot((doc) => {
          if (doc.exists) {
            setAlmacenGeneral(doc.data());
          }
        });
    }

    getData();
  }, []);

  return (
    <Box>
      {almacenGeneral ? (
        <Button
          variant="contained"
          color="info"
          startIcon={<Icon icon="eva:inbox-fill" />}
          onClick={() => setOpenDialog(true)}
        >
          Registrar ingresos
        </Button>
      ) : (
        <Button onClick={initializeEmpaqueUser} variant="contained" color="primary">
          Inicializar almacen
        </Button>
      )}
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </Box>
  );
}

function DialogBody({ open, onClose }) {
  const [section, setSection] = useState(1);

  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Empaque</DialogTitle> */}
      <DialogContent sx={{ marginTop: '15px' }}>
        <CatalogoList />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
