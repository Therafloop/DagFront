import React, { useState } from 'react';
import { Button, Card, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { addEmpaqueUserCartAction } from '../../../../../redux/slices/dagpacketEmpaqueUser';
import { LoadingButton } from '@mui/lab';
import useEmpaque from '../../../../../hooks/useEmpaque';

export default function DialogCardItem({ open, onClose, dataItem }) {
  const { recepcionarProdAlmacenGeneral } = useEmpaque();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting }
  } = useForm();

  const handleClose = () => {
    onClose(false);
  };

  //   console.log(dataItem);

  const onSubmit = async (dataForm) => {
    console.log(dataForm);
    const objData = {
      id: dataItem.id,
      name: dataItem.name,
      img: dataItem.imgUrl,
      description: dataItem.description,
      type: dataItem.type,
      unidad_medida: dataItem.unidad_medida,
      variant: dataItem.variant,
      cantidad: Number(dataForm.cantidad),
      costoUnit: Number(dataForm.costoUnit)
    };

    console.log(objData);

    // dispatch(addEmpaqueUserCartAction(objData));
    await recepcionarProdAlmacenGeneral('CEDIS', objData);
    handleClose();
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Typography variant="subtitle1" textAlign="center">
          {dataItem.name}
        </Typography>
        <Typography variant="subtitle2" textAlign="center">
          {dataItem.description}
        </Typography>
        <Card sx={{ padding: '10px' }} component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField label="Cantidad metros/piezas" {...register('cantidad', { required: true })} />
            {errors.cantidad && (
              <Typography color="error" fontSize="13px">
                This field is required
              </Typography>
            )}
          </Box>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              label="Costo unitario"
              {...register('costoUnit', { required: true })}
              InputProps={{
                inputProps: { step: 'any' }
              }}
            />
            {errors.costoUnit && (
              <Typography color="error" fontSize="13px">
                This field is required
              </Typography>
            )}
          </Box>
          <LoadingButton loading={isSubmitting} type="submit" variant="contained" fullWidth>
            aceptar
          </LoadingButton>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
