import { Card, Grid, Icon, InputAdornment, TextField, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { firestore } from '../../../../../contexts/FirebaseContext';
import UserCard from './UserCard';
import useUserRole from '../../../../../hooks/useUserRole';

function UsersList({ setSelectedUser, selectedUser, addGeneralCardMessage = null, arrFilterByNameRole }) {
  const [userList, setUserList] = useState([]);
  const [searchUser, setSearchUser] = useState('');

  useEffect(() => {
    firestore.collection('users').onSnapshot((query) => {
      const dataArr = [];
      query.forEach((item) => {
        dataArr.push({ id: item.id, ...item.data() });
      });

      setUserList(dataArr);
    });
  }, []);

  //   useEffect(() => {
  //     setSelectedUser(null);
  //   }, []);

  const filterByRoleUsers = userList?.filter((user) => {
    if (!arrFilterByNameRole) {
      return user;
    }
    if (arrFilterByNameRole?.includes(user?.role)) {
      // console.log(user);
      return user;
    }
    return false;
  });

  const filteredUsers = filterByRoleUsers?.filter((user) => {
    if (searchUser === '') {
      return user;
    }
    if (user?.displayName.toLowerCase().includes(searchUser.toLowerCase())) {
      return user;
    }
    return false;
  });

  return (
    <Card sx={{ padding: '15px' }}>
      {/* <Typography variant="subtitle2">Asignar licenciatario</Typography> */}

      <TextField
        sx={{ marginTop: '15px' }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Icon fontSize="25px" icon="eva:search-fill" />
            </InputAdornment>
          )
        }}
        label="Buscar usuario"
        variant="outlined"
        value={searchUser}
        onChange={(e) => setSearchUser(e.target.value)}
      />

      <Grid marginTop="10px" container spacing={1}>
        {addGeneralCardMessage && (
          <Grid item xs={12} md={6}>
            <Card
              onClick={() => setSelectedUser('general')}
              sx={{
                padding: '15px',
                display: 'flex',
                gap: '15px',
                alignItems: 'center',
                height: '100%',
                cursor: 'pointer',
                justifyContent: 'center'
              }}
            >
              <Typography variant="subtitle2">{addGeneralCardMessage}</Typography>
            </Card>
          </Grid>
        )}

        {filteredUsers.map((user) => (
          <UserCard key={user.id} dataUser={user} setSelectedUser={setSelectedUser} selectedUser={selectedUser} />
        ))}
      </Grid>
    </Card>
  );
}

export default UsersList;
