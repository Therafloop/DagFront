import React from 'react';
import { Avatar, Box, Card, IconButton, Typography } from '@mui/material';
import { Icon } from '@iconify/react';

function SelectedUserCard({ dataUser, setSelectedUser }) {
  return (
    <Card
      sx={{
        padding: '5px',
        display: 'flex',
        gap: '15px',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '100%',
        width: '300px'
      }}
    >
      {dataUser === 'general' ? (
        <Box sx={{ px: '10px' }}>
          <Typography variant="subtitle2">Usuarios en general</Typography>
        </Box>
      ) : (
        <Box sx={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <Avatar src={dataUser?.photoURL} />
          <Typography>{dataUser?.displayName}</Typography>
        </Box>
      )}

      <IconButton onClick={() => setSelectedUser(null)}>
        <Icon icon="eva:close-outline" />
      </IconButton>
    </Card>
  );
}

export default SelectedUserCard;
