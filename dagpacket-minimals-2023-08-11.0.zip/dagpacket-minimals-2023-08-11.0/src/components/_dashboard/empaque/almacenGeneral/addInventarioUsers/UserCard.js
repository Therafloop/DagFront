import { Icon } from '@iconify/react';
import { Avatar, Card, Grid, IconButton, Typography } from '@mui/material';
import React from 'react';

function UserCard({ dataUser, setSelectedUser, selectedUser }) {
  const { displayName, email, id, photoURL } = dataUser;

  const sendHostUserId = () => {
    setSelectedUser(dataUser);
  };

  return (
    <Grid item xs={12} md={6}>
      <Card
        onClick={sendHostUserId}
        sx={{ padding: '15px', display: 'flex', gap: '15px', alignItems: 'center', height: '100%', cursor: 'pointer' }}
      >
        <Avatar src={photoURL} />
        <Typography>{displayName}</Typography>
        {selectedUser?.id === dataUser.id && (
          <IconButton>
            <Icon icon="eva:checkmark-circle-2-fill" />
          </IconButton>
        )}
      </Card>
    </Grid>
  );
}

export default UserCard;
