import { LoadingButton } from '@mui/lab';
import {
  Box,
  Button,
  Card,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Icon,
  TextField,
  Typography
} from '@mui/material';
import { useSnackbar } from 'notistack';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useEmpaque from '../../../../../hooks/useEmpaque';
import { firestore } from '../../../../../contexts/FirebaseContext';
import useAuthUsers from '../../../../../hooks/useAuthUsers';
import { fCurrency } from '../../../../../utils/formatNumber';
import CardItemResume from './CardItemResume';
import { useForm } from 'react-hook-form';
import { resetEmpaqueUserSlice } from '../../../../../redux/slices/dagpacketEmpaqueUser';

function ResumeItemsSelected({ dataUser, handleClose }) {
  const [openDialog, setOpenDialog] = useState(false);

  const { empaqueUserCart, total } = useSelector((state) => state.dagpacketEmpaqueUser);

  // const surtirEmpaque = async () => {
  //   console.log(empaqueUserCart);
  //   setLoading(true);
  //   await enviarProducto('CEDIS', dataUser.almacenId, empaqueUserCart);
  //   enqueueSnackbar('Operacion exitosa', { variant: 'success' });

  //   setLoading(false);
  //   handleClose();
  // };

  const handleCloseGeneral = () => {
    handleClose();
  };

  return (
    <Card sx={{ padding: '15px' }}>
      <Typography textAlign="center" variant="subtitle1">
        Empaquetado
      </Typography>
      <Divider />
      <Box>
        {empaqueUserCart.map((item) => (
          <CardItemResume key={item.id} item={item} />
        ))}
      </Box>
      <Divider />

      <Button
        onClick={() => setOpenDialog(true)}
        //   disabled={!empaqueCart.length} onClick={confirmCart}
        variant="contained"
        fullWidth
        sx={{ marginTop: '10px' }}
      >
        Confirmar
      </Button>
      <DialogConfirm
        open={openDialog}
        onClose={setOpenDialog}
        empaqueUserCart={empaqueUserCart}
        dataUser={dataUser}
        handleCloseGeneral={handleCloseGeneral}
      />
    </Card>
  );
}

export default ResumeItemsSelected;

function DialogConfirm({ open, onClose, empaqueUserCart, dataUser, handleCloseGeneral }) {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting }
  } = useForm();
  const { enqueueSnackbar } = useSnackbar();
  const { enviarProducto } = useEmpaque();
  const { currentUser, verifyUserNip } = useAuthUsers();
  const dispatch = useDispatch();

  console.log(empaqueUserCart);

  const handleClose = () => {
    onClose(false);
  };

  const onSubmit = async (data) => {
    if (verifyUserNip(data.nip)) {
      console.log('se pudo');
      await enviarProducto('CEDIS', dataUser.almacenId, empaqueUserCart);
      enqueueSnackbar('Operacion exitosa', { variant: 'success' });

      dispatch(resetEmpaqueUserSlice());

      handleClose();
      handleCloseGeneral();
    } else {
      enqueueSnackbar('Ingrese NIP correcto', { variant: 'error' });
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title" textAlign="center">
        Confirmar traspaso
      </DialogTitle>
      <DialogContent>
        <Card component="form" sx={{ padding: '15px' }} onSubmit={handleSubmit(onSubmit)}>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField label="NIP" type="password" {...register('nip', { required: true })} />
            {errors.nip && (
              <Typography color="error" fontSize="13px">
                Ingrese su NIP correcto
              </Typography>
            )}
          </Box>
          <LoadingButton loading={isSubmitting} variant="contained" fullWidth type="submit">
            Confimar
          </LoadingButton>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
