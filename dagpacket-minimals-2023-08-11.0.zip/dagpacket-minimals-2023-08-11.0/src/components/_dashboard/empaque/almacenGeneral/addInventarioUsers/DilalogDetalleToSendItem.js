import React, { useState } from 'react';
import { Button, Card, Dialog, DialogActions, DialogContent, DialogTitle, TextField, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { addEmpaqueUserCartAction } from '../../../../../redux/slices/dagpacketEmpaqueUser';

export default function DilalogDetalleToSendItem({ open, onClose, dataItem }) {
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm({
    defaultValues: { price_compra: dataItem?.costoUnit ? dataItem?.costoUnit : null }
  });

  const handleClose = () => {
    onClose(false);
  };

  console.log(dataItem);

  const onSubmit = (dataForm) => {
    console.log(dataForm);
    const objData = {
      id: dataItem.id,
      name: dataItem.name,
      img: dataItem.img,
      description: dataItem.description,
      type: dataItem.type,
      unidad_medida: dataItem.unidad_medida,
      variant: dataItem.variant,
      // status: dataItem.status,
      cantidad: Number(dataForm.cantidad),
      price_compra: Number(dataForm.price_compra),
      price_venta: Number(dataForm.price_venta)
    };

    console.log(objData);

    dispatch(addEmpaqueUserCartAction(objData));
    handleClose();
  };

  // const verifyPrecioVenta = () => {
  //   if (watch('price_compra') >= watch('price_venta')) {
  //     return true;
  //   }

  //   return false;
  // };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Box textAlign="center">
          <Typography variant="subtitle1">{dataItem.name}</Typography>
          <Typography variant="subtitle2">{dataItem.description}</Typography>
        </Box>
        <Card sx={{ padding: '10px' }} component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField label="Cantidad metros/piezas" {...register('cantidad', { required: true })} />
            {errors.cantidad && (
              <Typography color="error" fontSize="13px">
                Este campo es requerido
              </Typography>
            )}
          </Box>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField
              label="Precio compra"
              disabled={!!dataItem.costoUnit}
              {...register('price_compra', { required: true })}
            />
            {errors.price_compra && (
              <Typography color="error" fontSize="13px">
                Este campo es requerido
              </Typography>
            )}
          </Box>
          <Box sx={{ marginBottom: '10px' }}>
            <TextField label="Precio venta" {...register('price_venta', { required: true })} />
            {errors.price_venta && (
              <Typography color="error" fontSize="13px">
                Este campo es requerido
              </Typography>
            )}
          </Box>
          <Button
            disabled={Number(watch('price_compra')) >= Number(watch('price_venta'))}
            type="submit"
            variant="contained"
            fullWidth
          >
            aceptar
          </Button>
          {Number(watch('price_compra')) >= Number(watch('price_venta')) === true && (
            <>
              <Typography textAlign="center" fontSize="11px" color="error">
                El precio de venta no puede
              </Typography>
              <Typography textAlign="center" fontSize="11px" color="error">
                ser menor que el precio de compra
              </Typography>
            </>
          )}
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
