import React, { useState } from 'react';
import { Box, Card, Divider, Typography } from '@mui/material';
import { fCurrency } from '../../../../../utils/formatNumber';
import DilalogDetalleToSendItem from './DilalogDetalleToSendItem';

function CardItem({ dataItem }) {
  const [openDialog, setOpenDialog] = useState(false);
  const { img, existencia, name, description } = dataItem;
  return (
    <>
      <Card
        sx={{
          padding: '10px',
          display: 'flex',
          flexDirection: 'column',
          gap: '10px',
          justifyContent: 'space-between',
          height: '100%',
          cursor: 'pointer'
        }}
        onClick={() => setOpenDialog(true)}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', height: '100%' }}>
          <img style={{ objectFit: 'cover' }} src={img} alt="" />
        </Box>
        <Box>
          <Box sx={{ marginTop: '10px', marginBottom: '10px' }}>
            <Box>
              <Typography fontSize="15px">{name}</Typography>
              <Typography variant="subtitle2">Existencia: {existencia}</Typography>
            </Box>
            <Divider />
            <Typography fontSize="13px">{description}</Typography>
          </Box>
        </Box>
      </Card>

      <DilalogDetalleToSendItem open={openDialog} onClose={setOpenDialog} dataItem={dataItem} />
    </>
  );
}

export default CardItem;
