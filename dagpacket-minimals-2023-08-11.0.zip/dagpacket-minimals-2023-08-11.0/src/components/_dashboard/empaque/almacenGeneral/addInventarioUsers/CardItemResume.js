import { Icon } from '@iconify/react';
import { Box, Divider, IconButton, Typography } from '@mui/material';
import React from 'react';
import { useDispatch } from 'react-redux';
import { removeEmpaqueUserAction } from '../../../../../redux/slices/dagpacketEmpaqueUser';
import { fCurrency } from '../../../../../utils/formatNumber';

function CardItemResume({ item }) {
  const { img, cantidad, name } = item;
  const dispatch = useDispatch();

  return (
    <>
      <Box sx={{ display: 'flex', gap: '10px', justifyContent: 'space-between', alignItems: 'center' }}>
        <img width="30%" src={img} alt="" />
        <Box>
          <Typography variant="subtitle1" fontSize="13px">
            {name} x {cantidad}
          </Typography>

          <IconButton color="error" size="small" onClick={() => dispatch(removeEmpaqueUserAction(item))}>
            <Icon icon="eva:trash-2-fill" />
          </IconButton>
        </Box>
      </Box>
      <Divider />
    </>
  );
}

export default CardItemResume;
