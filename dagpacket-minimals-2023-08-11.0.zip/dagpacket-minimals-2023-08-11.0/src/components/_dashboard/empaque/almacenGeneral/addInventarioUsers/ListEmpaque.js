import { Card, Grid } from '@mui/material';
import React, { useState, useEffect } from 'react';
import { firestore } from '../../../../../contexts/FirebaseContext';
import CardItem from './CardItem';

function ListEmpaque() {
  const [empaqueList, setEmpaqueList] = useState([]);
  const [itemsAlmGral, setItemsAlmGral] = useState([]);

  const [productosList, setProductosList] = useState([]);
  console.log('los empaques', productosList);
  console.log('los empaques', itemsAlmGral);

  // useEffect(() => {
  //   function getData() {
  //     firestore.collection('emp_catalogo').onSnapshot((query) => {
  //       const dataArr = [];
  //       query.forEach((item) => {
  //         dataArr.push({ id: item.id, ...item.data() });
  //       });
  //       setEmpaqueList(dataArr);
  //       console.log(dataArr);
  //     });
  //   }

  //   getData();
  // }, []);

  useEffect(() => {
    function getData() {
      firestore
        .collection('emp_almacenes')
        .doc('CEDIS')
        .onSnapshot((query) => {
          if (query.exists) {
            setItemsAlmGral(query.data().productoItems);
          }
          // console.log(query.data());
        });
    }

    getData();
  }, []);

  // useEffect(() => {
  //   const arr = itemsAlmGral.map((item) => {
  //     const finded = empaqueList.find((it) => it.id === item.id);

  //     return finded;
  //   });

  //   setProductosList(arr);
  // }, [empaqueList, itemsAlmGral]);

  return (
    <Card sx={{ padding: '15px' }}>
      <Grid container spacing={1}>
        {itemsAlmGral.map((item) => (
          <Grid item key={item.id} xs={12} sm={4} md={3} lg={2}>
            <CardItem dataItem={item} />
          </Grid>
        ))}
      </Grid>
    </Card>
  );
}

export default ListEmpaque;
