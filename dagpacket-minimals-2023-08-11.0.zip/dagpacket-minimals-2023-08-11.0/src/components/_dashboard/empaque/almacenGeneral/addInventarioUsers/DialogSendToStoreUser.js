import React, { useState, useEffect, useCallback } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import ListEmpaque from './ListEmpaque';
import ResumeItemsSelected from './ResumeItemsSelected';
import UsersList from './UsersList';
import { LoadingButton } from '@mui/lab';
import useEmpaque from '../../../../../hooks/useEmpaque';
import SelectedUserCard from './SelectedUserCard';
import { firestore } from '../../../../../contexts/FirebaseContext';

export default function DialogSendToStoreUser({ dataUser, almGralData }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <Button
        variant="contained"
        color="info"
        onClick={() => setOpenDialog(true)}
        startIcon={<Icon icon="eva:plus-fill" />}
      >
        Enviar empaques
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} dataUser={dataUser || almGralData} />
    </>
  );
}

function DialogBody({ open, onClose }) {
  const [selectedUser, setSelectedUser] = useState(null);
  const [inicializarLoading, setInicializarLoading] = useState(false);
  const { inicializarAlmacen } = useEmpaque();
  const handleClose = () => {
    onClose(false);
  };

  const getUser = useCallback(async (userId) => {
    const res = await (await firestore.collection('users').doc(userId).get()).data();
    setSelectedUser(res);
  }, []);

  const inicializarAlmacenUser = async () => {
    setInicializarLoading(true);
    await inicializarAlmacen(selectedUser?.id);

    // lo hice asi por falta de tiempo y porque el estado no se actuaiza en tiepo real y eso no era lo que queria xd
    await getUser(selectedUser?.id);
    setInicializarLoading(false);
  };

  useEffect(() => {
    setSelectedUser(null);
  }, [open]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        {!selectedUser && <UsersList selectedUser={selectedUser} setSelectedUser={setSelectedUser} />}
        {selectedUser && (
          <>
            <Box sx={{ display: 'flex', justifyContent: 'center', marginBottom: '15px' }}>
              <SelectedUserCard dataUser={selectedUser} setSelectedUser={setSelectedUser} />
            </Box>
            <Grid container spacing={2}>
              {!selectedUser.almacenId ? (
                <Grid item xs={12}>
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="subtitle1" textAlign="center">
                      Este usuario aun no tiene inicializado su almacen de productos
                    </Typography>
                    <LoadingButton loading={inicializarLoading} onClick={inicializarAlmacenUser} variant="contained">
                      Inicializar almacen
                    </LoadingButton>
                  </Box>
                </Grid>
              ) : (
                <>
                  <Grid item xs={9}>
                    <ListEmpaque />
                  </Grid>
                  <Grid item xs={3}>
                    <ResumeItemsSelected dataUser={selectedUser} handleClose={handleClose} />
                  </Grid>
                </>
              )}
            </Grid>
          </>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
