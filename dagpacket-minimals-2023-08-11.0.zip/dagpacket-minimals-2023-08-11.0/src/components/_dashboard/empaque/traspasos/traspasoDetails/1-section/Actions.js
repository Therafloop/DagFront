import { LoadingButton } from '@mui/lab';
import { Box, Card } from '@mui/material';
import { useSnackbar } from 'notistack';
import React, { useState } from 'react';
import useEmpaque from '../../../../../../hooks/useEmpaque';

function Actions({ dataItem }) {
  const [loading, setLoading] = useState(false);
  const { cancelarEnvioProducto } = useEmpaque();
  const { enqueueSnackbar } = useSnackbar();
  console.log(dataItem);

  const cancelTraspaso = async () => {
    setLoading(true);
    await cancelarEnvioProducto(dataItem.origenId, dataItem.destinoId, dataItem);
    setLoading(false);
    enqueueSnackbar('Empaques no recepcionados', { variant: 'success' });
  };

  return (
    <Card sx={{ padding: '15px', display: 'flex', justifyContent: 'center' }}>
      <LoadingButton
        disabled={!dataItem.status === 'PENDIENTE'}
        variant="contained"
        loading={loading}
        onClick={cancelTraspaso}
      >
        Cancelar traspaso
      </LoadingButton>
    </Card>
  );
}

export default Actions;
