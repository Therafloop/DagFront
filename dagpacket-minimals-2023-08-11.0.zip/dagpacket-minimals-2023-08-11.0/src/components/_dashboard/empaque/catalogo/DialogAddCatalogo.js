import React, { useCallback, useEffect, useState } from 'react';
import {
  Button,
  Card,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  InputAdornment,
  LinearProgress,
  Radio,
  RadioGroup,
  Stack,
  styled,
  TextField,
  Typography
} from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import { useForm } from 'react-hook-form';
import { LoadingButton } from '@mui/lab';
import { firestore, storage as st } from '../../../../contexts/FirebaseContext';
import { fData, fPercent } from '../../../../utils/formatNumber';
import { UploadSingleFile } from '../../../upload';

export default function DialogAddCatalogo() {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <Box>
      <Button variant="contained" color="info" onClick={() => setOpenDialog(true)}>
        Crear nuevo producto
      </Button>
      <DialogBody open={openDialog} onClose={setOpenDialog} />
    </Box>
  );
}

const TYPE_EMPAQUETADO = [
  { id: 'empaque', label: 'Empaque' },
  { id: 'recubrimiento', label: 'Recubrimiento' }
];

const VARIANTE_EMPAQUE = [
  { id: 'caja', label: 'Caja' },
  { id: 'sobre', label: 'Sobre' }
];

const LabelStyle = styled(Typography)(({ theme }) => ({
  ...theme.typography.subtitle2,
  color: theme.palette.text.secondary,
  marginBottom: theme.spacing(1)
}));

function DialogBody({ open, onClose }) {
  const [valueType, setValueType] = useState('empaque');
  const [empaqVariant, setEmpaqVariant] = useState('caja');

  const [file, setFile] = useState({ preview: '', file: null });
  const [pF, setPF] = useState(0);
  const [pData, setPData] = useState('');

  console.log(valueType);
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    getFieldState,
    reset,
    formState: { errors, isSubmitting }
  } = useForm();

  const handleClose = () => {
    onClose(false);
  };

  const handleChangeType = (event) => {
    setValueType(event.target.value);
  };

  const handleChangeVariantEmpaque = (event) => {
    setEmpaqVariant(event.target.value);
  };

  const onSubmit = async (dataForm) => {
    // console.log(dataForm);
    const newObj = {
      ...dataForm,
      variant: valueType === 'empaque' ? dataForm.variant : 'recubrimiento',
      status: 'active',
      price_venta: Number(dataForm.price_venta),
      price_compra: Number(dataForm.price_compra),
      unidad_medida: valueType === 'empaque' ? 'unid.' : 'm',
      created_at: new Date(),
      updated_at: new Date()
    };

    // console.log(newObj);
    const imgUrl = await uploadMedia();

    newObj.imgUrl = imgUrl;
    await firestore.collection('emp_catalogo').add(newObj);

    reset();
    setFile({ preview: '', file: null });
    handleClose();
  };

  const uploadMedia = useCallback(async () => {
    const refF = st.ref().child(`payment_report/${file.file.name}`);

    return new Promise((resolve) => {
      if (file.file !== null) {
        refF.put(file.file).on('next', (snapshot) => {
          const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setPF(percent);
          setPData(`${fData(snapshot.bytesTransferred)} / ${fData(snapshot.totalBytes)}  (${fPercent(percent)})`);
          if (percent === 100) {
            setTimeout(() => {
              refF.getDownloadURL().then((url) => {
                resolve(url);
              });
            }, 1500);
          }
        });
      } else {
        resolve(null);
      }
    });
  }, [file]);

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <Card sx={{ padding: '15px' }} component="form" onSubmit={handleSubmit(onSubmit)}>
          <Box sx={{ marginBottom: '15px' }}>
            <TextField fullWidth label="Nombre" {...register('name', { required: true })} />
            {errors.name && (
              <Typography fontSize="13px" color="error">
                Este campo es requerido
              </Typography>
            )}
          </Box>
          <Box sx={{ marginBottom: '15px' }}>
            <FormControl>
              <FormLabel id="demo-radio-buttons-group-label">Tipo</FormLabel>
              <RadioGroup
                row
                aria-labelledby="demo-radio-buttons-group-label"
                defaultValue={TYPE_EMPAQUETADO[0].id}
                name="radio-buttons-group"
                onChange={handleChangeType}
                // {...register('category')}
              >
                {TYPE_EMPAQUETADO.map((type) => (
                  <FormControlLabel
                    key={type.id}
                    {...register('type')}
                    value={type.id}
                    control={<Radio />}
                    label={type.label}
                  />
                ))}
              </RadioGroup>
            </FormControl>
          </Box>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1}>
            <Box sx={{ marginBottom: '15px' }}>
              <TextField
                fullWidth
                type="number"
                label="Precio venta"
                {...register('price_venta', { required: true })}
                InputProps={{
                  startAdornment: <InputAdornment position="start">$</InputAdornment>,
                  inputProps: { step: 'any' }
                }}
              />
              {errors.price_venta && (
                <Typography fontSize="13px" color="error">
                  Este campo es requerido
                </Typography>
              )}
            </Box>
            <Box sx={{ marginBottom: '15px' }}>
              <TextField
                fullWidth
                type="number"
                label="Precio compra"
                {...register('price_compra', { required: true })}
                InputProps={{
                  startAdornment: <InputAdornment position="start">$</InputAdornment>,
                  inputProps: { step: 'any' }
                }}
              />
              {errors.price_compra && (
                <Typography fontSize="13px" color="error">
                  Este campo es requerido
                </Typography>
              )}
            </Box>
          </Stack>

          {/* {valueType === 'empaque' ? (
              <Box sx={{ marginBottom: '15px' }}>
                <TextField
                  type="number"
                  label="Precio"
                  {...register('price', { required: true })}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">$</InputAdornment>
                  }}
                />
                {errors.price && (
                  <Typography fontSize="13px" color="error">
                    Este campo es requerido
                  </Typography>
                )}
              </Box>
            ) : (
              <Box sx={{ marginBottom: '15px' }}>
                <TextField
                  type="number"
                  label="Precio por metro"
                  {...register('price_meter', { required: true })}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">$</InputAdornment>
                  }}
                />
                {errors.price_meter && (
                  <Typography fontSize="13px" color="error">
                    Este campo es requerido
                  </Typography>
                )}
              </Box>
            )} */}

          {valueType === 'empaque' && (
            <Box sx={{ marginBottom: '15px' }}>
              <FormControl>
                <FormLabel id="demo-radio-buttons-group-label">Tipo</FormLabel>
                <RadioGroup
                  row
                  aria-labelledby="demo-radio-buttons-group-label"
                  defaultValue={VARIANTE_EMPAQUE[0].id}
                  name="radio-buttons-group"
                  onChange={handleChangeVariantEmpaque}
                  // {...register('category')}
                >
                  {VARIANTE_EMPAQUE.map((variant) => (
                    <FormControlLabel
                      key={variant.id}
                      {...register('variant')}
                      value={variant.id}
                      control={<Radio />}
                      label={variant.label}
                    />
                  ))}
                </RadioGroup>
              </FormControl>
            </Box>
          )}
          <Box sx={{ marginBottom: '15px' }}>
            <TextField fullWidth label="Descripcion" {...register('description', { required: true })} />
            {errors.description && (
              <Typography fontSize="13px" color="error">
                Este campo es requerido
              </Typography>
            )}
          </Box>

          <div>
            <LabelStyle>Imagen empaquetado</LabelStyle>
            <UploadSingleFile
              showPreview
              maxSize={3145728}
              accept="image/*"
              file={file.preview}
              onDrop={(filec) => {
                setPData(`${fData(filec[0].size)}`);
                setFile({
                  file: filec[0],
                  preview: URL.createObjectURL(filec[0])
                });
              }}
            />
            <LinearProgress variant="determinate" value={pF} />
            {pData}
          </div>

          <LoadingButton type="submit" loading={isSubmitting} variant="contained" fullWidth>
            Añadir
          </LoadingButton>
        </Card>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
