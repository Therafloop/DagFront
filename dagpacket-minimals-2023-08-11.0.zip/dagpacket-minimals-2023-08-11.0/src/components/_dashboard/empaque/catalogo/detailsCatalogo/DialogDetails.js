import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import EditItemForm from './EditItemForm';

export default function DialogDetails({ dataItem }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <IconButton size="small" onClick={() => setOpenDialog(true)}>
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>

      <DialogBody open={openDialog} onClose={setOpenDialog} dataItem={dataItem} />
    </>
  );
}

function DialogBody({ open, onClose, dataItem }) {
  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle>
      <DialogContent>
        <EditItemForm dataItem={dataItem} />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
