import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import { Icon } from '@iconify/react';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import SelectOptionLayout, { SideItem } from '../../../../../layouts/components/SelectOptionLayout';
import TraspasosList from './1-section/TraspasosList';

export default function DialogSolTraspasoDetail({ dataItem }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <IconButton size="small" onClick={() => setOpenDialog(true)}>
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>
      <DialogBody open={openDialog} onClose={setOpenDialog} dataItem={dataItem} />
    </>
  );
}

function DialogBody({ open, onClose, dataItem }) {
  const [section, setSection] = useState(1);

  const handleClose = () => {
    onClose(false);
  };

  const side = (
    <>
      <SideItem text="Traspasos" section={1} action={setSection} icon={<AccountBalanceWalletIcon />} />
    </>
  );

  const body = (
    <>
      {section === 1 && (
        <>
          <Grid item xs={12}>
            <TraspasosList dataItem={dataItem} />
          </Grid>
        </>
      )}
    </>
  );

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      maxWidth="lg"
      fullWidth
    >
      {/* <DialogTitle id="alert-dialog-title">Titulo del dialogo</DialogTitle> */}
      <DialogContent>
        <SelectOptionLayout sidebar={side} body={body} />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
