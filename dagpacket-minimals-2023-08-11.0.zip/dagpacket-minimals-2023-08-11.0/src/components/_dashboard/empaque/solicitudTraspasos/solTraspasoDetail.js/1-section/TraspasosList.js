import React from 'react';
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import TraspasoTableRow from './TraspasoTableRow';

export default function TraspasosList({ dataItem }) {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell> </TableCell>
            <TableCell>Origen</TableCell>
            {/* <TableCell>Fecha</TableCell> */}
            <TableCell>Producto</TableCell>
            <TableCell>Cantidad</TableCell>
            <TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {dataItem.traspasosIds.map((item) => (
            <TraspasoTableRow itemId={item} key={item} solData={dataItem} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
