import React, { useState } from 'react';
import { Box, Button, IconButton, ListItemIcon, ListItemText, Menu, MenuItem, Typography } from '@mui/material';
import ContentCut from '@mui/icons-material/ContentCut';
import { Icon } from '@iconify/react';
import useEmpaque from '../../../../../../hooks/useEmpaque';
import { useSnackbar } from 'notistack';

function TraspasoOptionMenu({ dataItem, setLoading }) {
  const [anchorEl, setAnchorEl] = useState(null);
  const { recepcionarProductos, cancelarEnvioProducto } = useEmpaque();
  const { enqueueSnackbar } = useSnackbar();
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleRecepcionar = async () => {
    setLoading(true);
    await recepcionarProductos(dataItem.origenId, dataItem.destinoId, dataItem);
    setLoading(false);
    enqueueSnackbar('Operacion exitosa', { variant: 'success' });
  };

  const handleCancelarRecepcion = async () => {
    setLoading(true);
    await cancelarEnvioProducto(dataItem.origenId, dataItem.destinoId, dataItem);
    setLoading(false);
    enqueueSnackbar('Empaques cancelados', { variant: 'success' });
  };

  return (
    <>
      <IconButton
        id="basic-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
        size="small"
      >
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'basic-button'
        }}
      >
        {/* <MenuItem
          disabled={dataItem.status === 'ACEPTADO' || dataItem.status === 'CANCELADO'}
          onClick={handleRecepcionar}
        >
          Aceptar
        </MenuItem> */}
        <MenuItem
          disabled={dataItem.status === 'CANCELADO' || dataItem.status === 'ACEPTADO'}
          onClick={handleCancelarRecepcion}
        >
          Cancelar
        </MenuItem>

        {/* <MenuItem onClick={handleClose}>
          <ListItemIcon>
            <ContentCut fontSize="small" />
          </ListItemIcon>
          <ListItemText>Texto para ver</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleClose}>Logout</MenuItem> */}
      </Menu>
    </>
  );
}

export default TraspasoOptionMenu;
