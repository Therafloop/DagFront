import { CircularProgress, LinearProgress, TableCell, TableRow } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { firestore } from '../../../../../../contexts/FirebaseContext';
import TraspasoOptionMenu from './TraspasoOptionMenu';

function TraspasoTableRow({ itemId, solData }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  console.log(data);

  useEffect(() => {
    function getData() {
      firestore
        .collection('emp_traspasos')
        .doc(itemId)
        .onSnapshot((doc) => setData({ id: doc.id, ...doc.data() }));
    }

    getData();
  }, [itemId]);
  return (
    <>
      {data && (
        <>
          {loading && <LinearProgress />}
          <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
            <TableCell component="th" scope="row">
              <TraspasoOptionMenu dataItem={data} setLoading={setLoading} />
            </TableCell>
            <TableCell component="th" scope="row">
              {data.origenUser}
            </TableCell>
            <TableCell>{data.productoName}</TableCell>
            <TableCell>{data.cantidad}</TableCell>
            <TableCell>{data.status}</TableCell>
          </TableRow>
        </>
      )}
      {!data && null}
    </>
  );
}

export default TraspasoTableRow;
