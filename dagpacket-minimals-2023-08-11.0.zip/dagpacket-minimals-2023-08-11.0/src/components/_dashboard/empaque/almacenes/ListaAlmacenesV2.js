import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import { useState, useEffect } from 'react';
// import plusFill from '@iconify/icons-eva/plus-fill';
// import { Link as RouterLink } from 'react-router-dom';
// material
import { useTheme } from '@mui/material/styles';
import {
  Card,
  Table,
  Stack,
  Avatar,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  IconButton,
  Box,
  Divider,
  Button
} from '@mui/material';
// redux
// routes
// hooks
import useSettings from '../../../../hooks/useSettings';
// components
import Page from '../../../Page';
import Label from '../../../Label';
import Scrollbar from '../../../Scrollbar';
import SearchNotFound from '../../../SearchNotFound';
import { UserListHead, UserListToolbar } from '../../user/list';
import { firestore } from '../../../../contexts/FirebaseContext';
// import { AppLicenciatarios } from '../../components/_dashboard/general-app';
// import WalletUserView from './WalletUserView';
// import DialogUsuarioEditar from './DialogUsuarioEditar';
import { Icon } from '@iconify/react';
import { fCurrency } from '../../../../utils/formatNumber';
import DialogAlmanecDetail from './almacenDetail/DialogAlmanecDetail';

// import EditMenu from './EditMenu';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: '' },
  { id: 'userName', label: 'Usuario', alignRight: false },
  // { id: 'name', label: 'Producto', alignRight: false },
  // { id: 'existencia', label: 'Existencia', alignRight: false },
  // { id: 'minStock', label: 'Stock minimo', alignRight: false }
  { id: 'caja_chica', label: 'Caja chica', alignRight: false },
  { id: 'caja_mediana', label: 'Caja mediana', alignRight: false },
  { id: 'caja_grande', label: 'Caja grande', alignRight: false },
  { id: 'sobre_bolsa', label: 'Sobre o bolsa', alignRight: false },
  { id: 'emplaye', label: 'Emplaye', alignRight: false },
  { id: 'poliburbuja', label: 'Polibirbuja', alignRight: false }
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(array, (_user) => _user?.userName?.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}

// eslint-disable-next-line consistent-return
const getExistenciaItemAlmacen = (items, identificador) => {
  if (identificador === 'caja_chica') {
    const elementId = 'AQ5L98NSgjwD3vcf3hNa';
    const findedItem = items?.find((it) => it.id === elementId);

    if (findedItem) {
      return `${findedItem.existencia} ${findedItem.unidad_medida ? findedItem.unidad_medida : ''} ${
        findedItem?.price_venta ? ` - ${fCurrency(findedItem?.price_venta)}` : ''
      }`;
    }
    return 0;
  }
  if (identificador === 'caja_mediana') {
    const elementId = '7Jbmm7s6dO8dQbLNx862';
    const findedItem = items?.find((it) => it.id === elementId);

    if (findedItem) {
      return `${findedItem.existencia} ${findedItem.unidad_medida ? findedItem.unidad_medida : ''} ${
        findedItem?.price_venta ? ` - ${fCurrency(findedItem?.price_venta)}` : ''
      }`;
    }
    return 0;
  }
  if (identificador === 'caja_grande') {
    const elementId = 'vxjlHFJsHNlQLVigD6ut';
    const findedItem = items?.find((it) => it.id === elementId);

    if (findedItem) {
      return `${findedItem.existencia} ${findedItem.unidad_medida ? findedItem.unidad_medida : ''} ${
        findedItem?.price_venta ? ` - ${fCurrency(findedItem?.price_venta)}` : ''
      }`;
    }
    return 0;
  }
  if (identificador === 'bolsa_sobre') {
    const elementId = 'ht6iW0ZhlSbxQFT5Fiya';
    const findedItem = items?.find((it) => it.id === elementId);

    if (findedItem) {
      return `${findedItem.existencia} ${findedItem.unidad_medida ? findedItem.unidad_medida : ''} ${
        findedItem?.price_venta ? ` - ${fCurrency(findedItem?.price_venta)}` : ''
      }`;
    }
    return 0;
  }
  if (identificador === 'emplaye') {
    const elementId = 'f5QJ2DH8MM9BGZ12vkUY';
    const findedItem = items?.find((it) => it.id === elementId);

    if (findedItem) {
      return `${findedItem.existencia} ${findedItem.unidad_medida ? findedItem.unidad_medida : ''} ${
        findedItem?.price_venta ? ` - ${fCurrency(findedItem?.price_venta)}` : ''
      }`;
    }
    return 0;
  }
  if (identificador === 'poliburbuja') {
    const elementId = 'RnEJ7J7VtwJFR082UIox';
    const findedItem = items?.find((it) => it.id === elementId);

    if (findedItem) {
      return `${findedItem.existencia} ${findedItem.unidad_medida ? findedItem.unidad_medida : ''} ${
        findedItem?.price_venta ? ` - ${fCurrency(findedItem?.price_venta)}` : ''
      }`;
    }
    return 0;
  }
};

export default function ListaAlmacenesV2() {
  const theme = useTheme();
  const [dataTable, setDataTable] = useState([]);
  //   const { userList } = useSelector((state) => state.dagpacket);
  //   const [userListLocal, setUserListLocal] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState('');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    async function getData() {
      await firestore.collection('emp_almacenes').onSnapshot((snapshot) => {
        // const dataArr = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        // console.log('esta es la lista------------', dataArr);

        const dataArr = [];

        snapshot.forEach((alm) => {
          console.log(alm.data());
          dataArr.push({ id: alm.id, ...alm.data() });
        });

        console.log('la nueva tabbla', dataArr);
        setDataTable(dataArr);
      });
    }
    getData();
  }, []);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = dataTable.map((n) => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - dataTable.length) : 0;

  const filteredDataTable = applySortFilter(dataTable, getComparator(order, orderBy), filterName);

  const isUserNotFound = filteredDataTable.length === 0;

  // const asd = () => {
  //   firestore.collection('empaquetado').doc("xNxbNyux8QuPCdgFOpN2").delete();
  // };

  return (
    <Card>
      {/* <Button onClick={asd}>asd</Button> */}
      <Box padding="10px 15px">
        <Typography variant="subtitle1" fontSize="25px">
          Almacenes
        </Typography>
        <Divider />
      </Box>
      <UserListToolbar numSelected={selected.length} filterName={filterName} onFilterName={handleFilterByName} />

      <Scrollbar>
        <TableContainer sx={{ minWidth: 800 }}>
          <Table>
            <UserListHead
              order={order}
              orderBy={orderBy}
              headLabel={TABLE_HEAD}
              rowCount={dataTable.length}
              numSelected={selected.length}
              onRequestSort={handleRequestSort}
              onSelectAllClick={handleSelectAllClick}
              checkboxOption={false}
            />
            <TableBody>
              {filteredDataTable.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                const { id, img, userName, existencia, name, minStock, productoItems, userId } = row;
                const isItemSelected = selected.indexOf(name) !== -1;
                return (
                  <TableRow
                    hover
                    key={id}
                    tabIndex={-1}
                    role="checkbox"
                    selected={isItemSelected}
                    aria-checked={isItemSelected}
                  >
                    <TableCell component="th" scope="row">
                      <DialogAlmanecDetail dataItem={row} />
                    </TableCell>
                    <TableCell component="th" scope="row">
                      {userName}
                    </TableCell>
                    {/* <TableCell component="th" scope="row">
                      {name}
                    </TableCell> */}
                    {/* <TableCell component="th" scope="row">
                      {existencia}
                    </TableCell>
                    <TableCell component="th" scope="row">
                      {minStock}
                    </TableCell> */}

                    <TableCell>{getExistenciaItemAlmacen(productoItems, 'caja_chica')}</TableCell>
                    <TableCell>{getExistenciaItemAlmacen(productoItems, 'caja_mediana')}</TableCell>
                    <TableCell>{getExistenciaItemAlmacen(productoItems, 'caja_grande')}</TableCell>
                    <TableCell>{getExistenciaItemAlmacen(productoItems, 'bolsa_sobre')}</TableCell>
                    <TableCell>{getExistenciaItemAlmacen(productoItems, 'emplaye')}</TableCell>
                    <TableCell>{getExistenciaItemAlmacen(productoItems, 'poliburbuja')}</TableCell>

                    {/* <TableCell align="left">{status}</TableCell> */}
                  </TableRow>
                );
              })}
              {emptyRows > 0 && (
                <TableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
            {isUserNotFound && (
              <TableBody>
                <TableRow>
                  <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                    <SearchNotFound searchQuery={filterName} />
                  </TableCell>
                </TableRow>
              </TableBody>
            )}
          </Table>
        </TableContainer>
      </Scrollbar>

      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={filteredDataTable.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Card>
  );
}
