import { LoadingButton } from '@mui/lab';
import { Box, Card, TextField, Typography } from '@mui/material';
import { useSnackbar } from 'notistack';
import React from 'react';
import { useForm } from 'react-hook-form';
import { firestore } from '../../../../../../contexts/FirebaseContext';

function ItemForm({ item, dataAlmacen, handleClose }) {
  const { enqueueSnackbar } = useSnackbar();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting }
  } = useForm({
    defaultValues: {
      existencia: item.existencia || null,
      minStock: item.minStock || null,
      price_compra: item.price_compra || null,
      price_venta: item.price_venta || null
    }
  });

  const onSubmit = async (dataForm) => {
    let productosArr = [...dataAlmacen.productoItems];

    const obj = { ...item, price_venta: Number(dataForm.price_venta), minStock: Number(dataForm.minStock) };
    const filtered = productosArr.filter((it) => it.id !== obj.id);

    productosArr = [...filtered, obj];

    // console.log(item, dataForm, obj, dataAlmacen, productosArr);

    try {
      await firestore.collection('emp_almacenes').doc(dataAlmacen.id).update({ productoItems: productosArr });
      enqueueSnackbar('Cambios guardados', { variant: 'success' });
      handleClose();
    } catch (error) {
      enqueueSnackbar('Se produjo un error', { variant: 'error' });
    }
  };
  return (
    <Card sx={{ padding: '10px' }} component="form" onSubmit={handleSubmit(onSubmit)}>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField disabled label="Existencia" {...register('existencia', { required: true })} />
        {errors.existencia && (
          <Typography color="error" fontSize="13px">
            Este campo es requerido
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField disabled label="Precio compra" {...register('price_compra', { required: true })} />
        {errors.price_compra && (
          <Typography color="error" fontSize="13px">
            Este campo es requerido
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField label="Precio de venta" {...register('price_venta', { required: true })} />
        {errors.price_venta && (
          <Typography color="error" fontSize="13px">
            Este campo es requerido
          </Typography>
        )}
      </Box>
      <Box sx={{ marginBottom: '10px' }}>
        <TextField label="Min stock" {...register('minStock', { required: true })} />
        {errors.minStock && (
          <Typography color="error" fontSize="13px">
            Este campo es requerido
          </Typography>
        )}
      </Box>

      <LoadingButton loading={isSubmitting} type="submit" variant="contained" fullWidth>
        aceptar
      </LoadingButton>
    </Card>
  );
}

export default ItemForm;
