import { filter } from 'lodash';
import { sentenceCase } from 'change-case';
import { useState, useEffect } from 'react';
// import plusFill from '@iconify/icons-eva/plus-fill';
// import { Link as RouterLink } from 'react-router-dom';
// material
import { useTheme } from '@mui/material/styles';
import {
  Card,
  Table,
  Stack,
  Avatar,
  Checkbox,
  TableRow,
  TableBody,
  TableCell,
  Container,
  Typography,
  TableContainer,
  TablePagination,
  IconButton,
  Box,
  Divider,
  Button
} from '@mui/material';
// redux
import { useDispatch, useSelector } from '../../../../../../redux/store';
import { deleteUser } from '../../../../../../redux/slices/user';
import { setUserList } from '../../../../../../redux/slices/dagpacket';
// routes
// hooks
import useSettings from '../../../../../../hooks/useSettings';
// components
import Page from '../../../../../Page';
import Label from '../../../../../Label';
import Scrollbar from '../../../../../Scrollbar';
import SearchNotFound from '../../../../../SearchNotFound';
import { UserListHead, UserListToolbar } from '../../../../user/list';
import { firestore } from '../../../../../../contexts/FirebaseContext';
// import { AppLicenciatarios } from '../../components/_dashboard/general-app';
import RoleView from '../../../../user/RoleView';
// import WalletUserView from './WalletUserView';
// import DialogUsuarioEditar from './DialogUsuarioEditar';
import { Icon } from '@iconify/react';
import useAuthUsers from '../../../../../../hooks/useAuthUsers';
import { fCurrency } from '../../../../../../utils/formatNumber';
import DialogItemInventario from './DialogItemInventario';
// import EditMenu from './EditMenu';

// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: '' },
  { id: 'name', label: 'Nombre', alignRight: false },
  { id: 'price_venta', label: 'Precio venta', alignRight: false },
  { id: 'existencia', label: 'Cantidad disp.', alignRight: false }
];

// ----------------------------------------------------------------------

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

function applySortFilter(array, comparator, query) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  if (query) {
    return filter(array, (_user) => _user?.displayName?.toLowerCase().indexOf(query.toLowerCase()) !== -1);
  }
  return stabilizedThis.map((el) => el[0]);
}

// const userList = [];

export default function InventarioList({ dataAlmacen }) {
  const theme = useTheme();
  const dispatch = useDispatch();
  const [dataTable, setDataTable] = useState([]);
  //   const { userList } = useSelector((state) => state.dagpacket);
  //   const [userListLocal, setUserListLocal] = useState([]);
  const [page, setPage] = useState(0);
  const [order, setOrder] = useState('asc');
  const [selected, setSelected] = useState([]);
  const [orderBy, setOrderBy] = useState('name');
  const [filterName, setFilterName] = useState('');
  const [rowsPerPage, setRowsPerPage] = useState(5);

  //   const { currentUser } = useAuthUsers();

  useEffect(() => {
    setDataTable(dataAlmacen.productoItems);
  }, [dataAlmacen.productoItems]);

  //   useEffect(() => {
  //     firestore
  //       .collection('emp_almacenes')
  //       .doc(currentUser.almacenId)
  //       .onSnapshot((doc) => {
  //         if (doc.exists) {
  //           console.log(doc.data());
  //           setDataTable(doc.data().productoItems);
  //         }
  //       });
  //   }, [currentUser.almacenId]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = dataTable.map((n) => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(selected.slice(0, selectedIndex), selected.slice(selectedIndex + 1));
    }
    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleFilterByName = (event) => {
    setFilterName(event.target.value);
    console.log(filterName);
  };

  const handleDeleteUser = (userId) => {
    dispatch(deleteUser(userId));
  };

  const emptyRows = page > 0 ? Math.max(0, (1 + page) * rowsPerPage - dataTable.length) : 0;

  const filteredDataTable = applySortFilter(dataTable, getComparator(order, orderBy), filterName);

  const isUserNotFound = filteredDataTable.length === 0;

  // const asd = () => {
  //   firestore.collection('empaquetado').doc("xNxbNyux8QuPCdgFOpN2").delete();
  // };

  return (
    <Card>
      {/* <Button onClick={asd}>asd</Button> */}
      {/* <Box padding="10px 15px">
        <Typography variant="subtitle1" fontSize="25px">
          Almacen
        </Typography>
        <Divider />
      </Box> */}
      <UserListToolbar numSelected={selected.length} filterName={filterName} onFilterName={handleFilterByName} />

      <Scrollbar>
        <TableContainer sx={{ minWidth: 800 }}>
          <Table>
            <UserListHead
              order={order}
              orderBy={orderBy}
              headLabel={TABLE_HEAD}
              rowCount={dataTable.length}
              numSelected={selected.length}
              onRequestSort={handleRequestSort}
              onSelectAllClick={handleSelectAllClick}
              checkboxOption={false}
            />
            <TableBody>
              {filteredDataTable.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                const { id, img, existencia, name, status = 'active', price_compra, price_venta } = row;
                const isItemSelected = selected.indexOf(name) !== -1;
                return (
                  <TableRow
                    hover
                    key={id}
                    tabIndex={-1}
                    role="checkbox"
                    selected={isItemSelected}
                    aria-checked={isItemSelected}
                  >
                    <TableCell align="left">
                      <DialogItemInventario item={row} dataAlmacen={dataAlmacen} />
                    </TableCell>
                    <TableCell component="th" scope="row" padding="none">
                      <Stack direction="row" alignItems="center" spacing={2}>
                        {/* <Avatar alt={displayName} src={photoURL} /> */}
                        <Avatar alt="caja chica" src={img} sx={{ width: 56, height: 56 }} />
                        <Typography variant="subtitle2" noWrap>
                          {name}
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell align="left">{fCurrency(price_venta)}</TableCell>
                    <TableCell align="left">{existencia}</TableCell>
                  </TableRow>
                );
              })}
              {emptyRows > 0 && (
                <TableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
            {isUserNotFound && (
              <TableBody>
                <TableRow>
                  <TableCell align="center" colSpan={6} sx={{ py: 3 }}>
                    <SearchNotFound searchQuery={filterName} />
                  </TableCell>
                </TableRow>
              </TableBody>
            )}
          </Table>
        </TableContainer>
      </Scrollbar>

      <TablePagination
        rowsPerPageOptions={[5, 10, 25]}
        component="div"
        count={filteredDataTable.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </Card>
  );
}
