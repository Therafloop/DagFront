import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import ItemForm from './ItemForm';

export default function DialogItemInventario({ item, dataAlmacen }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <IconButton onClick={() => setOpenDialog(true)} size="small">
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>
      <DialogBody open={openDialog} onClose={setOpenDialog} item={item} dataAlmacen={dataAlmacen} />
    </>
  );
}

function DialogBody({ open, onClose, item, dataAlmacen }) {
  const handleClose = () => {
    onClose(false);
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle textAlign="center" id="alert-dialog-title">
        {item.name}
      </DialogTitle>
      <DialogContent>
        <ItemForm item={item} dataAlmacen={dataAlmacen} handleClose={handleClose} />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
