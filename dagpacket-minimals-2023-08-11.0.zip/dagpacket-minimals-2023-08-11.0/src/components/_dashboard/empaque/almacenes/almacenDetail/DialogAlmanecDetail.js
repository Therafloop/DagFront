import React, { useState } from 'react';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, Typography } from '@mui/material';
import { Box } from '@mui/system';
import { Icon } from '@iconify/react';
import SelectOptionLayout, { SideItem } from '../../../../../layouts/components/SelectOptionLayout';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import InventarioList from './1-section/InventarioList';

export default function DialogAlmanecDetail({ dataItem }) {
  const [openDialog, setOpenDialog] = useState(false);

  return (
    <>
      <IconButton onClick={() => setOpenDialog(true)} size="small">
        <Icon icon="eva:more-vertical-fill" />
      </IconButton>
      <DialogBody open={openDialog} onClose={setOpenDialog} dataItem={dataItem} />
    </>
  );
}

function DialogBody({ open, onClose, dataItem }) {
  const [section, setSection] = useState(1);

  console.log(dataItem, dataItem.created_date.toDate(), dataItem.updated_date.toDate());

  const handleClose = () => {
    onClose(false);
  };

  const side = (
    <>
      <SideItem text="Inventario" section={1} action={setSection} icon={<AccountBalanceWalletIcon />} />
    </>
  );

  const body = (
    <>
      {section === 1 && (
        <>
          <Grid item xs={12}>
            <InventarioList dataAlmacen={dataItem} />
          </Grid>
        </>
      )}
    </>
  );

  return (
    <Dialog
      maxWidth="lg"
      fullWidth
      open={open}
      onClose={handleClose}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
    >
      <DialogTitle textAlign="center" id="alert-dialog-title">
        Almacen - {dataItem.userName}
      </DialogTitle>
      <DialogContent>
        <SelectOptionLayout sidebar={side} body={body} />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="inherit" startIcon={<Icon icon="eva:arrow-back-fill" />}>
          Atras
        </Button>
      </DialogActions>
    </Dialog>
  );
}
