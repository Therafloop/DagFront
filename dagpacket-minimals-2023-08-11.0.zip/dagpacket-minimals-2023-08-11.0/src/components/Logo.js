import PropTypes from 'prop-types';
// material
import { Box } from '@mui/material';
import Img from '../assets/dagpacketd.png';

// ----------------------------------------------------------------------

Logo.propTypes = {
  sx: PropTypes.object
};

export default function Logo({ sx }) {
  return <Box sx={{ width: 40, height: 40, ...sx }} component="img" src={Img} />;
  // return <Box sx={{ width: '95%', height: 40, ...sx }} component="img" src="/favicon/dagPacket-logo.png" />;
}
