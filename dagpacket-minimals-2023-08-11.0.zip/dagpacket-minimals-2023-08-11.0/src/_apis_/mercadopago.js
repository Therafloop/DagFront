import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';
import { TERMINAL_ERRORS } from '../constants/mercadopago';
import { actionSectionIdentifier, sectionIdentifier, statusAction } from '../constants/ticketsErrors';
import { firestore } from '../contexts/FirebaseContext';
import { getServerUrlServPlatform } from './getServerUrl';

// const backendServerURL = isProduction ? backendURL : backendURLSandbox;
const backendServerURL = getServerUrlServPlatform();

const reportError = async (dataError) => {
  await firestore.collection('errorReports').add(dataError);
};

const conn = axios.create({
  baseURL: backendServerURL,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    Authorization: 'dagtoken'
  }
});

export const createMPToken = async (empresaId = '', keys = {}, userId = '') => {
  try {
    await conn.post(`/pagos/${empresaId}/mercadopago/token`, {
      ...keys
    });
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.crearMPToken,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al crear el token de mercadopago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error(error);
  }
};

/**
 *
 * @param {string} empresaId
 * @param {PreferenciaItem[]} items
 * @param {[key: string]: string} back_urls
 * @param {string: string} external_reference
 * @returns
 */
export const createMPPreference = async (
  { back_urls = {}, empresaId = '', items = [], external_reference = '' },
  userId = ''
) => {
  try {
    const { data } = await conn.post(`/pagos/${empresaId}/mercadopago/preference`, {
      items,
      back_urls,
      external_reference
    });
    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.crearMpPreferece,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al crear la referencia de mercadopago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error al crear la preferencia');
  }
};

export const getPayment = async ({ empresaId = '', idPayment = '' }, userId = '') => {
  try {
    const { data } = await conn.get(`/pagos/${empresaId}/mercadopago/status/${idPayment}`);
    console.log({ response21Get: data?.body });
    return data?.body;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.getPayment,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al consultar el pago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error al consultar el pago');
  }
};

export const getPaymentByExternalReference = async (empresaId = '', external_referencia = '', userId = '') => {
  try {
    const { data } = await conn.get(`/pagos/${empresaId}/mercadopago/paymentByPreference/${external_referencia}`);

    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.getPaymentByExternalReference,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al crear la preferencia',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error al crear la preferencia');
  }
};

export const cancelPayment = async ({ empresaId = '', idPayment = '' }, userId = '') => {
  try {
    const { data } = await conn.delete(`/pagos/${empresaId}/mercadopago/payments/${idPayment}`, {
      headers: {
        Authorization: 'superToken'
      }
    });

    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.cancelPayment,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al cancelar el pago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error al cancelar el pago');
  }
};

export const createRefund = async ({ empresaId = '', idPayment = '', amount = null }, userId = '') => {
  try {
    const { data } = await conn.post(`/pagos/${empresaId}/mercadopago/refunds/${idPayment}`);

    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.crearReembolso,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al reembolsar pagos',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error al reembolsar pagos');
  }
};

export const getDevices = async (empresaId = '', limit = 50, offset = 0, userId = '') => {
  try {
    const { data } = await conn.get(`/pagos/${empresaId}/mercadopago/devices?limit=${limit}&offset=${offset}`);
    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.getDevices,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al obtener los dispositivos',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error al obtener los dispositivos');
  }
};

export const getPaymentPoint = async (empresaId = '', paymentId = '', userId = '') => {
  try {
    const { data } = await conn.get(`/pagos/${empresaId}/mercadopago/payment-intents/${paymentId}`);
    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.getPaymentPoint,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error obtener la intencion de  pago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error obtener la intencion de  pago');
  }
};

export const createPaymentIntents = async (
  empresaId = '',
  { amount = 0, deviceId = '', externalReference = '', printOnTerminal = false, lockerId = '' },
  userId = ''
) => {
  if (lockerId) activateTerminalScreen(lockerId);
  try {
    const { data } = await conn.post(`/pagos/${empresaId}/mercadopago/payment-intents`, {
      amount,
      deviceId,
      externalReference,
      printOnTerminal
    });

    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.intentosDePago,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al crear los intentos de pago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    const data = error?.response?.data;
    data.message = TERMINAL_ERRORS[data.message];
    return data;
  }
};

export const cancelPaymentIntents = async (empresaId = '', paymentId = '', deviceId = '', userId = '') => {
  try {
    const { data } = await conn.delete(`/pagos/${empresaId}/mercadopago/payment-intents`, {
      data: {
        paymentId,
        deviceId
      }
    });

    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.cencelarIntentosPago,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al cancelar los intentos de pago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    const data = error?.response?.data;
    const errorKeys = Object.keys(TERMINAL_ERRORS);
    errorKeys.forEach((key, userId = '') => {
      if (data?.message && data?.message?.includes(key)) {
        data.message = TERMINAL_ERRORS[key];
      }
    });
    return data;
  }
};

/**
 *
 * @param {string} empresaId
 * @param {'PDV' | 'STANDALONE'} operatingMode
 * @param {string} deviceId
 * @returns
 */

export const changeOperationMode = async (empresaId = '', operatingMode = 'PDV', deviceId = '', userId = '') => {
  try {
    const { data } = await conn.post(`/pagos/${empresaId}/mercadopago/changeOperationMode`, {
      operatingMode,
      deviceId
    });

    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.cambiarModoDeOperacion,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Cambiando modo de operacion',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    return error?.response?.data;
  }
};

export const getPaymentPointState = async (empresaId = '', paymentId = '', userId = '') => {
  try {
    const { data } = await conn.get(`/pagos/${empresaId}/mercadopago/payment-intents/lastState/${paymentId}`);
    return data;
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.estadoPuntoDePago,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error obtener el estado del Pago',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    throw new Error('Error obtener el estado del Pago');
  }
};

export const activateTerminalScreen = async (lockerId = '', userId = '') => {
  try {
    conn.post(`/lockers/${lockerId}/power`);
  } catch (error) {
    const errorData = {
      error: JSON.stringify(error),
      errorAction: actionSectionIdentifier.statusDePantalla,
      section: sectionIdentifier.mercadoPago,
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al activar status de la pantalla',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    };
    console.log(errorData);

    await reportError(errorData);
    console.log(error);
  }
};
