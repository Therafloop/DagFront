const workMode = localStorage.getItem('workmode') || 'deploy';

// eslint-disable-next-line consistent-return
export const getServerUrlServPlatform = () => {
  if (workMode === 'development') {
    const dataArr = localStorage.getItem('urlBackLocal');
    const findedObj = JSON.parse(dataArr)?.find((it) => it.section === 'service_platform');

    return findedObj?.URL;
  }
  if (workMode === 'deploy') {
    const dataArr = localStorage.getItem('urlBackDeploy');
    const findedObj = JSON.parse(dataArr)?.find((it) => it.section === 'service_platform');

    return findedObj?.URL;
  }
};

// eslint-disable-next-line consistent-return
export const getServerUrlLocker = () => {
  if (workMode === 'development') {
    const dataArr = localStorage.getItem('urlBackLocal');
    const findedObj = JSON.parse(dataArr)?.find((it) => it.section === 'locker');

    return findedObj?.URL;
  }
  if (workMode === 'deploy') {
    const dataArr = localStorage.getItem('urlBackDeploy');
    const findedObj = JSON.parse(dataArr)?.find((it) => it.section === 'locker');

    return findedObj?.URL;
  }
};
