import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';

const backendServerURL = isProduction ? backendURL : backendURLSandbox;

const backend = axios.create({
  baseURL: backendServerURL
});

export async function getTracking(paquetería, codigo) {
  return new Promise((resolve, reject) => {
    backend
      .get(`/rastreo/${paquetería}/${codigo}`)
      .then((response) => {
        console.log(response.data);
        resolve(response.data);
      })
      .catch((error) => {
        reject(error);
      });
  });
}
