import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';

const backendServerURL = isProduction ? backendURL : backendURLSandbox;

const conn = axios.create({
  baseURL: `${backendServerURL}/notifications`
});

export async function suscribePushNotifications(keys, userid) {
  const data = conn.post(`/suscribe/${userid}`, keys, {});
  return data;
}

export async function sendNotificationByRoleAPI(role = '', notification = { title: '', message: '' }) {
  const data = conn.post(`/new-message/role/${role}`, notification, {});
  return data;
}

export async function sendNotificationByUserAPI(userid = '', notification = { title: '', message: '' }) {
  const data = conn.post(`/new-message/user/${userid}`, notification, {});
  return data;
}

export async function sendNotificationEveryone(notification = { title: '', message: '' }) {
  const data = conn.post(`/new-message/everyone`, notification, {});
  return data;
}
