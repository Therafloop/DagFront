import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';

const backendServerURL = isProduction ? backendURL : backendURLSandbox;

const conn = axios.create({
  baseURL: `${backendServerURL}/pagos`,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    Authorization: 'dagtoken'
  }
});

export async function createPreference(items = [], back_urls = {}) {
  const resp = await conn.post('/mercadopago/preference', {
    items,
    back_urls,
    auto_return: 'approved'
  });
  console.log(resp.data.body.id);
  return resp.data.body.id;
}
