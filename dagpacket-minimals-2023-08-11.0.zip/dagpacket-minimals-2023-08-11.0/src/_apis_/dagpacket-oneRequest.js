import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';
import { getServerUrlServPlatform } from './getServerUrl';

// const backendServerURL = isProduction ? backendURL : backendURLSandbox;
const backendServerURL = getServerUrlServPlatform();

// const getBaseUrl = () => {
//   const actualOrigin = localStorage.getItem('originBack');
//   if (actualOrigin === 'sandbox') {
//     return backendURLSandbox;
//   }
//   if (actualOrigin === 'production') {
//     return backendURL;
//   }
//   return backendURL;
// };

const conn = axios.create({
  baseURL: backendServerURL,
  headers: {
    'Content-Type': 'application/json',
    // 'User-Agent': 'dagpacket-frontend',
    Accept: 'application/json',
    Authorization: 'dagtoken'
  }
});

export async function cotizarEnvio(data) {
  const res = await conn.post('/paquetes/cotizar006', data);
  return res.data;
}

// ========== cotizar solo vencedor  ==================
export async function cotizarEnvioVencedor(data) {
  const res = await conn.post('/paquetes/vencedor/cotizar', data);
  return res.data;
}

export async function comprarGuia(data, provider) {
  const res = await conn.post(`/paquetes/${provider}`, data);
  return res.data;
}

export async function rastreoPaqueteria(rate_provider, trackingNum) {
  const res = await conn.get(`rastreo/${rate_provider}/${trackingNum}`);
  return res.data;
}

export async function nombrePaqRastreo() {
  const res = await conn.get('rastreo');
  return res.data;
}

export async function updateEstadoEnvio(dagpacketCode) {
  const res = await conn.post(`/paquetes/superenvios/update`, {
    dagpacketCode
  });
  return res.data;
}

export async function getReporteIntervalo(intervalo, endPoint = '/reports/utilidades') {
  const res = await conn.post(endPoint, intervalo);
  return res.data;
}

export async function getReporteLicenciatarios(date_from = '2023-05-16', date_to = '2023-05-31') {
  const userIds = [];
  const compact = true;
  const status = 'CREATED';

  // const res = await conn.post('/rastreo/reporte', { date_from, date_to, userIds, compact, status });
  const res = await conn.post('/reports/utilidades', { date_from, date_to, userIds, compact, status });
  return res.data;
}

/**

Obtiene el reporte de wallets basado en un intervalo de tiempo 
@async
@function
@param {Object} intervalo - Objeto que contiene el intervalo de tiempo para el reporte.
@param {string} intervalo.date_from - Fecha de inicio del intervalo en formato "YYYY-MM-DD".
@param {string} intervalo.date_to - Fecha de finalización del intervalo en formato "YYYY-MM-DD".
@returns {Promise<Object[]>} Retorna una promesa que se resuelve en un array de objetos que representan el reporte de empaque.
@example
intervalo={
date_from: "2023-01-01",
date_to: "2023-04-05"}
getReporteWallets(intervalo)
*/

export async function getReporteWallets(
  intervalo = {
    date_from: '2022-02-01',
    date_to: '2023-03-31'
  }
) {
  // const res = await conn.post('/utils/reporte-wallets', intervalo);
  const res = await conn.post('/reports/wallets ', intervalo);
  return res.data;
}

/**

Obtiene el reporte de empaque basado en un intervalo de tiempo y, opcionalmente, un conjunto de ID's.
@async
@function
@param {Object} intervalo - Objeto que contiene el intervalo de tiempo para el reporte.
@param {string} intervalo.date_from - Fecha de inicio del intervalo en formato "YYYY-MM-DD".
@param {string} intervalo.date_to - Fecha de finalización del intervalo en formato "YYYY-MM-DD".
@param {string[]} [intervalo.ids] - Opcional. Array de ID's para filtrar el reporte. Si no se proporciona, se incluirán todos los registros en el intervalo de tiempo.
@returns {Promise<Object[]>} Retorna una promesa que se resuelve en un array de objetos que representan el reporte de empaque.
@example
intervalo={
date_from: "2023-01-01",
date_to: "2023-04-05"}
userIds = ["n6oa4FnwekcTqGhb6s3SHnSbGXE2","suMokhIw84fGxNBXFgCcm8327Gf2"]
getReporteEmpaque({intervalo,userIds})
*/
export async function getReporteEmpaque(intervalo, userIds = []) {
  // const res = await conn.post('/utils/reporte-empaque', intervalo);
  const res = await conn.post('/reports/empaque', intervalo);
  return res.data;
}
export async function getReporteUtilidadesLicen(intervalo, userIds = [], status = 'CREATED', compact = true) {
  const requestBody = {
    ...intervalo,
    userIds,
    status,
    compact
  };

  const res = await conn.post('/reports/utilidades', requestBody);
  return res.data;
}

export async function getColoniasVencedor(zipCode) {
  const res = await conn.get(`/paquetes/vencedor/colonias/${zipCode}`);
  return res;
}
/**

Obtiene el reporte de empaque basado en un intervalo de tiempo y, opcionalmente, un conjunto de ID's.
@async
@function
@param {Object} intervalo - Objeto que contiene el intervalo de tiempo para el reporte.
@param {string} intervalo.date_from - Fecha de inicio del intervalo en formato "YYYY-MM-DD".
@param {string} intervalo.date_to - Fecha de finalización del intervalo en formato "YYYY-MM-DD".
@param {string} enpoint - endpoint a donde se realizará la petición en formato "/<enpoint>"
@param {string[]} [intervalo.ids] - Opcional. Array de ID's para filtrar el reporte. Si no se proporciona, se incluirán todos los registros en el intervalo de tiempo.
@returns {Promise<Object[]>} Retorna una promesa que se resuelve en un array de objetos que representan el reporte de empaque.
@example
intervalo={
date_from: "2023-01-01",
date_to: "2023-04-05"}, "/utils/reporteCupones"
userIds = ["n6oa4FnwekcTqGhb6s3SHnSbGXE2","suMokhIw84fGxNBXFgCcm8327Gf2"]
getReporteEmpaque({intervalo,userIds})
*/
export async function getReporteVarios(intervalo, endPoint, userIds = [], saveReport = true) {
  const body = { ...intervalo, userIds, saveReport };
  const res = await conn.post(endPoint, body);
  return res;
}

/**
 * Obtiene el reporte de utilidades basado en un intervalo de tiempo, un estado y, opcionalmente, un conjunto de ID's de usuario.
 * @async
 * @function
 * @param {Object} rangoFechas - Objeto que contiene el intervalo de tiempo para el reporte.
 * @param {string} rangoFechas.date_from - Fecha de inicio del intervalo en formato "YYYY-MM-DD".
 * @param {string} rangoFechas.date_to - Fecha de finalización del intervalo en formato "YYYY-MM-DD".
 * @param {string[]} [userIds] - Opcional. Array de ID's de usuario para filtrar el reporte. Si no se proporciona, se incluirán todos los registros en el intervalo de tiempo.
 * @param {string} status - Estado para el reporte.
 * @returns {Promise<Object[]>} Retorna una promesa que se resuelve en un array de objetos que representan el reporte de utilidades.
 * @example
 * rangoFechas={
 *   date_from: "2023-06-01",
 *   date_to: "2023-06-15"
 * },
 * status = "CREATED",
 * userIds = ["n6oa4FnwekcTqGhb6s3SHnSbGXE2", "suMokhIw84fGxNBXFgCcm8327Gf2"]
 * getReporteUtilidades(rangoFechas, status, userIds)
 */
export async function getReporteUtilidades(rangoFechas, userId = '', status = 'CREATED') {
  const body = {
    ...rangoFechas,
    compact: true,
    status
  };

  const res = await conn.post(`/reports/utilidades/${userId}`, body);
  return res.data;
}
