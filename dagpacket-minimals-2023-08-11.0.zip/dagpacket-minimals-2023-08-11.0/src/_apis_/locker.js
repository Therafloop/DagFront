import axios from 'axios';
import { locker, backendURL } from '../config';

const conn = axios.create({
  baseURL: locker,
  headers: {
    'Content-Type': 'application/json',
    // 'User-Agent': 'dagpacket-frontend',
    Accept: 'application/json',
    Authorization: 'dagtoken'
  }
});

export async function scanLocker(letter, number) {
  const res = await conn.post('/box/scan', {
    Box: [letter, number]
  });
  return res.data;
}

export async function openLocker(letter, number) {
  const res = await conn.post('/box/open', {
    Box: [letter, number]
  });
  return res.data;
}

export async function gatWeight() {
  const res = await conn.get('/scale/weight');
  return res.data;
}

export async function getDimensions() {
  const res = await conn.get('/dimensions');
  return res.data;
}

export async function setDimensions() {
  const res = await conn.post('/dimensions/setpoint');
  return res.data;
}

export async function tareScale() {
  const res = await conn.post('/scale/tare');
  return res.data;
}

export async function getBestFitLocker(data) {
  const res = await conn.post(`${backendURL}/lockers/best-fit`, data);
  return res.data;
}

export async function getQueueItems() {
  const res = await conn.get(`/box/queue`);
  return res.data;
}

export async function deleteQueueItems() {
  const res = await conn.delete(`/box/queue`);
  return res.data;
}
