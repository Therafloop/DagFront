import { firestore } from '../contexts/FirebaseContext';
import uniqid from 'uniq-id';

const moment = require('moment');
// const uniqid = require('uniq-id');

export async function generateSingleUseToken(userid = 'anon', privLevel = 1, minutos = 3) {
  const idRaw = uniqid.generateUUID(`${privLevel}-front-once-xxx-xxx`, 10)();

  const newDateExpire = moment().add(minutos, 'minutes').toDate();

  const newToken = {
    descripcion: `token de uso unico para el id: ${userid}`,
    expires: newDateExpire,
    privlevel: privLevel || 1,
    unlimited: false,
    userid,
    uses: 1
  };
  return new Promise((resolve, reject) => {
    firestore
      .collection('tokens')
      .doc(idRaw)
      .set(newToken)
      .then(() => {
        setTimeout(() => {
          resolve(idRaw);
        }, 500);
      })
      .catch((err) => {
        reject(err);
      });
  });
}

export async function generateTokenUserPriv3(userid = '', minutos = 3) {
  const idRaw = uniqid.generateUUID(`${userid}-3-xxx-xxx`, 10)();

  const newDateExpire = moment().add(minutos, 'minutes').toDate();

  const newToken = {
    descripcion: `token de uso unico para el id: ${userid}`,
    expires: newDateExpire,
    privlevel: 3,
    unlimited: false,
    userid,
    uses: 1
  };
  return new Promise((resolve, reject) => {
    firestore
      .collection('tokens')
      .doc(idRaw)
      .set(newToken)
      .then(() => {
        setTimeout(() => {
          resolve(idRaw);
        }, 500);
      })
      .catch((err) => {
        reject(err);
      });
  });
}

export async function generateReadToken(userid = '', minutos = 1) {
  const idRaw = uniqid.generateUUID(`1-read-xxx-xxx`, 10)();

  const newDateExpire = moment().add(minutos, 'minutes').toDate();

  const newToken = {
    descripcion: `token de uso unico para el id: ${userid}`,
    expires: newDateExpire,
    privlevel: 1,
    unlimited: false,
    userid,
    uses: 1
  };
  return new Promise((resolve, reject) => {
    firestore
      .collection('tokens')
      .doc(idRaw)
      .set(newToken)
      .then(() => {
        setTimeout(() => {
          resolve(idRaw);
        }, 500);
      })
      .catch((err) => {
        reject(err);
      });
  });
}
