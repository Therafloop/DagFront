import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';
import { firestore } from '../contexts/FirebaseContext';
import { getServerUrlServPlatform } from './getServerUrl';

// const backendServerURL = isProduction ? backendURL : backendURLSandbox;
const backendServerURL = getServerUrlServPlatform();

const conn = axios.create({
  baseURL: backendServerURL,
  headers: {
    // 'Content-Type': 'application/json',
    // 'User-Agent': 'dagpacket-frontend',
    Accept: 'application/json',
    Authorization: 'dagtoken'
  }
});

const reportError = async (dataError) => {
  await firestore.collection('errorReports').add(dataError);
};

// export async function getListRecargas() {
//   const res = await conn.get('/pagos/recargas');
//   return res.data;
// }
export async function getListRecargas(userId = '') {
  try {
    const res = await conn.get('/pagos/recargas');
    return res.data;
  } catch (error) {
    await reportError({
      error: JSON.stringify(error),
      errorAction: 'getListRecargas',
      section: 'getListRecargas Function',
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error obteniendo lista de recargas',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    });
    throw error;
  }
}

// export async function getListServicios() {
//   const res = await conn.get('/pagos/servicios');
//   return res.data;
// }

export async function getListServicios(userId = '') {
  try {
    const res = await conn.get('/pagos/servicios');
    return res.data;
  } catch (error) {
    await reportError({
      error: JSON.stringify(error),
      errorAction: 'getListServicios',
      section: 'getListServicios Function',
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error obteniendo lista de servicios',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    });
    throw error;
  }
}

// export async function comprarRecargasServicios(data) {
//   const res = await conn.post('/pagos/pindistsale/recargasyservicios/', data);
//   return res.data;
// }

export async function comprarRecargasServicios(data, userId = '') {
  try {
    const res = await conn.post('/pagos/pindistsale/recargasyservicios/', data);
    return res.data;
  } catch (error) {
    await reportError({
      error: JSON.stringify(error),
      errorAction: 'comprarRecargasServicios',
      section: 'comprarRecargasServicios Function',
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error en función comprar recargas y servicios',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    });
    throw error;
  }
}

// export async function getReporteConciliacion() {
//   const res = await conn.post('/pagos/reporte');
//   return res.data;
//   // return `${backendURL}/pagos/reporte`;
// }

export async function getReporteConciliacion(userId = '') {
  try {
    const res = await conn.post('/pagos/reporte');
    return res.data;
  } catch (error) {
    await reportError({
      error: JSON.stringify(error),
      errorAction: 'getReporteConciliacion',
      section: 'getReporteConciliacion Function',
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error al obtener reporte de',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    });
    throw error;
  }
}

// export async function getDetailsStatusEmida(token) {
//   const res = await conn.get('/pagos/getAccountBalance/recargas', {
//     headers: {
//       Authorization: token
//     }
//   });

//   return res;
// }
export async function getDetailsStatusEmida(token, userId = '') {
  try {
    const res = await conn.get('/pagos/getAccountBalance/recargas', {
      headers: {
        Authorization: token
      }
    });

    return res;
  } catch (error) {
    await reportError({
      error: JSON.stringify(error),
      errorAction: 'getDetailsStatusEmida',
      section: 'getDetailsStatusEmida Function',
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error getting details status emida',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    });
    throw error;
  }
}

// export async function getDetailsStatusEmidaServicios(token) {
//   const res = await conn.get('/pagos/getAccountBalance/servicios', {
//     headers: {
//       Authorization: token
//     }
//   });
//   // console.log({ res });

//   return res;
// }

export async function getDetailsStatusEmidaServicios(token, userId = '') {
  try {
    const res = await conn.get('/pagos/getAccountBalance/servicios', {
      headers: {
        Authorization: token
      }
    });

    return res;
  } catch (error) {
    await reportError({
      error: JSON.stringify(error),
      errorAction: 'getDetailsStatusEmidaServicios',
      section: 'getDetailsStatusEmidaServicios Function',
      created_at: new Date(),
      updated_at: new Date(),
      description: 'Error getting details status emida servicios',
      versionApp: localStorage.getItem('versionApp'),
      user_id: userId
    });
    throw error;
  }
}
