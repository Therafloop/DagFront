import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction, isLockerV2, backendURLLocker } from '../config';
import { getServerUrlLocker } from './getServerUrl';

// const backendServerURL = isProduction ? backendURL : backendURLSandbox;
// const backendServerURL = isLockerV2 ? backendURLLocker : backendURL;
const backendServerURL = getServerUrlLocker();

const conn = axios.create({
  baseURL: `${backendServerURL}/lockers`
});

/**
 *
 * @param {string} id id del locker
 * @param {string} token token de autorizacion
 * @returns respuesta de la api
 */
export async function getLockerData(id, token) {
  const res = await conn.get(id, { headers: { Authorization: token } });
  return res.data;
}

/**
 * Abrir un cajon
 * @param {string} lockerId id del locker
 * @param {string} id id de cajon
 * @param {boolean} active valor nuevo
 * @param {string} token Token de autorizacion
 * @returns Respuesta de la api
 */
export async function setOpenLocker(lockerId, id, _active, token) {
  const res = await conn.post(
    `${lockerId}/door`,
    { command: 'ON', location: id.toLowerCase() },
    {
      headers: {
        Authorization: token
      }
    }
  );
  return res.data;
}

// export async function Medir(lockerId, token) {
//   // const res = await conn.get(`${lockerId}/dimensions?command=m`, {
//   const res = await conn.get(`/testlocker/dimensions?command=m`, {
//     headers: {
//       Authorization: token
//     }
//   });
//   return res.data;
// }

export async function Medir(lockerId, token) {
  // const res = await conn.get(`${lockerId}/dimensions?command=m`, {
  const res = await conn.post(
    `/${lockerId}/dimensions`,
    {
      command: 'm'
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
  return res.data;
}

export async function Pesar(lockerId, token) {
  console.log('aaaaaaaa');
  const res = await conn.get(`${lockerId}/weight`, {
    headers: {
      Authorization: token
    }
  });
  return res.data;
}

export async function calibrarMedicion(lockerId, token) {
  const res = await conn.get(`${lockerId}/dimensions?command=s`, {
    headers: {
      Authorization: token
    }
  });
  return res.data;
}

export async function calibrarPeso(lockerId, token) {
  const res = await conn.post(
    `${lockerId}/calibrate`,
    {},
    {
      headers: {
        Authorization: token
      }
    }
  );
  return res.data;
}

export async function getBestFitLocker(lockerId, token, data) {
  const res = await conn.post(
    `best-fit`,
    {
      lockerId,
      package: data
    },
    {
      headers: {
        Authorization: token
      }
    }
  );
  return res.data;
}

export async function obtainCajonStatus(cajonId, token) {
  const res = await conn.get(`testlocker/${cajonId}/status`, {
    headers: {
      Authorization: token
    }
  });
  return res.data;
}
