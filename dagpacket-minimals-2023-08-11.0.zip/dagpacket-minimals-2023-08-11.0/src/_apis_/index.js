import './chat';
import './mail';
import './blog';
import './user';
import './account';
import './calendar';
import './products';
import './kanban';
