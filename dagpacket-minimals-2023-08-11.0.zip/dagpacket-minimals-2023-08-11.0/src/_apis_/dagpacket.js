import axios from 'axios';
import { backendURL, backendURLSandbox, isProduction } from '../config';
import { getServerUrlServPlatform } from './getServerUrl';

// const backendServerURL = isProduction ? backendURL : backendURLSandbox;
const backendServerURL = getServerUrlServPlatform();

const conn = axios.create({
  baseURL: backendServerURL,
  headers: {
    'Content-Type': 'application/json',
    // 'User-Agent': 'dagpacket-frontend',
    Accept: 'application/json',
    Authorization: 'dagtoken'
  }
});

const connAlt = axios.create({
  baseURL: backendServerURL,
  headers: {
    'Content-Type': 'application/json',
    // 'User-Agent': 'dagpacket-frontend',
    Accept: 'application/json'
  }
});

export async function getPaquetes() {
  const res = await conn.get('paquetes/mienvio/');
  return res.data;
}

// export async function getPaquetesRed() {
//   const res = await conn.get('paquetes/redpack/');
//   return res.data;
// }

export async function hacerCotizacion(data, token) {
  const res = await connAlt.post('paquetes/mienvio/cotizar', data, {
    headers: {
      Authorization: token
    }
  });
  console.log(token);
  return res.data;
}

// eslint-disable-next-line consistent-return
export async function hacerCotizacionRed(data) {
  data.delivery_type = 2;
  data.shipping_type = 2;
  // console.log(data);
  try {
    const res = await conn.post('paquetes/redpack/cotizar', data);
    return Promise.resolve(res.data);
  } catch (error) {
    return Promise.reject(error.response);
  }
}

export async function hacerEnvioRedpack(data) {
  const res = await conn.post('/paquetes/redpack', data);
  return res.data;
}

export async function getTarifas(objectId) {
  const res = await conn.get(`paquetes/mienvio/${objectId}/tarifas`);
  return res.data;
}

export async function hacerEnvio(data) {
  const res = await conn.post('paquetes/mienvio', data);
  return res.data;
}

export async function getTarifaChoose(object_id) {
  try {
    const res = await conn.get(`paquetes/mienvio/${object_id}/tarifas`);
    return res.data;
  } catch (error) {
    console.log(error.response);
  }
  return false;
}

export async function updateEnvio(object_id, rateId) {
  // rateId es el id de la tarifa que seleccionamos
  const newData = { rate: rateId.toString(), object_purpose: 'PURCHASE' };
  console.log(object_id, newData);
  try {
    const res = await conn.put(`paquetes/mienvio/${object_id}`, newData);
    console.log(res.data);
    return res.data;
  } catch (error) {
    console.log(error.response);
  }
  return false;
}

export async function getUpdatedEnvio(object_id) {
  const res = await conn.get(`paquetes/mienvio/${object_id}/`);
  return res.data;
}

export function getGuiaMienvio(id) {
  return `${backendServerURL}/paquetes/mienvio/compras/${id}/guia`;
}

// export async function listaEnvios() {
//   const res = await conn.get('shipments?with_label=true&limit=10&payed=true');
//   return res.data;
// }

// schema example
/* 
  {
  "shipments": [
    "quote_shipment_id"
  ],
  "payment": {
    "provider": "wallet"
  }
} 
  guardar la repuesta de la peticion
  // realizar esta accion al redirijir y finalizar compra de cada uno
*/

export async function crearCompra(data) {
  const res = await conn.post('paquetes/mienvio/compras', data);
  return res.data;
}

// pago a clip

export async function clipTransaction(data) {
  const res = await conn.post('clip/transactions', data);
  return res.data;
}

export async function clipDeleteTransaction(code) {
  const res = await conn.delete(`clip/transactions/${code}`);
  return res.data;
}

export async function clipConfirm(data) {
  const res = await conn.post('/clip/createpayment', data);
  return res.data;
}

export async function clipPaymentConfirm(code) {
  const res = await conn.get(`clip/transactions/${code}`);
  return res.data;
}

// obtener envio

export async function getGuia(object_id) {
  // const res = await conn.get(`/paquetes/mienvio/compras/1072593/guia`);
  const res = await conn.get(`/paquetes/mienvio/compras/${object_id}/guia`);
  return res.data;
}

// obtenr compras

export async function getConvertCompras(data) {
  // const newData = [];
  // data.map((item) => newData.push(item.toString()));
  // console.log(newData);
  console.log(data);
  const obj = {
    shipments: [data],
    payment: {
      provider: 'wallet'
    }
  };

  const res = await conn.post('/paquetes/mienvio/compras', obj);
  return res.data;
}

// Redpack

export function getPDFRedpackUrl(id) {
  return `${backendServerURL}/paquetes/redpack/pdf/${id}`;
}

export async function getOriginDestination(origin, destination) {
  const res = await conn.get(`/maps/directions?origin=${origin}&destination=${destination}`);
  return res.data;
}

// ----------------UPS----------------

export async function cotizacionUPS(data) {
  const res = await conn.post('/paquetes/ups/cotizar', data);
  return res.data;
}

export async function hacerEnvioUPS(data) {
  const res = await conn.post('/paquetes/ups', data);
  return res.data;
}

export function getGuiaUPS(id) {
  return `${backendServerURL}/paquetes/ups/label/${id}`;
}

// ----------------- envio activo (super envio)--------

export async function cotizacionSuperEnvio(data) {
  const res = await conn.post('/paquetes/superenvios/cotizar', data);
  return res.data;
}

export async function hacerEnvioSuperEnvios(data) {
  const res = await conn.post('/paquetes/superenvios', data);
  return res.data;
}

export function getGuiaSuperenvios(id) {
  return `${backendServerURL}/paquetes/superenvios/label/${id}`;
}

export function getGuiaPdfSuperenvios(rate_provider, trackingNum, locker) {
  // console.log('los datooooooooooooooooooos', rate_provider, trackingNum);
  // const res = await conn.get(`/paquetes/superenvios/label/${rate_provider}/${trackingNum}`);
  // const res = await conn.get(`/paquetes/superenvios/label/dhl/299299}`);
  // console.debug(res);
  // return res.data;

  if (locker) {
    return `${backendServerURL}/paquetes/superenvios/label/${rate_provider}/${trackingNum}?rotate=true`;
  }

  return `${backendServerURL}/paquetes/superenvios/label/${rate_provider}/${trackingNum}`;
}

// ================ 99 MINUTOS

export function getGuia99Superenvios(id) {
  return `${backendServerURL}/paquetes/99minutos/label/${id}`;
}

// ============= PAQUETEEXPRESS
export function getGuiaPaqueteXpress(id) {
  return `${backendServerURL}/paquetes/paqueteexpress/label/${id}`;
}

// DHL ======
export function getGuiaDHL(id) {
  return `${backendServerURL}/paquetes/dhl/label/${id}`;
}

// Altospack ======
export function getGuiaAltospack(id) {
  return `${backendServerURL}/paquetes/altospack/label/${id}`;
}

// Altospack ======
export function getGuiaVencedor(id) {
  return `${backendServerURL}/paquetes/vencedor/label/${id}`;
}

// Altospack ======
export function getGuiaJyT(id) {
  return `${backendServerURL}/paquetes/J&T/label/${id}`;
}

// STMP and WHatsapp Send Recibo Locker
export async function sendReciboWhatsappSMTP({ id, addresses, dagpacketCode, total }) {
  try {
    const res = await conn.post(`/invoices/send/${id}`, {
      addresses,
      total,
      dagpacketCode
    });
    return res;
  } catch (error) {
    console.log({ error });
    return error;
  }
}

export function getGuiaFormatUrl({ provider = '', codigo = '', rate_provider = '', label_code = '', locker = false }) {
  provider = provider.toLowerCase();
  switch (provider) {
    case 'ups':
      return getGuiaUPS(codigo);
    case 'redpack':
      return getPDFRedpackUrl(codigo);
    case 'mienvio':
      return getGuiaMienvio(codigo);
    case 'superenvios':
      return getGuiaPdfSuperenvios(rate_provider, codigo, locker);
    case '99minutos':
      return getGuia99Superenvios(codigo);
    case 'paqueteexpress':
      return getGuiaPaqueteXpress(codigo);
    case 'dhl':
      return getGuiaDHL(codigo);
    case 'altospack':
      return getGuiaAltospack(label_code);
    case 'j&t':
      return getGuiaJyT(label_code);

    default:
      throw new Error(`Paquetería no controlada, falta agregar provider ${provider}`);
  }
}
